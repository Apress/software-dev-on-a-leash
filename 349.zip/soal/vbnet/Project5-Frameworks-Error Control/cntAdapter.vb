Option Strict Off
Option Explicit On 
Option Compare Text
Public Class cntAdapter
    '*************************************************************************
    'Source Code,
    'Framework, &
    'Architecture :  Copyright (c) 1997-2000 Virtual Machine Intelligence Inc. All Rights Reserved
    '
    '*************************************************************************

    Private lngRow As Long
    Private lngRowSetCtr As Long
    Private objData As Object
    Private strSQLLast As String
    Private vntItem As Object
    Private moObserve As New vTools.Observer()
    Private objRef As Object
    Private objCfg As Object
    Private vntID As Object
    Private tcData As New vTools.TurboCollection()
    Private tcOut As vTools.TurboCollection
    Private strBrowseRule As String
    Private strOutputFile As String
    Private pHandle As vTools.ParmNode
    Private oTxt As vTools.TextIO
    Private vntItemTag As Object
    Private tcLayout As New vTools.TurboCollection()
    Private blnKillBrowse As Boolean
    Private strAdp As vTools.StringAdapter
    Private blnStatusMessage As Boolean
    Private strStatusMessage As String
    Private strPrintDelim As String
    Private strSourceType As String
    Private strFindKey As String
    Private strDelim As String = "|"
    Private strWorkType As String
    Private strPath As String
    Private strPackageTag As String
    Private lngMaxRows As Long
    Public Function cntCol() As Object
        On Error Resume Next
        cntCol = tcData
    End Function
    Public Property ID(ByVal NewV As Object)
        Get
            ID = vntID
        End Get
        Set(ByVal Value)
            vntID = NewV
        End Set
    End Property

    Public Function Create(Optional ByVal pParent As Object = Nothing) As cntAdapter
        On Error Resume Next
        Dim objNew As Object
        objNew = New cntAdapter()
        objNew.Init(pParent)
        Create = objNew
    End Function
    Public Sub ctlEvent(ByVal strEvent As String, _
    Optional ByVal Parm1 As String = Nothing, _
    Optional ByVal Parm2 As String = Nothing, _
    Optional ByVal Parm3 As String = Nothing)
        On Error Resume Next

        moObserve.Observe(Me, strEvent, "CONTAINER")

    End Sub
    'Public Sub AddTrigger(oEventDestination As Object, vntPerform As Variant, vntWatch As Variant)
    '  InitEvents
    '  moEvent.AddTrigger oEventDestination, vntPerform, vntWatch
    'End Sub
    'Public Function EventTrap(vntDesc As Variant) As Variant
    '  InitEvents
    '  EventTrap = moEvent.EventTrap(vntDesc)
    'End Function
    'Private Sub InitEvents()
    '  If Not moEvent Is Nothing Then Exit Sub
    '  Set moEvent = New EventMgr
    '  moEvent.Init Me, objFA
    'End Sub
    Public Function Action(ByVal ActionID As String, Optional ByVal ActionData As String = Nothing, Optional ByVal ActionObject As Object = Nothing) As String
        On Error Resume Next
        Dim strAction As String
        Dim strActionData As String
        Dim pWrk As vTools.ParmNode
        strAction = ActionID
        strActionData = ActionData
        Dim strItem As String
        Dim tcParm As vTools.TurboCollection

        If strAction = vbNullString Then Exit Function
        '   Set tcParm = glb.UnstringParm(strActionData, "ActionID")
        '   Set pWrk = tcParm.Find("ActionID")
        '   If pWrk Is Nothing Then
        '     Action = Item(strActionData)
        '     Exit Function
        '   End If
        '
        '   strAction = pWrk.Item
        '  End If

        Select Case strAction
            Case "Item"
                '    Debug.Print
                tcParm = glb.UnStringParm(strActionData, "Item")
                pWrk = tcParm.Find("Item")
                If pWrk Is Nothing Then
                    tcParm.MoveFirst()
                    Me.Item(tcParm.Ref.ItemKey) = tcParm.Ref.Item
                Else
                    If tcParm.Count = 1 Then
                        Action = Item(pWrk.Item)
                    Else
                        strItem = pWrk.Item
                        tcParm.Remove(pWrk)
                        pWrk = tcParm.Find("Item")
                        Item(strItem) = pWrk.Item
                    End If

                End If

            Case "DataPresent"
                Action = CStr(tcData.DataPresent)
            Case "MoveNext"
                Action = CStr(MoveNext())
            Case "MoveFirst"
                MoveFirst()
            Case "Layout"
                Layout(strActionData)
            Case "Load"
                strPackageTag = strActionData
                Load(strActionData)
            Case "Sort"
                Sort(strActionData)
            Case "GetRow"
                Action = GetRow()
            Case "PutRow"
                PutRow(strActionData)
            Case "AddRow"
                AddRow(strActionData)
            Case "Browse"
                Browse(strActionData, ActionObject)
        End Select


    End Function
    Public Function GetRow() As String
        On Error Resume Next
        Dim strWrk As String
        Dim lngI As Long
        lngI = 0
        With tcLayout
            .MoveFirst()
            Do
                If lngI <> 0 Then strWrk = strWrk & strDelim
                strWrk = strWrk & tcData.Ref.Row(lngI)
                lngI = lngI + 1
                .MoveNext()
            Loop While .More
        End With
        GetRow = strWrk
    End Function
    Public Sub PutRow(ByVal strDat As String)
        On Error Resume Next
        Dim lngI As Long
        Dim pWrk As vTools.ParmNode
        Dim strA As vTools.StringAdapter
        strA = glb.NewStringAdapter
        strA.Parse(strDat, strDelim)
        lngI = 0
        strA.MoveFirst()
        Do
            tcData.Ref.Row(lngI) = strA.Item
            lngI = lngI + 1
            strA.MoveNext()
        Loop While strA.More
        glb.OldStringAdapter(strA)
    End Sub
    Public Sub AddRow(ByVal strDat As String)
        On Error Resume Next
        tcData.Add()
        tcData.Ref.RowInit = tcLayout.Count
        PutRow(strDat)
    End Sub
    Public ReadOnly Property MyLayout() As Object 'turbocollection
        Get
            MyLayout = Nothing
            MyLayout = tcLayout
        End Get
    End Property
    Public Sub LoadLayout(ByVal cntAdp As cntAdapter)
        On Error Resume Next
        Dim tcL As vTools.TurboCollection
        tcL = cntAdp.MyLayout
        tcL.MoveFirst()
        Do
            tcLayout.AddItem(tcL.Ref.Item, tcL.Ref.Item)
            tcLayout.Ref.ID = tcL.Ref.ID
            tcL.MoveNext()
        Loop While tcL.More
        tcL = Nothing
    End Sub
    Public Sub Layout(ByVal strLayout As String)
        On Error Resume Next
        Dim lngI As Long
        Dim lngS As Long
        Dim lngM As Long
        Dim pWrk As vTools.ParmNode
        Dim strWrk As String
        Dim strFormat As String
        Dim tcParm As vTools.TurboCollection
        'If tcLayout.DataPresent Then Exit Sub

        tcLayout.Clear()
        Dim strA As vTools.StringAdapter
        strA = glb.NewStringAdapter
        strA.Parse(CStr(strLayout), strDelim)
        lngI = 0
        strA.MoveFirst()
        Do
            tcParm = glb.UnStringParm(strA.Item, "Tag", ",")
            strWrk = tcParm.Find("Tag").Item
            strFormat = vbNullString
            tcLayout.AddItem(strWrk, strWrk, strWrk, "c")
            pWrk = tcLayout.Ref
            pWrk.ItemSize = tcParm.Find("Size").Item
            pWrk.ItemType = tcParm.Find("Type").Item
            strFormat = tcParm.Find("Format").Item


            lngM = 0
            lngS = pWrk.ItemSize
            If pWrk.ItemType = "N" Then
                If lngS = 0 Then lngS = 10
                strWrk = vbNullString
                Do
                    strWrk = strWrk & "0"
                    lngM = lngM + 1
                Loop While lngM < lngS
                pWrk.FormatStr = strWrk
            ElseIf pWrk.ItemType = "D" Then
                If strFormat = vbNullString Then pWrk.FormatStr = "YYYYMMDD"
            End If




            tcLayout.Ref.ID = lngI
            lngI = lngI + 1
            strA.MoveNext()
        Loop While strA.More
        glb.OldStringAdapter(strA)

    End Sub
    Public Sub Init(ByVal pCfg As Object)
        On Error Resume Next
        strDelim = "|"

        If pCfg Is Nothing Then Exit Sub



    End Sub
    Public WriteOnly Property Observe(Optional ByVal Instructions As String = Nothing)
        Set(ByVal Value)
            On Error Resume Next
            moObserve.Add(Me, Value, Instructions)
        End Set
    End Property
    Public Sub New()
        On Error Resume Next
        oTxt = glb.TextIOMgr
        vntItem = vbNullString
    End Sub
    Public WriteOnly Property KillBrowse(ByVal strS As String)
        Set(ByVal Value)
            On Error Resume Next
            blnKillBrowse = True
        End Set
    End Property
    Public Sub Clear()
        On Error Resume Next
        tcData.Clear()
    End Sub
    Public Function MoveNext() As Boolean
        Dim blnMore As Boolean
        On Error Resume Next
        tcData.MoveNext()
        MoveNext = tcData.More
    End Function
    Public Sub MoveFirst()
        On Error Resume Next
        tcData.MoveFirst()
    End Sub
    Public Function Count() As Long
        On Error Resume Next
        Count = tcData.Count
    End Function
    Public Function More() As Boolean
        On Error Resume Next
        More = tcData.More
    End Function
    Public Property Item(Optional ByVal strKey As String = Nothing) As String
        Get
            Dim lngX As Long
            Dim vntWrk As String
            Dim pWrk As vTools.ParmNode
            Item = Nothing

            If tcLayout Is Nothing Or tcData Is Nothing Then Exit Property

            If IsNumeric(CStr(strKey)) Then
                lngX = CLng(strKey)
            Else
                pWrk = tcLayout.Find(CStr(strKey), lngPosition:=lngX)
                If pWrk Is Nothing Then
                    Item = "***" & CStr(strKey) & "***"
                    Exit Property
                End If
            End If

            Item = tcData.Ref.ArrValue(CLng(lngX))
        End Get
        Set(ByVal Value As String)
            On Error Resume Next
            Dim lngX As Long
            Dim pWrk As vTools.ParmNode

            If IsNumeric(CStr(strKey)) Then
                tcData.Ref.ArrValue(CLng(strKey)) = Value
            Else
                pWrk = tcLayout.Find(CStr(strKey), lngPosition:=lngX)
                If Not pWrk Is Nothing Then
                    tcData.Ref.ArrValue(CLng(lngX)) = Value
                End If
            End If
        End Set
    End Property
    Public ReadOnly Property DataPresent() As Boolean
        Get
            On Error Resume Next
            DataPresent = False
            DataPresent = tcData.DataPresent()
        End Get
    End Property
    Private Sub Sort(ByVal sCol As String)
        On Error Resume Next
        Dim strA As vTools.StringAdapter
        Dim strParms As String
        Dim strP As String
        Dim strW As String
        Dim tcSort As New vTools.TurboCollection()
        Dim pWrk As vTools.ParmNode
        Dim strCol As String
        Dim strWrk As String
        Dim blnDesc As Boolean
        Dim vntValue As String
        Dim lngI As Long
        Dim lngS As Long

        blnDesc = False
        If Not tcData.DataPresent Then Exit Sub
        strA = glb.NewStringAdapter
        strA.Parse(CStr(sCol), strDelim)

        Do
            If strA.Item = "@Descending" Then
                blnDesc = True
            Else
                pWrk = tcLayout.Find(strA.Item)
                If Not pWrk Is Nothing Then
                    tcSort.Add()
                    tcSort.Ref.Ref = pWrk
                    lngS = pWrk.ItemSize
                    If lngS = 0 Then lngS = 10
                    tcSort.Ref.ItemSize = lngS
                    tcSort.Ref.ID = pWrk.ID
                    tcSort.Ref.ItemType = pWrk.ItemType
                End If
            End If
            strA.MoveNext()
        Loop While strA.More

        tcData.MoveFirst()
        Do
            strWrk = vbNullString
            tcSort.MoveFirst()
            Do
                pWrk = tcSort.Ref.Ref
                strCol = tcData.Ref.Row(pWrk.ID)
                Select Case pWrk.ItemType
                    Case "d"
                        strCol = Format(strCol, "yyyyMMdd")
                    Case "n"
                        strCol = Format(CLng(strCol), "0000000000")
                    Case Else
                        If Len(strCol) > 10 Then
                            strCol = Mid(strCol, 1, 10)
                        Else
                            strCol = strCol & Space(10 - Len(strCol))
                        End If
                End Select
                strWrk = strWrk & strCol
                tcSort.MoveNext()
            Loop While tcSort.More
            tcData.Ref.SortKey = strWrk





            tcData.MoveNext()
        Loop While tcData.More




        tcData.SortList(strParms = "Ascending|" & CStr(CBool(Not blnDesc)))
        tcData.MoveFirst()

        tcSort.Clear()
        glb.OldStringAdapter(strA)


    End Sub
    Public Sub Remove(ByVal strDat As String, ByVal strKey As String)
        On Error Resume Next
        Dim pWrk As vTools.ParmNode
        Dim pNew As vTools.ParmNode
        pWrk = tcData.Ref
        tcData.MoveNext()
        pNew = tcData.Ref
        If pNew Is pWrk Then
            tcData.Remove(pNew)
        Else
            tcData.Remove(pWrk)
            tcData.Ref = pNew
        End If

    End Sub
    Private Sub Find(ByVal strKeyVal As String)
        On Error Resume Next
        Dim pWrk As vTools.ParmNode
        pWrk = tcData.Find(strKeyVal, blnSetRef:=True)
    End Sub
    Private Sub SetFindKey(ByVal strKey As String)
        On Error Resume Next
        If tcData Is Nothing Then Exit Sub
        If Not tcData.DataPresent Then Exit Sub



        Dim lngX As Long
        ' Dim vntX As Long
        Dim pWrk As vTools.ParmNode

        If IsNumeric(strKey) Then
            lngX = CLng(strKey)
        Else
            pWrk = tcLayout.Find(strKey, lngPosition:=lngX)
            If pWrk Is Nothing Then Exit Sub
            'lngX = CLng(vntX)
        End If

        pWrk = tcData.Ref


        With tcData
            .MoveFirst()
            Do

                .Ref.ItemKey = .Ref.ArrValue(lngX)

                .MoveNext()
            Loop While .More
        End With

        tcData.Ref = pWrk

    End Sub
    Public ReadOnly Property LayoutStr() As String
        Get
            On Error Resume Next
            Dim lngI As Long
            Dim strWrk As String
            strWrk = vbNullString
            LayoutStr = strWrk
            lngI = 0
            If tcLayout Is Nothing Then Exit Property
            tcLayout.MoveFirst()
            Do
                If lngI <> 0 Then strWrk = strWrk & strDelim
                strWrk = strWrk & tcLayout.Ref.Item
                tcLayout.MoveNext()
                lngI = lngI + 1
            Loop While tcLayout.More
            LayoutStr = strWrk
        End Get

    End Property
    Public Sub Load(Optional ByVal iPackage As String = Nothing)
        On Error Resume Next
        If InStr(1, iPackage, "Path=", vbTextCompare) > 0 Then
            LoadFile(iPackage)
        Else
            objData = DataLoad(False)
            If Not objData Is Nothing Then
                If objData.DataPresent Then LoadList()
            End If
        End If

    End Sub
    Private Sub LoadFile(Optional ByVal iPackage As String = Nothing)
        On Error Resume Next
        Dim tcFile As vTools.TurboCollection
        Dim tcPackage As vTools.TurboCollection
        Dim lngI As Long
        Dim oTxt As vTools.TextIO
        Dim strA As vTools.StringAdapter
        strA = glb.NewStringAdapter
        Dim arr() As String
        Dim pWrk As vTools.ParmNode
        ReDim arr(tcLayout.Count)
        Dim strSource As String
        Dim strPath As String
        Dim strD As String

        tcPackage = glb.UnStringParm(iPackage, "Source")
        strSource = vbNullString
        strSource = tcPackage.Find("Source").Item
        If strSource = vbNullString Then Exit Sub

        strD = strDelim
        If strSource = "Text" Then
            strPath = vbNullString
            strPath = tcPackage.Find("Path").Item
            If strPath = vbNullString Then Exit Sub
            If Mid(strPath, 1, 5) <> "file:" Then Exit Sub
            strPath = (Mid(strPath, 6))
            tcData.Clear()
            strD = tcPackage.Find("Delim").Item

            oTxt = glb.TextIOMgr
            tcFile = oTxt.LoadInputFile(strPath)
            If tcFile Is Nothing Then tcFile = glb.LoadResourceFile(strPath)
            If Not tcFile Is Nothing Then
                tcFile.MoveFirst()
                Do
                    strA.Parse(tcFile.Ref.Item, strD)
                    pWrk = tcData.Add
                    pWrk.RowInit = strA.Count
                    lngI = 0
                    Do
                        pWrk.Row(lngI) = strA.Item
                        lngI = lngI + 1
                        strA.MoveNext()
                    Loop While strA.More

                    tcFile.MoveNext()
                Loop While tcFile.More
            End If

        End If


        tcFile.Clear()
        tcPackage.Clear()


        glb.OldStringAdapter(strA)



    End Sub
    Private Sub Browse(ByVal strDat As String, ByVal oCall As Object)
        On Error Resume Next
        Dim blnMore As Boolean
        Dim tcParm As vTools.TurboCollection
        Dim strRoutine As String


        If tcData Is Nothing Then Exit Sub
        If Not tcData.DataPresent Then Exit Sub


        tcParm = glb.UnStringParm(strDat, "Routine")

        strRoutine = tcParm.Find("Routine").Item


        blnKillBrowse = False
        MoveFirst()

        Do
            oCall.Action("Execute", "Routine=" & strRoutine)
            If blnKillBrowse Then Exit Do
        Loop While MoveNext()

        tcParm.Clear()



    End Sub
    Public Sub dbAction(ByVal strPar As String, ByVal blnAsync As Boolean)
        On Error Resume Next
        strPackageTag = strPar
        DataLoad(blnAsync)
    End Sub
    Public Function DataLoad(ByVal blnAsync As Boolean) As Object
        DataLoad = Nothing
        Dim strA As vTools.StringAdapter
        strA = glb.NewStringAdapter
        On Error Resume Next
        Dim dbD As Object
        Dim dbB As Object
        If strPackageTag <> vbNullString Then

            If Mid(strPackageTag, 1, 4) = "SQL:" Then
                dbB = dbPer.Ref("Broker")
                dbB.Item("SQL") = Mid(strPackageTag, Len("SQL: "))

            ElseIf Mid(strPackageTag, 1, 8) = "SQLTEST:" Then
                dbB = dbPer.Ref("Broker")
                dbB.Item("SQL") = Mid(strPackageTag, Len("SQLTEST: "))
                strSQLLast = dbB.SQL
                Exit Function

            ElseIf InStr(1, strPackageTag, "Package:", vbTextCompare) > 0 Then
                strA.Parse(strPackageTag, ":")
                strA.MoveNext()
                dbB = dbPer.Ref("Broker")
                dbB.Item("SQL") = dbB.PackageSQL(strA.Item)
            Else
                dbB = dbPer.Ref("Broker")
                dbB.Item("SQL") = dbB.DefaultSQL(strPackageTag)
            End If

            strSQLLast = dbB.SQL
            dbD = dbB.Execute(blnAsync)
            If Err.Number <> 0 Then
                glb.DebugOut(Err.Description)
            End If
            DataLoad = dbD
        End If

        glb.OldStringAdapter(strA)

    End Function
    Private Sub LoadList()
        On Error Resume Next
        Dim blnMore As Boolean
        Do
            blnMore = LoadRow()
            objData.MoveNext()
        Loop While objData.More
        objData = Nothing
    End Sub
    Public Function LoadPrep() As Boolean
        On Error Resume Next
        LoadPrep = False
        tcData.Clear()
        lngMaxRows = 0


        lngRow = 0 'StartRow
        lngRowSetCtr = 0
        LoadPrep = True
    End Function
    Public Function LoadRow() As Boolean
        On Error Resume Next
        Dim blnLoad As Boolean
        Dim lngI As Long
        Dim strTag As String
        Dim strV As String
        Dim pWrk As vTools.ParmNode


        LoadRow = False

        tcLayout.MoveFirst()
        tcData.Add()
        pWrk = tcData.Ref
        pWrk.RowInit = tcLayout.Count

        Do


            strTag = tcLayout.Ref.ItemKey   'arrLayout(intIdx)
            If strTag <> vbNullString Then
                strV = CStr(objData.Item(strTag))
                tcLayout.Ref.Item = strV
                lngI = CLng(tcLayout.Ref.ID)
                pWrk.Row(lngI) = strV
            End If


            tcLayout.MoveNext()
        Loop While tcLayout.More


        lngMaxRows = lngMaxRows + 1
        lngRow = lngRow + 1

        LoadRow = True

    End Function
    Public Property MaxRows() As Long
        Get
            MaxRows = lngMaxRows
        End Get
        Set(ByVal Value As Long)
            lngMaxRows = Value
        End Set
    End Property



End Class
