Option Strict Off
Option Explicit On
Friend Class ProtoMe
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents opt2 As System.Windows.Forms.RadioButton
	Public WithEvents cbo1 As System.Windows.Forms.ComboBox
	Public WithEvents opt1 As System.Windows.Forms.RadioButton
	Public WithEvents cmdLaunchAgain As System.Windows.Forms.Button
	Public WithEvents cmd3 As System.Windows.Forms.Button
	Public WithEvents cmd2 As System.Windows.Forms.Button
    'Public WithEvents grd As Ax.AxDB
    Public WithEvents tvw As AxMSComctlLib.AxTreeView
	Public WithEvents chk As System.Windows.Forms.CheckBox
	Public WithEvents opt0 As System.Windows.Forms.RadioButton
	Public WithEvents txt4 As System.Windows.Forms.TextBox
	Public WithEvents txt3 As System.Windows.Forms.TextBox
	Public WithEvents _fra1_1 As System.Windows.Forms.GroupBox
	Public WithEvents txt5 As System.Windows.Forms.TextBox
	Public WithEvents txt6 As System.Windows.Forms.TextBox
	Public WithEvents fra0 As System.Windows.Forms.GroupBox
	Public WithEvents cboTest As System.Windows.Forms.ComboBox
	Public WithEvents cmd1 As System.Windows.Forms.Button
	Public WithEvents cmd0 As System.Windows.Forms.Button
	Public WithEvents txt1 As System.Windows.Forms.TextBox
	Public WithEvents txt0 As System.Windows.Forms.TextBox
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Public WithEvents fra1 As Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(ProtoMe))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.opt2 = New System.Windows.Forms.RadioButton()
        Me.cbo1 = New System.Windows.Forms.ComboBox()
        Me.opt1 = New System.Windows.Forms.RadioButton()
        Me.cmdLaunchAgain = New System.Windows.Forms.Button()
        Me.cmd3 = New System.Windows.Forms.Button()
        Me.cmd2 = New System.Windows.Forms.Button()
        Me.tvw = New AxMSComctlLib.AxTreeView()
        Me._fra1_1 = New System.Windows.Forms.GroupBox()
        Me.chk = New System.Windows.Forms.CheckBox()
        Me.opt0 = New System.Windows.Forms.RadioButton()
        Me.txt4 = New System.Windows.Forms.TextBox()
        Me.txt3 = New System.Windows.Forms.TextBox()
        Me.fra0 = New System.Windows.Forms.GroupBox()
        Me.txt5 = New System.Windows.Forms.TextBox()
        Me.txt6 = New System.Windows.Forms.TextBox()
        Me.cboTest = New System.Windows.Forms.ComboBox()
        Me.cmd1 = New System.Windows.Forms.Button()
        Me.cmd0 = New System.Windows.Forms.Button()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.txt0 = New System.Windows.Forms.TextBox()
        Me.fra1 = New Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray(Me.components)
        Me.DataGrid1 = New System.Windows.Forms.DataGrid()
        CType(Me.tvw, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._fra1_1.SuspendLayout()
        Me.fra0.SuspendLayout()
        CType(Me.fra1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'opt2
        '
        Me.opt2.BackColor = System.Drawing.SystemColors.Control
        Me.opt2.Cursor = System.Windows.Forms.Cursors.Default
        Me.opt2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.opt2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.opt2.Location = New System.Drawing.Point(8, 16)
        Me.opt2.Name = "opt2"
        Me.opt2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.opt2.Size = New System.Drawing.Size(17, 17)
        Me.opt2.TabIndex = 20
        Me.opt2.TabStop = True
        Me.opt2.Tag = "OpIn2"
        Me.opt2.Text = "Option1"
        '
        'cbo1
        '
        Me.cbo1.BackColor = System.Drawing.SystemColors.Window
        Me.cbo1.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbo1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cbo1.Location = New System.Drawing.Point(193, 40)
        Me.cbo1.Name = "cbo1"
        Me.cbo1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbo1.Size = New System.Drawing.Size(137, 22)
        Me.cbo1.TabIndex = 19
        Me.cbo1.Tag = "cboTest2"
        '
        'opt1
        '
        Me.opt1.BackColor = System.Drawing.SystemColors.Control
        Me.opt1.Cursor = System.Windows.Forms.Cursors.Default
        Me.opt1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.opt1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.opt1.Location = New System.Drawing.Point(8, 40)
        Me.opt1.Name = "opt1"
        Me.opt1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.opt1.Size = New System.Drawing.Size(17, 17)
        Me.opt1.TabIndex = 3
        Me.opt1.TabStop = True
        Me.opt1.Tag = "OpIn"
        Me.opt1.Text = "Option1"
        '
        'cmdLaunchAgain
        '
        Me.cmdLaunchAgain.BackColor = System.Drawing.SystemColors.Control
        Me.cmdLaunchAgain.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdLaunchAgain.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLaunchAgain.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdLaunchAgain.Location = New System.Drawing.Point(184, 311)
        Me.cmdLaunchAgain.Name = "cmdLaunchAgain"
        Me.cmdLaunchAgain.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdLaunchAgain.Size = New System.Drawing.Size(81, 25)
        Me.cmdLaunchAgain.TabIndex = 8
        Me.cmdLaunchAgain.Tag = "cmdLaunchAgain"
        Me.cmdLaunchAgain.Text = "LaunchAgain"
        '
        'cmd3
        '
        Me.cmd3.BackColor = System.Drawing.SystemColors.Control
        Me.cmd3.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmd3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmd3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmd3.Location = New System.Drawing.Point(96, 312)
        Me.cmd3.Name = "cmd3"
        Me.cmd3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmd3.Size = New System.Drawing.Size(81, 25)
        Me.cmd3.TabIndex = 7
        Me.cmd3.Tag = "Redo"
        Me.cmd3.Text = "Redo"
        '
        'cmd2
        '
        Me.cmd2.BackColor = System.Drawing.SystemColors.Control
        Me.cmd2.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmd2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmd2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmd2.Location = New System.Drawing.Point(8, 312)
        Me.cmd2.Name = "cmd2"
        Me.cmd2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmd2.Size = New System.Drawing.Size(81, 25)
        Me.cmd2.TabIndex = 6
        Me.cmd2.Tag = "Undo"
        Me.cmd2.Text = "Undo"
        '
        'tvw
        '
        Me.tvw.Location = New System.Drawing.Point(335, 96)
        Me.tvw.Name = "tvw"
        Me.tvw.OcxState = CType(resources.GetObject("tvw.OcxState"), System.Windows.Forms.AxHost.State)
        Me.tvw.Size = New System.Drawing.Size(113, 208)
        Me.tvw.TabIndex = 12
        '
        '_fra1_1
        '
        Me._fra1_1.BackColor = System.Drawing.SystemColors.Control
        Me._fra1_1.Controls.AddRange(New System.Windows.Forms.Control() {Me.chk, Me.opt0, Me.txt4, Me.txt3})
        Me._fra1_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._fra1_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fra1.SetIndex(Me._fra1_1, CType(1, Short))
        Me._fra1_1.Location = New System.Drawing.Point(8, 208)
        Me._fra1_1.Name = "_fra1_1"
        Me._fra1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._fra1_1.Size = New System.Drawing.Size(321, 97)
        Me._fra1_1.TabIndex = 18
        Me._fra1_1.TabStop = False
        Me._fra1_1.Tag = "someframe"
        Me._fra1_1.Text = "FrameA"
        '
        'chk
        '
        Me.chk.BackColor = System.Drawing.SystemColors.Control
        Me.chk.Cursor = System.Windows.Forms.Cursors.Default
        Me.chk.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chk.Location = New System.Drawing.Point(16, 32)
        Me.chk.Name = "chk"
        Me.chk.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chk.Size = New System.Drawing.Size(17, 13)
        Me.chk.TabIndex = 15
        Me.chk.Tag = "chkThose"
        Me.chk.Text = "Check2"
        '
        'opt0
        '
        Me.opt0.BackColor = System.Drawing.SystemColors.Control
        Me.opt0.Cursor = System.Windows.Forms.Cursors.Default
        Me.opt0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.opt0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.opt0.Location = New System.Drawing.Point(16, 64)
        Me.opt0.Name = "opt0"
        Me.opt0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.opt0.Size = New System.Drawing.Size(13, 13)
        Me.opt0.TabIndex = 16
        Me.opt0.TabStop = True
        Me.opt0.Tag = "OptOut"
        Me.opt0.Text = "Option1"
        '
        'txt4
        '
        Me.txt4.AcceptsReturn = True
        Me.txt4.AutoSize = False
        Me.txt4.BackColor = System.Drawing.SystemColors.Window
        Me.txt4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt4.Location = New System.Drawing.Point(40, 56)
        Me.txt4.MaxLength = 0
        Me.txt4.Name = "txt4"
        Me.txt4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt4.Size = New System.Drawing.Size(265, 25)
        Me.txt4.TabIndex = 14
        Me.txt4.Tag = "txt4"
        Me.txt4.Text = ""
        '
        'txt3
        '
        Me.txt3.AcceptsReturn = True
        Me.txt3.AutoSize = False
        Me.txt3.BackColor = System.Drawing.SystemColors.Window
        Me.txt3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt3.Location = New System.Drawing.Point(40, 24)
        Me.txt3.MaxLength = 0
        Me.txt3.Name = "txt3"
        Me.txt3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt3.Size = New System.Drawing.Size(265, 25)
        Me.txt3.TabIndex = 13
        Me.txt3.Tag = "txt3"
        Me.txt3.Text = ""
        '
        'fra0
        '
        Me.fra0.BackColor = System.Drawing.SystemColors.Control
        Me.fra0.Controls.AddRange(New System.Windows.Forms.Control() {Me.txt5, Me.txt6})
        Me.fra0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fra0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fra0.Location = New System.Drawing.Point(336, 8)
        Me.fra0.Name = "fra0"
        Me.fra0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fra0.Size = New System.Drawing.Size(113, 80)
        Me.fra0.TabIndex = 17
        Me.fra0.TabStop = False
        Me.fra0.Tag = "noFrame"
        Me.fra0.Text = "FrameB"
        '
        'txt5
        '
        Me.txt5.AcceptsReturn = True
        Me.txt5.AutoSize = False
        Me.txt5.BackColor = System.Drawing.SystemColors.Window
        Me.txt5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt5.Location = New System.Drawing.Point(7, 48)
        Me.txt5.MaxLength = 0
        Me.txt5.Name = "txt5"
        Me.txt5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt5.Size = New System.Drawing.Size(97, 24)
        Me.txt5.TabIndex = 10
        Me.txt5.Tag = "txt5"
        Me.txt5.Text = ""
        '
        'txt6
        '
        Me.txt6.AcceptsReturn = True
        Me.txt6.AutoSize = False
        Me.txt6.BackColor = System.Drawing.SystemColors.Window
        Me.txt6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt6.Location = New System.Drawing.Point(8, 15)
        Me.txt6.MaxLength = 0
        Me.txt6.Name = "txt6"
        Me.txt6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt6.Size = New System.Drawing.Size(97, 25)
        Me.txt6.TabIndex = 9
        Me.txt6.Tag = "txt6"
        Me.txt6.Text = ""
        '
        'cboTest
        '
        Me.cboTest.BackColor = System.Drawing.SystemColors.Window
        Me.cboTest.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboTest.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboTest.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboTest.Location = New System.Drawing.Point(192, 15)
        Me.cboTest.Name = "cboTest"
        Me.cboTest.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboTest.Size = New System.Drawing.Size(137, 22)
        Me.cboTest.TabIndex = 2
        Me.cboTest.Tag = "cboTest"
        '
        'cmd1
        '
        Me.cmd1.BackColor = System.Drawing.SystemColors.Control
        Me.cmd1.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmd1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmd1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmd1.Location = New System.Drawing.Point(304, 312)
        Me.cmd1.Name = "cmd1"
        Me.cmd1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmd1.Size = New System.Drawing.Size(81, 25)
        Me.cmd1.TabIndex = 5
        Me.cmd1.Tag = "cmdCancel"
        Me.cmd1.Text = "Cancel"
        '
        'cmd0
        '
        Me.cmd0.BackColor = System.Drawing.SystemColors.Control
        Me.cmd0.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmd0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmd0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmd0.Location = New System.Drawing.Point(392, 312)
        Me.cmd0.Name = "cmd0"
        Me.cmd0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmd0.Size = New System.Drawing.Size(57, 25)
        Me.cmd0.TabIndex = 4
        Me.cmd0.Tag = "cmdOk"
        Me.cmd0.Text = "Ok"
        '
        'txt1
        '
        Me.txt1.AcceptsReturn = True
        Me.txt1.AutoSize = False
        Me.txt1.BackColor = System.Drawing.SystemColors.Window
        Me.txt1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt1.Location = New System.Drawing.Point(31, 16)
        Me.txt1.MaxLength = 0
        Me.txt1.Name = "txt1"
        Me.txt1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt1.Size = New System.Drawing.Size(145, 19)
        Me.txt1.TabIndex = 1
        Me.txt1.Tag = "txt1"
        Me.txt1.Text = ""
        '
        'txt0
        '
        Me.txt0.AcceptsReturn = True
        Me.txt0.AutoSize = False
        Me.txt0.BackColor = System.Drawing.SystemColors.Window
        Me.txt0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txt0.Location = New System.Drawing.Point(32, 41)
        Me.txt0.MaxLength = 0
        Me.txt0.Name = "txt0"
        Me.txt0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt0.Size = New System.Drawing.Size(145, 19)
        Me.txt0.TabIndex = 0
        Me.txt0.Tag = "txt0"
        Me.txt0.Text = ""
        '
        'DataGrid1
        '
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid1.Location = New System.Drawing.Point(8, 72)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.Size = New System.Drawing.Size(320, 128)
        Me.DataGrid1.TabIndex = 21
        '
        'ProtoMe
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(456, 344)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.DataGrid1, Me.opt2, Me.cbo1, Me.opt1, Me.cmdLaunchAgain, Me.cmd3, Me.cmd2, Me.tvw, Me._fra1_1, Me.fra0, Me.cboTest, Me.cmd1, Me.cmd0, Me.txt1, Me.txt0})
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(11, 30)
        Me.MaximizeBox = False
        Me.Name = "ProtoMe"
        Me.Tag = "OptOut"
        Me.Text = "ProtoMe"
        CType(Me.tvw, System.ComponentModel.ISupportInitialize).EndInit()
        Me._fra1_1.ResumeLayout(False)
        Me.fra0.ResumeLayout(False)
        CType(Me.fra1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As ProtoMe
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As ProtoMe
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New ProtoMe()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	

End Class