Public Class absFunction
    '*************************************************************************
    'Source Code,
    'Framework, &
    'Architecture :  Copyright (c) 1997-2000 Virtual Machine Intelligence Inc. All Rights Reserved
    '
    '*************************************************************************
    Private oParent As Object
    Public Function Create(ByVal iParent As Object, ByVal iParm As String) As absFunction
        On Error Resume Next
        Dim oNew As absFunction
        oNew = New absFunction()
        Create = oNew
        oNew.Init(iParent, iParm)
    End Function
    Public Sub Init(ByVal iParent As Object, ByVal iParm As String)
        On Error Resume Next
        oParent = iParent
    End Sub
    Public Function Evaluate(ByVal strLHS As String, ByVal strRHS As String) As String
        On Error Resume Next
        Evaluate = ""
        Evaluate = Math.Abs(CDbl(strRHS))
    End Function



End Class
