Public Class spxfrFunction
    '*************************************************************************
    'Source Code,
    'Framework, &
    'Architecture :  Copyright (c) 1997-2000 Virtual Machine Intelligence Inc. All Rights Reserved
    '
    '*************************************************************************
    Private oParent As Object
    Public Function Create(ByVal iParent As Object, ByVal iParm As String) As spxfrFunction
        On Error Resume Next
        Dim oNew As spxfrFunction
        oNew = New spxfrFunction()
        Create = oNew
        oNew.Init(iParent, iParm)
    End Function
    Public Sub Init(ByVal iParent As Object, ByVal iParm As String)
        On Error Resume Next
        oParent = iParent
    End Sub
    Public Function Evaluate(ByVal strLHS As String, ByVal strRHS As String) As String
        On Error Resume Next
        Evaluate = ""
        Dim tcParm As vtools.TurboCollection
        Dim rDbl As Double
        Dim pWrk As vtools.ParmNode
        Dim lngI As Long
        tcParm = glb.UnStringParm(strRHS)
        rDbl = 0
        Do
            pWrk = tcParm.Find("P" & CStr(lngI))
            If Not pWrk Is Nothing Then
                If IsNumeric(pWrk.Item) Then
                    rDbl = rDbl + CDbl(pWrk.Item)
                End If
                lngI = lngI + 1
            End If
        Loop While Not pWrk Is Nothing
        Evaluate = CStr(rDbl)

        'Evaluate = Abs(CDbl(strRHS))
    End Function



End Class
