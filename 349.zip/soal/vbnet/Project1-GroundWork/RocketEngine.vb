'*************************************************************************
'Source Code,
'Framework, &
'Architecture :  Copyright (c) 1997-2000 Virtual Machine Intelligence Inc. All Rights Reserved
'
'*************************************************************************
Public Class RocketEngine
    Private tcItem As New vTools.TurboCollection()     ' define a properties collection
    Private Sub ExamineItem(ByVal strK As String, ByVal strV As String)
        On Error Resume Next

        Select Case strK
            Case "Warp"                                         'if "warp" is the key
                Item("Drive") = "Warp"                          'automatically set the required 
                Item("Navigation") = "Gravitational"            'default configuration
                Item("Inertia") = "Dampening=True"
        End Select

    End Sub
    Public Property Item(Optional ByVal strK As String = "") As String
        Get
            On Error Resume Next
            Dim strVx As String
            strVx = vbNullString                            'set to null in case Find() fails
            strVx = tcItem.Find(strK).Item                  'do the find - if found will return value
            Item = strVx                                    'return to calling proc

        End Get
        Set(ByVal Value As String)
            On Error Resume Next
            tcItem.Find(strK).Item = Value                  'find and set the property
            If Err.Number <> 0 Then                          'if not found, then need to add it
                tcItem.AddItem(Value, strK, strK)            'else if ok to add then add it
            End If
            ExamineItem(strK, Value)                            'and examine it further

        End Set
    End Property
    Public Sub New()
        Me.Item("Drive") = "TwinIon"                            'default properties for all starcraft classes
        Me.Item("Navigation") = "VFR"
        Me.Item("Inertia") = "Dampening=False"
    End Sub

End Class
