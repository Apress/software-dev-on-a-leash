'*************************************************************************
'Source Code,
'Framework, &
'Architecture :  Copyright (c) 1997-2002 Virtual Machine Intelligence Inc. All Rights Reserved
'*************************************************************************
Option Strict Off
Option Explicit On 
Option Compare Text
Module main
    Public glb As New vTools.glbAdapter()
    Public ConditionFactory As New vTools.conFactory()

    Public dbPer As Object
    Public glbM As glbMain
    Public mIfc As ifcAdapter
    Private tcFactory As New vTools.TurboCollection()

'NOTE: If the vTools reference fails, open the Solution explorer, 
' Expand the References treeview, click on vTools to remove it, then
' right-click on References, select Add Reference, then browse for the
' vTools.DLL in this project's directory and select it. 



    Public Sub main()
        On Error Resume Next
        StartupInit()
 


        Dim strD As String


        Dim tcP As New vTools.TurboCollection()

        tcP.AddItem("David", "Author")
        tcP.AddItem("Carla", "Spouse")
        tcP.AddItem("Valerie", "Editor")
        tcP.AddItem("Karen", "PowerBroker")
        tcP.AddItem("Jacob", "Son")
        tcP.AddItem("Callie", "Daughter")
        tcP.Dump("<>")

        strD = tcP.Item
        Debug.WriteLine(strD)
        strD = tcP.Item(strdelim:="<>", strdefaultkey:="TCDATA")
        Debug.WriteLine(strD)



        tcP.Clear()


        tcP.AddItem("David", "Author")
        tcP.Ref.tc = New vTools.TurboCollection()                    'nest one level down

        tcP.Ref.tc.AddItem("Carla", "Spouse")                 'add entry
        tcP.Ref.tc.Ref.tc = New vTools.TurboCollection()             'nest another level down
        tcP.Ref.tc.Ref.tc.AddItem("Jacob", "Son")             'add more
        tcP.Ref.tc.Ref.tc.AddItem("Callie", "Daughter")

        tcP.Dump("<>")                                        'show structured nesting

        strD = tcP.Item(strdelim:="<>", strdefaultkey:="TCDATA") 'show XML nesting
        Debug.WriteLine(strD)

        Dim tcA As New vTools.TurboCollection()

        tcA.UnStringXML(strD)                            'reproduce struct from XML
        tcA.Dump("<>")


        Dim pWrk As vTools.ParmNode
        pWrk = tcP.FindXML("Spouse")
        Debug.WriteLine("Item=" & pWrk.Item & "  ItemKey=" & pWrk.ItemKey)
        pWrk = tcP.FindXML("Son")
        Debug.WriteLine("Item=" & pWrk.Item & "  ItemKey=" & pWrk.ItemKey)


        pWrk = tcP.FindXML("Author")
        pWrk.tc.AddItem("Bryan", "Friend")                  'Add to David's
        pWrk = tcP.FindXML("Spouse")
        pWrk.tc.AddItem("Fran", "Friend")                   'Add to Carla's

        pWrk = tcP.FindXML("Son")
        pWrk.tc = New vTools.TurboCollection()
        pWrk.tc.AddItem("Chris", "Friend")             'add to Jacob's
        pWrk.tc.AddItem("Zach", "Friend")              'add to Jacob's
        pWrk.tc.AddItem("David", "Friend")             'add to Jacob's

        pWrk = tcP.FindXML("Daughter")
        pWrk.tc = New vTools.TurboCollection()
        pWrk.tc.AddItem("Abby", "Friend")               'add to Callie's
        pWrk.tc.AddItem("Blaire", "Friend")             'add to Callie's
        pWrk.tc.AddItem("Sara", "Friend")               'add to Callie's

        tcP.Dump("<>")

        pWrk = tcP.FindXML("Son")
        pWrk = pWrk.tc.FindXML("Friend")
        Debug.WriteLine("Item=" & pWrk.Item & "  ItemKey=" & pWrk.ItemKey)


        tcP.Clear()



        tcP.AddItem("David", "Author")
        tcP.Ref.RowInit = 5
        tcP.Ref.Row(0) = "01234"
        tcP.Ref.Row(1) = "David"
        tcP.Ref.Row(2) = "Southwest"
        tcP.Ref.Row(3) = "Author"
        tcP.Ref.Row(4) = "01/01/2000"
        tcP.AddItem("Valerie", "Editor")
        tcP.Ref.RowInit = 5
        tcP.Ref.Row(0) = "43210"
        tcP.Ref.Row(1) = "Valerie"
        tcP.Ref.Row(2) = "West Coast"
        tcP.Ref.Row(3) = "Editor"
        tcP.Ref.Row(4) = "08/01/2000"

        tcP.Dump("<>")

        strD = tcP.Item(strdelim:="<*>", strdefaultkey:="TCDATA")

        Debug.WriteLine(strD)


        tcA.Clear()
        tcA.UnStringXML(strD)                            'reproduce struct from XML
        tcA.Dump("<>")




' For Bonus Projects, see the file BonusProjects.txt in the VBNET/vUIMDemo directory. 
' add the content if the BonusProjects.txt file to the ProtoMe.txt file. Double-click
' on the vUIMDemo.exe, then wait for the program to start. When it does, hit Alt/Shift
' to bring up the Watch window, and in the top right textbox type "Call Bonus", then
' hit the Execute button and watch the log window for details. Check the content
' of BonusProjects.txt for comments on what you see in the log window.








    End Sub
      '
    'Startup Routine to call vTools as a DLL - we can invoke the same scenario for every
    ' DLL driven by the main() module - the StartupSubSys for glbMain allows for registering
    ' an unlimited number of third-party DLLs so we can quickly integrate new subsystems
    ' and provide plug-and-play thereafter.
    '

     Private Sub StartupInit()

      mIfc = New ifcAdapter()

      'glb = New vtools.glbAdapter()
      Dim strPath As String
      strPath = glb.Item("ResourcePath")
      glb.Item("Master") = "True"
      glb.Item("Context") = "ProjectSix"
      glb.IFCRef = mIfc
      glbM = New glbMain()
      mIfc.Init(glbM, "ProjectSix")
      mIfc.ifcCtrl = mIfc
      glbM.Action("Startup", "", mIfc)
      glb.Item("PKGSPEC") = "PKGSPEC.txt"
'Note that this startupsubsys function can also accept a tag-based CreateObject,
' giving use the ability to dynamically attach pre-integrated DLLs at run time,
' furthering the model's flexibility and minimizing its run-time footprint
     glbM.Action("StartupSubSys", "glb", glb) 'glb speaks for the vTools subsystem






 '     dbPer = glb.Ref("Per")

  '    dbPer.Action("Logon", ":")

    strPath = glb.Item("ResourcePath")


    End Sub
    Public Sub CloseMain()
        On Error Resume Next
    End Sub
    Public WriteOnly Property ifcCtrlRef() As Object
        Set(ByVal Value As Object)
            On Error Resume Next
            glb.IFCRef = Value
        End Set
    End Property

End Module
