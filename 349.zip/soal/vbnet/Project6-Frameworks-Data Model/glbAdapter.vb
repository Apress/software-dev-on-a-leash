Option Strict Off
Option Explicit On
Option Compare Text
Imports VB = Microsoft.VisualBasic
Friend Class glbAdapter

  '*************************************************************************
  'Source Code,
  'Framework, &
  'Architecture :  Copyright (c) 1997-2000 Virtual Machine Intelligence Inc. All Rights Reserved
  '
  '*************************************************************************

    Private strAppPath As String
    Private strBrowseContext As String
  Private blnMaster As Boolean
  Private lngUnique As Integer
  Private tcGlobal As TurboCollection
  Private tcGlobalRef As TurboCollection
  Private tcRuleQueue As New TurboCollection()
  Private blnRuleQueue As Boolean
  Private mIfc As ifcAdapter
  Private intUniqueInc As Short
  Private strLastUUID As String
  Private lngUnLoadMode As Integer
  Private strRunTimeID As String
  Private strRunTimeSvcID As String
  Private strMasterProcessID As String
  Private tcStringAdapter As New TurboCollection()
  Private tcStringAdapterAv As New TurboCollection()
  Private strAdapterCtr As Integer
  Private TextIOM As TextIO
  Public ConditionFactory As New conFactory()
  Private tcFactory As New TurboCollection()
  Private tcItem As New TurboCollection()
    Private blnShuttingDown As Boolean
    Dim cntErr As New cntAdapter()

    Public Function TextIOMgr() As TextIO
        On Error Resume Next
        If TextIOM Is Nothing Then

            If NextLevel() Then
                TextIOM = mIfc.Ref("TextIO")
            Else
                If TextIOM Is Nothing Then
                    TextIOM = New TextIO()
                    glb.Ref("TextIO") = TextIOM
                End If
            End If

        End If

        TextIOMgr = TextIOM


    End Function
    Public Sub ObserveItem(ByRef oSubscribe As Object, ByRef oPublish As Object, ByRef strInstructions As String)
        On Error Resume Next
        Dim strWrk As String

        Dim strRHS As String
        Dim strLHS As String

        Dim tcP As TurboCollection
        tcP = UnStringParm(strInstructions)

        strWrk = strWrk & FormatXML("Key", (tcP.Find("RHSKey").Item))
        strWrk = strWrk & FormatXML("Property", (tcP.Find("RHSProperty").Item))
        If Err.Number <> 0 Then
            strWrk = strWrk & FormatXML("Property", "Item")
        End If
        strWrk = strWrk & FormatXML("Event", (tcP.Find("Event").Item))
        strWrk = strWrk & FormatXML("Op", tcP.Find("Op").Item)
        If Err.Number = 0 Then
            strWrk = strWrk & FormatXML("ValueIn", (tcP.Find("ValueIn").Item))
            strWrk = strWrk & FormatXML("ValueIs", (tcP.Find("ValueIs").Item))
            strWrk = strWrk & FormatXML("Value", (tcP.Find("Value").Item))
        End If


        strRHS = FormatXML("RHS", strWrk)





        strWrk = FormatXML("Key", (tcP.Find("LHSKey").Item))
        strWrk = strWrk & FormatXML("Property", (tcP.Find("LHSProperty").Item))
        If Err.Number <> 0 Then
            strWrk = strWrk & FormatXML("Property", "Item")
        Else
            strWrk = strWrk & FormatXML("TargetRef", "Action")
        End If
        strLHS = FormatXML("LHS", strWrk)



        strWrk = FormatXML("%%%OBSERVE", strLHS & strRHS)


        If oSubscribe Is Nothing Then
            oPublish.Observe(strWrk) = Me
        Else
            oPublish.Observe(strWrk) = oSubscribe
        End If


    End Sub
    Private Sub ShutDown()
        On Error Resume Next
        Dim pwrk As ParmNode
        If blnShuttingDown Then Exit Sub
        blnShuttingDown = True

        If Not tcGlobalRef Is Nothing Then
            If tcGlobalRef.DataPresent Then
                tcGlobalRef.MoveFirst()
                Do
                    pwrk = tcGlobalRef.Ref
                    If Not pwrk.Ref Is Nothing Then
                        tcGlobalRef.Ref.Ref.Action("CloseMe")
                    End If
                    tcGlobalRef.MoveNext()
                Loop While tcGlobalRef.More
            End If
        End If

        tcGlobalRef.Clear()
        tcGlobalRef = Nothing
        tcGlobal = Nothing
        mIfc.Action("Shutdown")
        mIfc = Nothing
        tcStringAdapter = Nothing
        tcStringAdapterAv = Nothing
        TextIOM = Nothing
        tcFactory = Nothing
        tcItem = Nothing

        CloseMain()


    End Sub
    Private Function NextLevel() As Boolean
        On Error Resume Next
        NextLevel = False
        If mIfc Is Nothing Then Exit Function
        If blnMaster Then Exit Function
        NextLevel = True
    End Function

    Private Function UniqueIdx() As Integer
        On Error Resume Next
        Dim lngID As Integer
        If NextLevel() Then
            lngID = -1
            lngID = CInt(mIfc.Action("UniqueIDx"))
            If lngID = -1 Then
                lngID = lngUnique
                lngUnique = lngUnique + 1
            End If
            UniqueIdx = lngID
        Else
            UniqueIdx = lngUnique
            lngUnique = lngUnique + 1
        End If
    End Function
    Private Sub MoveFirst()
        On Error Resume Next
        If strBrowseContext = "ErrorHandler" Then
            cntErr.Action("MoveFirst")
        End If
    End Sub
    Private Function MoveNext() As String
        On Error Resume Next
        If strBrowseContext = "ErrorHandler" Then
            MoveNext = cntErr.Action("MoveNext")
        End If
    End Function
    Private Function GetRow() As String
        On Error Resume Next
        If strBrowseContext = "ErrorHandler" Then
            GetRow = cntErr.Action("GetRow")
        End If
    End Function
    Private Sub ErrorHandler(ByVal strErr As String, Optional ByVal oAction As Object = Nothing)
        On Error Resume Next
        Dim strTime As String
        Dim strComponent As String
        Dim strClass As String
        Dim strContext As String
        Dim strMsg As String
        Dim strDat As String
        Dim tcp As TurboCollection
        If Not cntErr.DataPresent Then
            cntErr.Action("Layout", "ErrTime|ErrComponent|ErrClass|ErrContext|ErrMsg")
            glb.Ref("cntErr") = cntErr
        End If


        strTime = glb.DateFormat(Now(), "YYYY-MM-DD HH24:MI:SS")
        If oAction Is Nothing Then                     'no object info available?
            strComponent = "Program"                   'just default both
            strClass = "NA"
        Else
            strComponent = TypeName(oAction.Ref("Top")) 'else get the reference's Top
            strClass = TypeName(oAction)                'and the class name too
        End If

        tcp = glb.UnStringParm(strErr)                  'decompose the compound message

        strContext = tcp.Find("Context").Item           'find and pull the context and message
        strMsg = tcp.Find("Message").Item
        strDat = strTime & "|" & strComponent & "|" & strClass & "|" & strContext & "|" & strMsg
        cntErr.Action("AddRow", strDat, Nothing)
        tcp = Nothing

    End Sub
    Public Function Action(ByRef strID As String, Optional ByRef strAction As String = "", Optional ByRef oAction As Object = Nothing) As String
        On Error Resume Next
        Dim tcP As TurboCollection

        If glb.IsXMLStr(strID) Then
            tcP = glb.UnStringXML(strID)
            strID = tcP.FindXML("Property").Item
            If strID = "Action" Then strID = tcP.FindXML("Key").Item
            tcP.Clear()
        End If


        Select Case strID
            Case "Pulse"
                glb.Ref("UIMgr").Action("Pulse")
                glb.Ref("Per").Action("Pulse")
                ExecRuleQueue()
            Case "ErrorHandler"
                ErrorHandler(strAction, oAction)
            Case "UniqueIDx"
                Action = CStr(UniqueIdx())
            Case "UniqueID"
                Action = UniqueID()
            Case "RuleQueue"
                AddRuleQueue(strAction, oAction)
            Case "FactoryClose"
                FactoryClose(strAction)
            Case "AddStartupToGlobal"
                Action = AddStartupToGlobal()
            Case "ShutDown"
                If NextLevel() Then
                    mIfc.Action("ShutDown")
                Else
                    ShutDown()
                End If
            Case "SendLaunchMsg"
                SendLaunchMessage(strAction, oAction)

            Case "SendSimpleMsg"
                SendSimpleMessage(strAction, oAction)

            Case "SendRawMsg"
                SendRawMessage(strAction, oAction)

            Case "SendComplexObject"
                SendComplexObject(strAction, oAction)
            Case "BrowseContext"
                strBrowseContext = strAction
            Case "GetRow"
                Action = GetRow()
            Case "MoveFirst"
                MoveFirst()
            Case "MoveNext"
                Action = MoveNext()



        End Select

    End Function
    Public Function ShellCall(ByRef strPath As String, ByRef strEXE As String) As String
        On Error Resume Next
        Dim retV As Double
        Dim strWrk As String
        Dim strQ As String
        strQ = """"
        strWrk = strPath
        If InStr(1, strWrk, " ", CompareMethod.Text) Then
            strWrk = strQ & strWrk & strQ
        End If
        strWrk = strWrk & strEXE
        retV = Shell(strWrk, AppWinStyle.NormalFocus)
        strWrk = CStr(retV)
        ShellCall = strWrk
    End Function
    Private Sub SendComplexObject(ByRef strAction As String, ByRef oAction As Object)
        On Error Resume Next
        Dim strF As String

        'Dim tcP As TurboCollection
        'Dim tcF As TurboCollection
        '
        '  Set tcP = glb.UnStringXML("TgtSubSys=UIMgr|Action=FormLaunch|")
        '  tcP.AddItem "None", "ActionData"
        '  Set tcF = glb.UnStringXML("Path=" & glb.Item("ResourcePath") & "ProtoMe" & "|ObjectName=ProtoMe|Instruction=UseCurrent|Mode=Display")
        '  Set tcP.Ref.tc = tcF
        '
        ' ' glb.Action "SendComplexObject", "", tcp
        '
        '
        'strF = tcP.Item(strDelim:="<*>", strDefaultKey:="Msg")
        '
        '

        strF = oAction.Item(strDelim:="<*>", strDefaultKey:="Msg")
        glb.Ref("Socket").Action("Send", strF)

    End Sub
    Private Sub SendRawMessage(ByRef strAction As String, ByRef oAction As Object)
        On Error Resume Next
        Dim strF As String
        Dim tcF As TurboCollection

        tcF = glb.UnStringXML(strAction)

        strF = tcF.Item(strDelim:="<>", strDefaultKey:="Msg")
        tcF.Clear()
        glb.Ref("Socket").Action("Send", strF)

    End Sub
    Private Sub SendSimpleMessage(ByRef strAction As String, ByRef oAction As Object)
        On Error Resume Next
        Dim strF As String
        Dim strA As StringAdapter
        strA = glb.NewStringAdapter
        Dim tcX As TurboCollection
        Dim tcP As TurboCollection
        Dim tcF As TurboCollection


        tcX = glb.UnStringXML(strAction)
        tcX.MoveFirst()
        tcP = New TurboCollection()
        tcF = tcP
        Do
            tcP.AddItem(tcX.Ref.Item, tcX.Ref.ItemKey)
            If tcX.Ref.ItemKey = "Action" Then
                tcP.AddItem("None", "ActionData")
                tcP.Ref.tc = New TurboCollection()
                tcP = tcP.Ref.tc
            End If
            tcX.MoveNext()
        Loop While tcX.More


        strF = tcF.Item(strDelim:="<>", strDefaultKey:="Msg")
        tcP.Clear()
        tcF.Clear()
        tcX.Clear()
        glb.Ref("Socket").Action("Send", strF)
        glb.OldStringAdapter(strA)



    End Sub
    Private Sub SendLaunchMessage(ByRef strAction As String, ByRef oAction As Object)
        On Error Resume Next
        Dim strF As String
        Dim strA As StringAdapter
        strA = glb.NewStringAdapter
        Dim tcX As TurboCollection
        Dim tcP As TurboCollection
        Dim tcF As TurboCollection


        strF = "TgtSubSys=UIMgr|Action=FormLaunch"
        strA.Parse(strAction, "|")
        strF = strF & "|Path=" & strA.Item & strA.Item(CStr(1))
        strF = strF & "|ObjectName=" & strA.Item(CStr(1))
        strF = strF & "|Instructions=" & strA.Item(CStr(2))
        strF = strF & "|Mode=" & strA.Item(CStr(3))


        tcX = glb.UnStringXML(strF)
        tcX.MoveFirst()
        tcP = New TurboCollection()
        tcF = tcP
        Do
            tcP.AddItem(tcX.Ref.Item, tcX.Ref.ItemKey)
            If tcX.Ref.ItemKey = "Action" Then
                tcP.AddItem("None", "ActionData")
                tcP.Ref.tc = New TurboCollection()
                tcP = tcP.Ref.tc
            End If
            tcX.MoveNext()
        Loop While tcX.More


        strF = tcF.Item(strDelim:="<>", strDefaultKey:="Msg")
        tcP.Clear()
        tcF.Clear()
        tcX.Clear()
        glb.Ref("Socket").Action("Send", strF)
        glb.OldStringAdapter(strA)


    End Sub

    Private Sub AddRuleQueue(ByRef strIn As String, ByRef oAction As Object)
        On Error Resume Next
        If blnRuleQueue Then
            Do
                System.Windows.Forms.Application.DoEvents()
            Loop While blnRuleQueue
        End If
        blnRuleQueue = True
        tcRuleQueue.AddItem(strIn, strIn, strIn)
        tcRuleQueue.Ref.obj = oAction
        blnRuleQueue = False
        'ExecRuleQueue
    End Sub
    Private Sub ExecRuleQueue()
        If blnRuleQueue Then Exit Sub
        On Error Resume Next
        If Not tcRuleQueue.DataPresent Then Exit Sub
        blnRuleQueue = True
        Dim pwrk As ParmNode
        pwrk = tcRuleQueue.Top
        tcRuleQueue.Remove(pwrk)
        pwrk.obj.Action("Execute", pwrk.Item)
        pwrk = Nothing
        blnRuleQueue = False
    End Sub
    Public Sub DebugOut(Optional ByRef strS As String = "")
        On Error Resume Next
#If CONSOLIDATED Then
        mIfc.Action("Print", strS)
        Exit Sub
#End If
        If NextLevel() Then
            mIfc.Action("Print", strS)
        Else
            System.Diagnostics.Debug.WriteLine(strS)
        End If
    End Sub
    Public Property IFCRef() As Object
        Get
            On Error Resume Next
            IFCRef = mIfc
        End Get
        Set(ByVal Value As Object)
            On Error Resume Next
            mIfc = Value
        End Set
    End Property
    Public Sub DoEvents()
        On Error Resume Next
        System.Windows.Forms.Application.DoEvents()
    End Sub
    Public Property Ref(ByVal strKey As String) As Object
        Get
            On Error Resume Next

            Ref = Nothing
            Dim pwrk As ParmNode
            If NextLevel() Then
                Ref = mIfc.Ref(strKey)
            Else
                If tcGlobalRef Is Nothing Then Exit Property
                pwrk = tcGlobalRef.Find(strKey)
                If pwrk Is Nothing Then Exit Property
                Ref = pwrk.Ref
            End If
        End Get
        Set(ByVal Value As Object)
            On Error Resume Next
            If Value Is Nothing Then Exit Property
            Dim pwrk As ParmNode
            If NextLevel() Then
                mIfc.Ref(strKey) = Value
            Else
                If tcGlobalRef Is Nothing Then tcGlobalRef = New TurboCollection()
                pwrk = tcGlobalRef.Find(strKey)
                If pwrk Is Nothing Then
                    tcGlobalRef.AddItem("", strKey, strKey)
                    pwrk = tcGlobalRef.Ref
                End If
                pwrk.Ref = Value
            End If
        End Set
    End Property
    Public Property Item(ByVal strKey As String) As String
        Get
            On Error Resume Next
            Dim strK As String




            strK = strKey
            If NextLevel() Then
                Item = mIfc.Action("GlobalValueGet", strKey)
                Exit Property
            End If


            Dim tcP As TurboCollection
            If InStr(1, strK, "</", CompareMethod.Text) > 0 Then
                tcP = UnStringXML(strKey)
                strK = tcP.Find("Key").Item

            End If



            Dim strA As String
            Dim strB As StringAdapter
            Dim strVal As String
            strVal = CStr(Nothing)


            strA = CStr(strK)
            If InStr(1, strA, "GLOBAL", CompareMethod.Text) > 0 Then
                strB = NewStringAdapter()
                strA = strB.ReplaceSubString(strA, "GLOBAL(", "")
                strA = strB.ReplaceSubString(strA, """", "")
                strA = strB.ReplaceSubString(strA, ")", "")
                OldStringAdapter(strB)
                strA = Trim(strA)
            End If

            strVal = "@@NOT FOUND@@"
            strVal = tcGlobal.Find(strA).Item
            If strVal = "@@NOT FOUND@@" Then '
                '  If strA = "IPCONFIG" Then
                '     vntVal = objUIMgr.IPConfig
                '  Else
                strVal = Environ(CStr(strA))
                '  End If
                If strVal <> "@@NOT FOUND@@" And strVal <> vbNullString Then GlobalValueInsert(CStr(strA), strVal)
                strVal = tcGlobal.Find(strA).Item


            End If




            If strKey <> "Status" And strKey <> "Context" And strKey <> "Master" And strKey <> "DBVendor" Then
                DebugOut("Global Value [" & strA & "] Was [" & strVal & "]")
                'If strA = "ActionFailed" Then
                ' Debug.Print
                'End If
            End If

            If strVal = "@@NOT FOUND@@" Then strVal = vbNullString


            Item = strVal

        End Get
        Set(ByVal Value As String)
            On Error Resume Next
            '  Dim lngI As Long
            Dim strV As String
            strV = Value
            If strKey = "Master" And Value = "True" Then blnMaster = True
            'If strKey = "runTimeid" Then
            'Debug.Print
            'End If

            '  lngI = InStr(1, strV, "=", vbTextCompare)
            '  If lngI > 0 Then strV = Mid(strV, lngI + 1)

            If Not NextLevel() Then
                GlobalValueInsert(strKey, strV)
                'DoEvents
            Else
                mIfc.Action("GlobalValueLet", strKey & "=" & strV)
            End If
        End Set
    End Property
    Public ReadOnly Property ifcMain() As Object
        Get
            On Error Resume Next
            ifcMain = mIfc
        End Get
    End Property
    '************************************************************************
    Public ReadOnly Property ObserversOn() As Boolean
        Get
            ObserversOn = True
        End Get
    End Property
    'Public Property Let Item(strK As String, strV As String)
    '  On Error Resume Next
    '  Dim pWrk As ParmNode
    '  If tcItem Is Nothing Then Set tcItem = New TurboCollection
    '  Set pWrk = tcItem.Find(strK)
    '  If pWrk Is Nothing Then
    '    tcItem.AddItem strV, strK, strK
    '  Else
    '    pWrk.Item = strV
    '  End If
    'End Property
    'Public Property Get Item(strK As String) As String
    '  On Error Resume Next
    '  Item = tcItem.Find(strK).Item
    'End Property
    Private Sub GlobalValueInsert(ByRef strKey As String, ByRef strVal As String)
        Dim pwrk As Object
        On Error Resume Next
        If tcGlobal Is Nothing Then tcGlobal = New TurboCollection()
        pwrk = tcGlobal.Find(strKey)
        If pwrk Is Nothing Then
            tcGlobal.AddItem(strVal, strKey, strKey)
        Else
            pwrk.Item = strVal
        End If

        If strKey = "MouseHourGlass" Then
            If NextLevel() Then
                mIfc.Action("GlobalValueLet", strKey)
            Else

            End If

        ElseIf strKey = "MouseDefault" Then
            If NextLevel() Then
                mIfc.Action("GlobalValueLet", strKey)
            Else

            End If


        ElseIf strKey = "Status" Then
            If NextLevel() Then
                mIfc.Action("Status", strVal)
            ElseIf Not tcGlobalRef Is Nothing Then
                glb.Ref("Socket").Item("Status") = strVal
                glb.Ref("UIMgr").Item("Status") = strVal
            End If
        End If
    End Sub
    'Public Function GlobalValueRef(strKey As String) As Object
    '  On Error Resume Next
    '  Set GlobalValueRef = Nothing
    '  Set GlobalValueRef = tcGlobal.Find(vntKey)
    'End Function
    Public Sub CollectionClear(ByRef colWrk As Collection, Optional ByRef vntObj As Object = Nothing)
        On Error Resume Next
        Dim lngI As Integer
        Dim vObj As Object
        If colWrk Is Nothing Then Exit Sub

        If IsNothing(vntObj) Then
            Do
                colWrk.Remove((1))
            Loop While colWrk.Count() > 0
            Exit Sub
        End If

        lngI = 1
        For Each vObj In colWrk
            If vObj Is vntObj Then
                colWrk.Remove(lngI)
                Exit Sub
            End If
            lngI = lngI + 1
        Next vObj
    End Sub
    '************************************************************************
    Public Function ReStringParm(ByRef tcParm As TurboCollection) As String
        On Error Resume Next
        Dim strW As String
        strW = vbNullString
        If tcParm Is Nothing Then Exit Function
        If Not tcParm.DataPresent Then Exit Function
        tcParm.MoveFirst()
        Do
            If Len(strW) > 0 Then strW = strW & "|"
            strW = strW & tcParm.Ref.ItemKey & "=" & tcParm.Ref.Item
            tcParm.MoveNext()
        Loop While tcParm.More
        ReStringParm = strW

    End Function
    Private Sub AppendXML(ByRef tcW As TurboCollection, ByRef tcP As TurboCollection)
        On Error Resume Next


    End Sub
    '************************************************************************
    Public Function UnStringXML(ByRef strIn As String, Optional ByRef strLevel As String = "<*>") As TurboCollection
        On Error Resume Next


        Dim tcWrk As TurboCollection

        If InStr(1, strIn, "</", CompareMethod.Text) > 0 Then
            tcWrk = New TurboCollection()
            tcWrk.UnStringXML(strIn, strLevel)
        Else
            tcWrk = UnStringParm(strIn)
        End If

        UnStringXML = tcWrk


        '''
        '''
        '''  Dim lngS As Long
        '''  Dim lngN As Long
        '''  Dim lngI As String
        '''  Dim lngE As Long
        '''  Dim strBod As String
        '''  Dim strItem As String
        '''  Dim strKey As String
        '''  Dim strA As StringAdapter
        '''  Set UnStringXML = Nothing
        '''  Dim tcP As TurboCollection
        '''  Dim tcW As TurboCollection
        '''  Dim pWrk As ParmNode
        '''
        '''  If strIn = vbNullString Then Exit Function
        '''  'Format is  <BODY> DATA </BODY>"
        '''  ' Data body is <KEY1>DATA1</KEY1><KEY2>DATA2</KEY2>....
        '''  Dim strWrk As String
        '''  strWrk = Trim(strIn)
        '''  lngI = InStr(1, strWrk, "<", vbTextCompare)
        '''  strWrk = Trim(Mid(strWrk, lngI))
        '''
        '''  Set tcW = New TurboCollection
        '''
        '''  'STRIKE the string into its elemental parts
        '''  '  where Tag1
        '''  '          Tag2
        '''  '           Tag3 body /Tag3
        '''  '          /Tag2
        '''  '         /Tag1
        '''
        '''  Do
        '''    If Mid(strWrk, 1, 1) = "<" Then
        '''      lngI = InStr(1, strWrk, ">", vbTextCompare)
        '''      tcW.AddItem Mid(strWrk, 1, lngI)
        '''      strWrk = Mid(strWrk, lngI + 1)
        '''    Else
        '''      lngI = InStr(1, strWrk, "<", vbTextCompare)
        '''      tcW.AddItem Mid(strWrk, 1, lngI - 1)
        '''      strWrk = Mid(strWrk, lngI)
        '''    End If
        '''
        '''
        '''  Loop While lngI > 0
        '''
        '''
        '''  'Now find all tag pairs - each on wiil reference its mate
        '''  '   <tag1> points forward to its </tag1>
        '''  '   </tag1> points backward to its <tag1>
        '''  '
        '''
        '''
        '''  tcW.MoveFirst
        '''  Do
        '''     strItem = tcW.Ref.Item
        '''     If Mid(strItem, 1, 2) = "</" Then
        '''       strItem = "<" & Mid(strItem, 3)
        '''       Set pWrk = tcW.Ref
        '''       Do
        '''       tcW.MovePrevious
        '''       Loop While strItem <> tcW.Ref.Item
        '''       If strItem = tcW.Ref.Item Then
        '''         Set tcW.Ref.Ref = pWrk
        '''         Set pWrk.Ref = tcW.Ref
        '''       End If
        '''
        '''       Set tcW.Ref = pWrk
        '''
        '''     End If
        '''
        '''  tcW.MoveNext
        '''  Loop While tcW.More
        '''
        '''
        '''
        '''
        '''
        '''
        ''''  tcW.MoveFirst
        ''''  Do
        ''''    If Not tcW.Ref.Ref Is Nothing Then
        ''''    Debug.Print tcW.Ref.Item & " " & tcW.Ref.Ref.Item
        ''''    End If
        ''''
        ''''  tcW.MoveNext
        ''''  Loop While tcW.More
        '''
        '''
        '''
        '''
        '''
        '''
        '''
        '''
        '''  tcW.MoveFirst
        '''  Set tcP = New TurboCollection
        '''
        '''  Do
        '''
        '''   strItem = tcW.Ref.Item
        '''   If Mid(strItem, 1, 1) = "<" And Mid(strItem, 1, 2) <> "</" Then
        '''
        '''     tcP.AddItem "", Mid(strItem, 2, Len(strItem) - 2)
        '''     Set tcP.Ref.tc = New TurboCollection
        '''     AppendXML tcW, tcP.Ref.tc
        '''
        '''
        '''   End If
        '''
        '''
        '''   If strItem = "<ParmNode>" Then
        '''      tcP.Add
        '''      tcP.Ref.UnStringXML tcW
        '''   End If
        '''
        '''  tcW.MoveNext
        '''  Loop While tcW.More
        '''
        '''
        '''
        '''
        '''
        '''
        '''
        '''
        '''
        '''
        '''  lngI = InStr(1, strWrk, ">", vbTextCompare)
        '''  If lngI = 0 Then Exit Function
        '''  strBod = Mid(strWrk, 2, lngI - 2)
        '''  strWrk = Mid(strWrk, lngI + 1)
        '''
        '''
        '''
        '''
        '''
        '''  lngE = InStr(1, strWrk, "</" & strBod & ">", vbTextCompare)
        '''  If lngE = 0 Then Exit Function
        '''  If lngE = 1 Then Exit Function
        '''  lngE = lngE - 1
        '''  strWrk = Mid(strWrk, 1, lngE)
        '''
        '''  'Now have the key/tag string to unhook
        '''  Dim strK As String
        '''  Dim strV As String
        '''  lngS = 1
        '''
        '''  Set tcP = New TurboCollection
        '''
        '''  Do
        '''  lngI = InStr(1, strWrk, "<", vbTextCompare)
        '''  If lngI = 0 Then Exit Do
        '''  lngE = InStr(1, strWrk, ">", vbTextCompare)
        '''
        '''  strK = Mid(strWrk, lngI + 1, lngE - 2)
        '''  strWrk = Mid(strWrk, lngE + 1)
        '''  lngN = 1
        '''  Do
        '''
        '''  lngS = InStr(lngN, strWrk, "<" & strK & ">", vbTextCompare)
        '''  If lngS = 0 Then
        '''    lngI = InStr(lngN, strWrk, "</" & strK & ">", vbTextCompare)
        '''    strV = Mid(strWrk, 1, lngI - 1)
        '''    Exit Do
        '''  Else
        '''    lngN = InStr(lngS, strWrk, "</" & strK & ">", vbTextCompare) + Len(strK) + 2
        '''  End If
        '''  Loop While lngS > 0
        '''
        '''
        '''  tcP.AddItem strV, strK, strK
        '''
        '''
        '''  lngI = InStr(lngI + 1, strWrk, ">", vbTextCompare)
        '''  strWrk = Mid(strWrk, lngI + 1)
        '''
        '''  Loop While lngI > 0
        '''
        '''
        ''''  Set UnStringXML = tcP
        ''''  tcP.MoveFirst
        ''''  Do
        ''''   strWrk = tcP.Ref.Item
        ''''   strKey = tcP.Ref.ItemKey
        ''''   If InStr(1, strWrk, "</", vbTextCompare) > 0 Then
        ''''     If InStr(1, strWrk, strKey, vbTextCompare) > 0 And _
        '''''          tcP.Ref.ItemKey = "Key" Then
        ''''       tcP.Ref.ItemKey = "Key_" & glb.Action("UniqueIdx")
        ''''     End If
        ''''     If InStr(1, strWrk, "<ParmNode>", vbTextCompare) = 1 Then
        ''''       tcP.Ref.UnStringXML strWrk
        ''''
        ''''     ElseIf InStr(1, strWrk, strKey, vbTextCompare) = 2 Then
        ''''       lngI = InStr(1, strWrk, "</" & strKey & ">", vbTextCompare)
        ''''       lngS = InStr(2, strWrk, ">", vbTextCompare) + 1
        ''''       tcP.Ref.Item = Mid(strWrk, lngS, lngI - lngS)
        ''''       lngI = InStr(lngI + 1, strWrk, ">", vbTextCompare) + 1
        ''''       strWrk = Mid(strWrk, lngI)
        ''''       Set tcP.Ref.tc = UnStringXML(strWrk)
        ''''       Debug.Print
        ''''     Else
        ''''      Set tcP.Ref.tc = UnStringXML(glb.FormatXML(strKey, strWrk))
        ''''     End If
        ''''   End If
        ''''  tcP.MoveNext
        ''''  Loop While tcP.More
        '''
        '''
        '''
        '''
        '''
        '''
        '''  'tcp.Dump strK:="<>"
        '''
        '''
        '''


    End Function
    Public Function IsXMLStr(ByRef strIn As String) As Boolean
        On Error Resume Next
        IsXMLStr = False
        If InStr(1, strIn, "</", CompareMethod.Text) > 0 Then IsXMLStr = True
    End Function
    Public Function FormatXML(ByRef strK As String, ByRef strV As String) As String
        On Error Resume Next
        Dim strKey As String
        strKey = strK
        If Mid(strKey, 1, 3) = "%%%" Then
            strKey = Mid(strKey, 4)
            strKey = UniqueIdx() & strKey
        End If

        strKey = "<" & strKey & ">" & strV & "</" & strKey & ">"
        FormatXML = strKey
    End Function
    Public Function UnStringParm(ByRef strIn As String, Optional ByRef strDefaultKey As String = "", Optional ByRef strDelim As String = "|") As TurboCollection
        On Error Resume Next
        Dim tcL As TurboCollection

        '  If InStr(1, strIn, "{", vbTextCompare) > 0 Then
        '   Debug.Print
        '  End If


        UnStringParm = Nothing
        If strIn = vbNullString Then Exit Function
        tcL = New TurboCollection()
        UnStringParm = tcL
        Dim strD As String
        Dim strA As StringAdapter
        Dim strB As StringAdapter
        strA = NewStringAdapter()
        strB = NewStringAdapter()
        Dim strW As String
        Dim strWrk As String
        Dim blnAsKey As Boolean

        strD = strDefaultKey
        If strD = vbNullString Then strD = "Default"
        blnAsKey = (strD = "%%%AsKey")
        If blnAsKey Then strD = vbNullString


        Dim lngI As Integer
        Dim lngS As Integer
        Dim lngR As Integer
        lngS = 1
        strWrk = Trim(strIn)

        Do

            lngI = InStr(lngS, strWrk, strDelim, CompareMethod.Text)
            '  lngR = InStr(lngS, strWrk, "{", vbTextCompare)
            '  If lngR > 0 Then
            '  If lngR < lngI Then
            '    lngI = InStr(lngS, strWrk, "}", vbTextCompare)
            '    lngI = lngI + 1
            '  End If
            '  End If

            If lngI > 0 Then
                strW = Mid(strWrk, lngS, lngI - lngS)
                lngS = lngI + 1
            Else
                strW = Mid(strWrk, lngS)
            End If


            strW = Trim(strW)
            If strW <> vbNullString Then
                lngR = InStr(1, strW, "=", CompareMethod.Text)

                If lngR > 0 Then
                    If blnAsKey Then
                        tcL.AddItem(Mid(strW, 1, lngR - 1), Mid(strW, lngR + 1))
                    Else
                        tcL.AddItem(Mid(strW, lngR + 1), Mid(strW, 1, lngR - 1))
                    End If
                Else
                    If blnAsKey Then
                        tcL.AddItem(strD, strW)
                    Else
                        tcL.AddItem(strW, strD)
                    End If
                End If

            End If

        Loop While lngI <> 0


        tcL.MoveFirst()




        OldStringAdapter(strA)
        OldStringAdapter(strB)
    End Function
    '************************************************************************
    Public Sub OldStringAdapter(ByRef pStr As StringAdapter)
        On Error Resume Next
        If pStr.src <> "NewSA" Then Exit Sub
        Dim pwrk As ParmNode
        pwrk = tcStringAdapter.Find(pStr.ID)
        If pwrk Is Nothing Then Exit Sub
        tcStringAdapter.Remove(pwrk)
        tcStringAdapterAv.Add(pwrk)
    End Sub
    '************************************************************************
    Public Function NewStringAdapter() As StringAdapter
        On Error Resume Next
        Dim pwrk As ParmNode
        Dim strA As StringAdapter
        If tcStringAdapterAv.DataPresent Then
            pwrk = tcStringAdapterAv.Top
            tcStringAdapterAv.Remove(pwrk)
        Else
            pwrk = New ParmNode()
            pwrk.obj = New StringAdapter()
            pwrk.obj.ID = CStr(strAdapterCtr)
            strAdapterCtr = strAdapterCtr + 1

        End If

        tcStringAdapter.Add(pwrk)
        tcStringAdapter.Ref.ItemKey = pwrk.obj.ID
        pwrk.obj.Clear()
        pwrk.obj.src = "NewSA"
        NewStringAdapter = pwrk.obj

        ' DebugOut "New Str Adp " & tcStringAdapter.Count - tcStringAdapterAv.Count


    End Function
    '************************************************************************
    Public Sub MessageOk(ByRef strMsg As String, ByRef strCtx As String)
        MsgBox(strMsg, MsgBoxStyle.OKOnly, glb.Item("ProductName") & " " & strCtx)
    End Sub
    '************************************************************************
    Public Function MessageYesNo(ByRef strMsg As String, ByRef strCtx As String) As Object
        Dim retV As MsgBoxResult
        retV = MsgBox(strMsg, MsgBoxStyle.YesNo, glb.Item("ProductName") & " " & strCtx)
        MessageYesNo = retV
    End Function
    Public Function UniqueID() As String
        On Error Resume Next
        Dim strWrk As String
        Dim lngI As Integer
        Dim lngS As Integer
        lngI = CInt(Format(Now, "DD"))
        lngI = lngI + (CInt(Format(Now, "MM")) * 16)
        lngI = lngI + (CInt(Format(Now, "YY")) * 64)
        strWrk = Hex(lngI)
        lngS = CInt(Format(Now, "SS"))
        lngS = lngS + (CInt(Mid(Format(Now, "HHMM"), 3)) * 64)
        lngS = lngS + (CInt(Mid(Format(Now, "HHMM"), 1, 2)) * 128)
        strWrk = strWrk & Hex(lngS)
        If Len(strWrk) < 8 Then
            Do
                strWrk = strWrk & "F"
            Loop While Len(strWrk) < 8
        End If

        UniqueID = strWrk


    End Function
    Public Function UUIDGen() As String
        Dim oT As TextIO
        Dim strWrk As String
        Dim pwrk As ParmNode
        Dim strU As String
        Dim strT As String
        Dim strR As String
        Dim dRet As Double
        Dim lngX As Integer

        On Error Resume Next
        Err.Clear()
        oT = TextIOMgr()

        strR = glb.Item("ResourcePath")
        'strR = Mid(strR, 1, Len(strR) - 1)
        If InStr(1, strR, " ", CompareMethod.Text) > 0 Then
            strR = """" & strR & """"
        End If
        strU = strR & "uuidgen.exe -o" & strR & "LASTUUID.Txt"
        strT = glb.Item("ResourcePath") & "LASTUUID.Txt"

        ' strU = """" & objB.GlobalValue("ResourcePath") & "uuidgen.exe" & """"



        ' lngX = 0
        ' Do

        dRet = Shell(strU, AppWinStyle.Hide)


        pwrk = oT.OpenInputFile(strT)
        strWrk = oT.Item(pwrk)
        oT.CloseFile(pwrk)

        ' lngX = lngX + 1
        'If lngX > 3 Then Exit Do
        ' Loop While strWrk = strLastUUID

        'DebugOut lngX & "  attempts"
        strLastUUID = strWrk

        UUIDGen = strWrk

    End Function
    ''************************************************************************
    'Public Property Let GlobalValue(strK As String, strV As String)
    '  On Error Resume Next
    '  mIfc.Action "GlobalValueLet", strK & "=" & strV
    'End Property
    ''************************************************************************
    'Public Property Get GlobalValue(strK As String) As String
    '  On Error Resume Next
    '  GlobalValue = mIfc.Action("GlobalValueGet", strK)
    'End Property
    Public Sub New()
        MyBase.New()
        On Error Resume Next
        intUniqueInc = 0
        Me.Item("ActionSuccess") = CStr("0")
        Me.Item("ActionFailed") = CStr("1")
        Me.Item("ActionNotFound") = CStr("2")
        Me.Item("ActionIncomplete") = CStr("1000")
        Me.Item("ActionQuit") = CStr("1100")
        Me.Item("ResourcePath") = Me.AppPath & "..\"


    End Sub
    Public Function ColorCon(ByRef strColor As String) As Integer
        Select Case CStr(strColor)
            Case "Yellow"
                ColorCon = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow)
            Case "Blue"
                ColorCon = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Blue)
            Case "DarkBlue"
                ColorCon = System.Drawing.ColorTranslator.ToOle(System.Drawing.SystemColors.Highlight)
            Case "Green"
                ColorCon = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Lime)
            Case "Red"
                ColorCon = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red)
            Case "White"
                ColorCon = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White)
            Case "Cyan"
                ColorCon = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Cyan)
            Case "Black"
                ColorCon = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black)
            Case "Gray"
                ColorCon = System.Drawing.ColorTranslator.ToOle(System.Drawing.SystemColors.Control)
            Case Else
                ColorCon = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black)
        End Select
    End Function
    Public Function ArrToStr(ByRef arrV() As String, Optional ByRef strDelim As String = "|") As String
        On Error Resume Next
        Dim strWrk As String
        strWrk = vbNullString
        ArrToStr = strWrk
        Dim lngL As Integer
        Dim lngU As Integer
        Dim lngS As Integer
        lngS = LBound(arrV)
        lngL = lngS
        If Err.Number <> 0 Then Exit Function
        lngU = UBound(arrV)
        If Err.Number <> 0 Then Exit Function
        Do
            If lngL <> lngS Then strWrk = strWrk & strDelim
            strWrk = strWrk & arrV(lngL)
            lngL = lngL + 1
        Loop While lngL <= lngU
        ArrToStr = strWrk
    End Function
    Public Sub StrToArr(ByRef arrV() As String, ByRef strValue As String, Optional ByRef strDelim As String = "|")
        On Error Resume Next
        Dim strA As StringAdapter
        If strValue = vbNullString Then
            ReDim arrV(0)
            Exit Sub
        End If
        strA = NewStringAdapter()
        strA.Parse(strValue, strDelim)
        Dim lngL As Integer
        lngL = 0
        ReDim arrV(strA.Count - 1)
        If Err.Number <> 0 Then Exit Sub
        strA.MoveFirst()
        Do
            arrV(lngL) = strA.Item
            lngL = lngL + 1
            strA.MoveNext()
        Loop While strA.More
        OldStringAdapter(strA)
    End Sub

    '*********************************************************************
    '****** FACTORY *****************
    Public Function RegisterFactory(ByRef strID As String, ByRef strDat As String, ByRef oFact As Object) As Short
        On Error Resume Next
        Dim pwrk As ParmNode
        pwrk = tcFactory.Find(strID)
        If pwrk Is Nothing Then
            tcFactory.AddItem(strDat, strID, strID)
            tcFactory.Ref.Ref = oFact
            tcFactory.Ref.obj = New TurboCollection()
        Else
            pwrk.Ref = oFact
        End If
    End Function
    Public Function FactoryAction(ByRef strID As String, Optional ByRef strData As String = "", Optional ByRef oAction As Object = Nothing) As Object
        On Error Resume Next
        FactoryAction = Nothing
        Dim pwrk As ParmNode
        pwrk = tcFactory.Find(strID)
        If pwrk Is Nothing Then Exit Function
        FactoryAction = pwrk.Ref.Action(strData, , oAction)
    End Function
    'Public Function GetSocketAdp(strSocketName As String) As sktAdapter
    '  On Error Resume Next
    '  Set GetSocketAdp = Nothing
    '  Set GetSocketAdp = oSocketFactory.GetSocketAdp(strSocketName)
    'End Function
    Private Sub FactoryClose(Optional ByRef strID As String = "")
        On Error Resume Next
        Dim pwrk As ParmNode
        If Not tcFactory.DataPresent Then Exit Sub
        If strID <> vbNullString Then
            pwrk = tcFactory.Find(strID)
            If pwrk Is Nothing Then Exit Sub
            pwrk.Ref.Action("Close")
            tcFactory.Remove(pwrk)
            Exit Sub
        End If

        With tcFactory
            .MoveFirst()
            Do
                tcFactory.Ref.Ref.Action("Close")
                tcFactory.Ref.obj.Clear()
                .MoveNext()
            Loop While .More
        End With
        tcFactory.Clear()


    End Sub
    'Public Function FactorySocketRegister(strKey As String) As sktAdapter
    '  On Error Resume Next
    '  Set SocketRegister = tcSockets.Find(strKey)
    'End Function
    Public Function FactoryRef(ByRef strID As String, ByRef strDat As String) As Object
        On Error Resume Next
        Dim pwrk As ParmNode
        FactoryRef = Nothing
        pwrk = tcFactory.Find(strID)
        If pwrk Is Nothing Then Exit Function
        pwrk = pwrk.Ref.obj.Find(strDat)
        If pwrk Is Nothing Then Exit Function
        FactoryRef = pwrk.Ref
    End Function
    Public Sub FactoryRegister(ByRef strID As String, ByRef strData As String, ByRef oAction As Object)
        On Error Resume Next
        Dim pwrk As ParmNode
        Dim tcR As TurboCollection
        If oAction Is Nothing Then Exit Sub
        pwrk = tcFactory.Find(strID)
        If pwrk Is Nothing Then Exit Sub
        tcR = pwrk.Ref.obj
        tcR.AddItem(oAction.Item("Name"), oAction.Item("ID"))
        tcR.Ref.Ref = oAction
        tcR.AddItem(oAction.Item("ID"), oAction.Item("Name"))
        tcR.Ref.Ref = oAction
    End Sub
    Public Function StartupModeSetup() As String
        On Error Resume Next
        Dim strTok As String
        Dim strA As StringAdapter
        Dim strCommand As String
        Dim intI As Short


        glb.Item("StartupMode") = "IPCClient"
        '  strTok = Item("RunTimeID")
        '  If strTok = vbNullString Then
        '     Item("RunTimeID") = Mid(Item("vMachMasterID"), 1, 8) '  "6ea74d30"
        '  End If


        strCommand = VB.Command()
        If strCommand = vbNullString Then Exit Function


        strA = NewStringAdapter()
        strA.Parse(strCommand, ",")

        Do

            strTok = strA.Item

            If InStr(1, strTok, "MODE=SVC", CompareMethod.Text) > 0 Then
                glb.Item("StartupMode") = "IPCService"

            ElseIf InStr(1, strTok, "MODE=CON", CompareMethod.Text) > 0 Then
                glb.Item("StartupMode") = "IPCDBConnect"


            ElseIf InStr(1, strTok, "UNLOAD=TRUE", CompareMethod.Text) > 0 Then
                lngUnLoadMode = 1

            ElseIf InStr(1, strTok, "UNLOAD=FALSE", CompareMethod.Text) > 0 Then
                lngUnLoadMode = 0

            ElseIf InStr(1, strTok, "UNLOAD=HIDE", CompareMethod.Text) > 0 Then
                lngUnLoadMode = 2


            ElseIf InStr(1, strTok, "SRC=", CompareMethod.Text) > 0 Then
                intI = InStr(1, strTok, "SRC=", CompareMethod.Text)
                intI = intI + 4
                glb.Item("MasterProcessID") = Mid(strTok, intI)


            ElseIf InStr(1, strTok, "ID=", CompareMethod.Text) > 0 Then
                intI = InStr(1, strTok, "ID=", CompareMethod.Text)
                intI = intI + 3
                glb.Item("RunTimeID") = Mid(strTok, intI)

            ElseIf InStr(1, strTok, "STARTUP=", CompareMethod.Text) > 0 Then
                intI = InStr(1, strTok, "STARTUP=", CompareMethod.Text)
                intI = intI + Len("Startup=")
                glb.Item(Mid(strTok, 1, intI - 2)) = Mid(strTok, intI)



            End If



            strA.MoveNext()
        Loop While strA.More


        OldStringAdapter(strA)


        StartupModeSetup = glb.Item("StartupMode")


    End Function
    Public Function AppPath() As String
        On Error Resume Next
        If strAppPath <> Nothing Then
            AppPath = strAppPath
            Exit Function
        End If
        Dim strA As StringAdapter
        Dim strK As String
        strA = Me.NewStringAdapter
        strK = System.Reflection.Assembly.GetExecutingAssembly.Location
        strA.Parse(strK, "\")
        strA.MoveLast()
        strA.Item = vbNullString
        strA.RemoveNullStrings()
        strK = strA.Concat("\")
        Me.OldStringAdapter(strA)
        strK = strK & "\"   '"""" & strK & """" & "\"
        strAppPath = strK
        AppPath = strK
    End Function
    Private Function StartupFileName() As String
        On Error Resume Next
        Dim strW As String
        strW = glb.Item("DefStartup")
        If strW = vbNullString Then glb.Item("DefStartup") = "Startup.Txt"
        StartupFileName = glb.Item("DefStartup")
    End Function
    Public Function DateFormat(ByVal dtM As Date, Optional ByVal strF As String = "yyyy-MM-dd") As String
        On Error Resume Next
        Dim strD As String
        strD = strF
        strD = Replace(strD, "YYYY", "yyyy")
        strD = Replace(strD, "HH", "hh")
        strD = Replace(strD, "HH24", "HH")
        strD = Replace(strD, "MM", "MM")
        strD = Replace(strD, "MI", "mm")
        strD = Replace(strD, "DD", "dd")
        strD = Replace(strD, "ss", "ss")


        strD = Format(dtM, strD)
        DateFormat = strD

        If strF = "YYYY-MM-DD" Then
            DateFormat = Mid(strD, 1, 10)
            '  ElseIf strF = "mm/dd/yyyy" Then
            '     dateformat = 
        End If
    End Function
    Public Function LoadResourceFile(ByRef strPath As String, Optional ByRef uPath As String = "") As TurboCollection
        On Error Resume Next
        Dim tcFile As TurboCollection
        If uPath = vbNullString Then
            tcFile = TextIOMgr.LoadInputFile(glb.Item("ResourcePath") & strPath)
        ElseIf Mid(uPath, 1, 1) = "@" Or Mid(uPath, 1, 1) = "$" Then
            tcFile = TextIOMgr.LoadInputFile(Mid(uPath, 2) & strPath)
        Else
            tcFile = TextIOMgr.LoadInputFile(uPath & strPath)
        End If
        LoadResourceFile = tcFile
    End Function
    Friend Function AddStartupToGlobal() As String
        On Error Resume Next
        Dim strA As StringAdapter
        strA = NewStringAdapter()
        AddStartupToGlobal = "False"
        Dim tcFile As TurboCollection
        Dim fsO As Object
        Dim oT As TextIO
        Dim strWrk As String
        Dim strK As String
        Dim strResourcePath As String
        Dim pwrk As ParmNode

        oT = TextIOMgr()


        strK = glb.Item("ResourcePath") & "\"
        If strK = vbNullString Then
            strK = Me.AppPath
            glb.Item("ResourcePath") = strK
        End If
        tcFile = oT.LoadInputFile(strK & StartupFileName())


        If tcFile Is Nothing Then
            strK = Me.AppPath & "\..\Resource\"
            tcFile = oT.LoadInputFile(strK & StartupFileName())
            If tcFile Is Nothing Then
                strK = Me.AppPath
                tcFile = oT.LoadInputFile(strK & StartupFileName())
                If tcFile Is Nothing Then
                    MessageOk("No Startup.Txt File or equivalent", "Startup Error")
                    Exit Function
                End If
            End If
        End If



        AddStartupToGlobal = "True"

        strResourcePath = strK
        tcFile.MoveFirst()

        Do

            strWrk = tcFile.Ref.Item
            strA.Parse(strWrk, "=")
            strK = strA.Item
            strWrk = Mid(strWrk, Len(strK) + 2)
            If strWrk <> vbNullString Then

                '    strWrk = CheckDBSpec(strK, strWrk)
                '
                '  If strWrk <> vbNullString Then
                glb.Item(strK) = strWrk
                '

                DebugOut("Adding " & strK & "=" & strWrk)
            End If
            tcFile.MoveNext()
        Loop While tcFile.More


        strK = strResourcePath

        strWrk = glb.Item("COPYRESOURCE")
        If strWrk <> vbNullString Then
            fsO = CreateObject("Scripting.FileSystemObject")
            fsO.CopyFile(strK & "*.txt", strWrk, True)
            fsO.CopyFile(strK & "*.frm", strWrk, True)
            strK = strWrk

        End If



        glb.Item("RESOURCEPATH") = strK

        strK = glb.Item("WorkingPath")
        If strK <> vbNullString Then glb.Item("RESOURCEPATH") = Me.AppPath & "\..\" & strK & "\"


        '  strWrk = Item("DBSPEC")
        '  strWrk = strK & strWrk
        '
        '  Set pWrk = oT.OpenInputFile(strWrk)
        '  If Not pWrk Is Nothing Then
        '    Do
        '      strWrk = oT.Item(pWrk)
        '      If strWrk <> vbNullString Then
        '
        '          strA.Parse strWrk, "="
        '          strK = strA.Item
        '          strWrk = Mid(strWrk, Len(strK) + 2)
        '
        ''          strWrk = CheckDBSpec(strK, strWrk)
        ''          If strWrk <> vbNullString Then objB.Item(strK) = strWrk
        '
        '
        '
        '      End If
        '    oT.MoveNext pWrk
        '    Loop While oT.More(pWrk)
        '
        '    oT.CloseFile pWrk
        '  End If



        strWrk = glb.Item("StartupMode")

        If strWrk <> "IPCClient" Then

            If strWrk = "IPCService" Then
                strK = strResourcePath & glb.Item("SvcStartup")
            ElseIf strWrk = "IPCDBConnect" Then
                strK = strResourcePath & glb.Item("ConStartup")
            End If

            pwrk = oT.OpenInputFile(strK)
            If Not pwrk Is Nothing Then
                Do
                    strWrk = oT.Item(pwrk)
                    If strWrk <> vbNullString Then
                        strA.Parse(strWrk, "=")
                        strK = strA.Item
                        strWrk = Mid(strWrk, Len(strK) + 2)
                        Me.Item(strK) = strWrk
                    End If
                    oT.MoveNext(pwrk)
                Loop While oT.More(pwrk)

                oT.CloseFile(pwrk)
            End If



        End If



        OldStringAdapter(strA)


    End Function

    Private Sub KillMe()
        On Error Resume Next
        ShutDown()
    End Sub
    Protected Overrides Sub Finalize()
        KillMe()
        MyBase.Finalize()
    End Sub
End Class