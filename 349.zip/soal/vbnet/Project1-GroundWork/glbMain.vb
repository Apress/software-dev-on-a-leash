Option Strict Off
Option Explicit On
Option Compare Text
<System.Runtime.InteropServices.ProgId("glbMain_NET.glbMain")> Public Class glbMain
	'*************************************************************************
	'Source Code,
	'Framework, &
	'Architecture :  Copyright (c) 1997-2000 Virtual Machine Intelligence Inc. All Rights Reserved
	'
	'*************************************************************************
  Private strID As String
  Private lngCtr As Integer
	Private blnIsLive As Boolean
	Private oParent As Object
  Private pDebugHandle As vTools.ParmNode
  Private pDebugOut As vTools.TextIO
	Private oSplash As Object
	Private StartupActionObject As Object
  Private moObserve As New vTools.Observer()
	Private strDebugOut As String
	
	'********************************************************************
	'MainBiz is a template for managing the active business layer. It
	'allows the developers to put references to all business subsystems
	'in the local collection. From that point, any other object in the system
	'can invoke one of the subsystem's using the soft key attached to the
	'subsystem in the collection.
	'
	'This effectively creates a soft interface between all business subsystems,
	'easing the rollout and debug of the subsystems and avoiding integration
	'headaches.
	'
	'By providing "soft linkage" between the other business systems using
	'MainBiz as a "grand central station", the subsystems themselves become more
	'standalone and modular. By definition they cannot be "aware" of other
	'subsystems around them without first asking MainBiz for permission.
	'
	'Each business subsystem is then required to define a public interface class
	'for use in communication outside the standard soft interface. The framework
	'enforces the use of this model.
	'
	'
	'This module requires information input concerning its primary path to get
	'metadata resources, including forms, as well as the identity of the
	'startup resource, whether a form or other configuration file - it is
	'assumed that the invokation of the program may include command-line
	'parameters, or that a logon or other user-initiated script may contain
	'the startup information
	'*****************************************************************************
	Public Function Action(ByRef ActionID As String, Optional ByRef ActionData As String = "", Optional ByRef ActionObject As Object = Nothing) As String
		On Error Resume Next
		Select Case ActionID
			Case "TimerPulse"
				'Debug.Print frmSplash.Item("TimerCount")
			Case "IPCMsg"
				IPCMsg(ActionData)
				moObserve.Observe(Me, ActionID, "glbMain")
			Case "ResourceAction"
				ResourceAction(ActionData, ActionObject)
				moObserve.Observe(Me, ActionID, "glbMain")
			Case "Startup"
				Action("Live")
				Startup(ActionID, ActionData, ActionObject)
			Case "Live"
        blnIsLive = True
      Case "CloseExe"
        blnIsLive = False
      Case "ShutDown"
        blnIsLive = False
        glb.Action("ShutDown")
      Case "DBConnect"
                glb.Ref("Per").Logon()
            Case "StartupSubSys"
                StartUpSubSys(ActionData, "InitSpec", ActionObject)
            Case "ListenSocket"
                SockListen(ActionObject) '
            Case "CloseMe"
                CloseMain()
            Case Else
                Action = glb.Action(ActionID, ActionData, ActionObject)
                If Not moObserve Is Nothing Then
                    moObserve.Observe(Me, ActionID, "glbMain")
                End If
        End Select
		
		
	End Function
	Private Sub IPCMsg(ByRef ActionData As String)
		On Error Resume Next
		Dim strWrk As String
    Dim tcP As vTools.TurboCollection
    tcP = glb.UnStringXML(ActionData)
    strWrk = tcP.FindXML("TgtSubSys").Item
    If strWrk = vbNullString Then Exit Sub
        glb.Ref(strWrk).Action("IPCMsg", ActionData)
        tcP = Nothing
    End Sub
    Private Sub SockListen(ByRef oSubscribe As Object)
        On Error Resume Next
        Dim strRHS As String
        Dim strLHS As String
        Dim strWrk As String



        strWrk = "LHSProperty=Action|LHSKey=IPCMsg" & "|" & "RHSKey=GetObserve|RHSProperty=Item|Event=ReceiveData"



        If oSubscribe Is Nothing Then
            glb.ObserveItem(Me, glb.Ref("Socket"), strWrk)
        Else
            glb.ObserveItem(oSubscribe, glb.Ref("Socket"), strWrk)

        End If






    End Sub
    Private Sub StartUpSubSys(ByRef strID As String, ByRef strSpec As String, ByRef oNew As Object)
        On Error Resume Next
        glb.Ref(strID) = oNew
        oNew.Action("Init", strSpec, StartupActionObject)
    End Sub
    Public ReadOnly Property Item(ByVal strK As String) As String
        Get
            On Error Resume Next
            Dim blnV As Boolean

            If strK = "Live" Then
                Item = CStr(blnIsLive)
            Else
                Item = strDebugOut
            End If
        End Get
    End Property
    Public Property GlobalValue(ByVal strKey As String) As String
        Get
            On Error Resume Next
            GlobalValue = glb.Item(strKey)
        End Get
        Set(ByVal Value As String)
            On Error Resume Next
            glb.Item(strKey) = Value
        End Set
    End Property
    Public Property GlobalRef(ByVal strKey As String) As Object
        Get
            On Error Resume Next
            GlobalRef = glb.Ref(strKey)
        End Get
        Set(ByVal Value As Object)
            On Error Resume Next
            glb.Ref(strKey) = Value
        End Set
    End Property
    Public WriteOnly Property Observe(Optional ByVal Instructions As String = "") As Object
        Set(ByVal Value As Object)
            On Error Resume Next
            If moObserve Is Nothing Then moObserve = New vTools.Observer()
            moObserve.Add(Me, Value, Instructions)
        End Set
    End Property
    Public ReadOnly Property frmSplash() As System.Windows.Forms.Form
        Get
            On Error Resume Next
            If oSplash Is Nothing Then
                'oSplash = New US00000()
                'oSplash.picConfig
            End If

            frmSplash = oSplash

        End Get
    End Property
    Public Function Top() As Object
        On Error Resume Next
        If oParent Is Nothing Then
            Top = Me
        Else
            Top = oParent.Top
        End If
    End Function
    Private Function Startup(ByRef ActionID As String, Optional ByRef ActionData As String = "", Optional ByRef ActionObject As Object = Nothing) As String
        On Error Resume Next
        'ID = ActionID
        Dim mObj As Object

        StartupActionObject = ActionObject


        SplashScreen(True)


        SplashScreen(False)

    End Function
    Private Function SplashScreen(ByRef blnOpen As Boolean) As Short
        On Error Resume Next
        If blnOpen Then
        Else
            frmSplash.Hide() '.Visible = False
            Do
            Loop While frmSplash.Visible
            frmSplash.Enabled = True
        End If

        System.Windows.Forms.Application.DoEvents()
        System.Windows.Forms.Application.DoEvents()


    End Function
    '*******************************************************************
    'Start Resource
    '
    'This function allows any object or form from anywhere in the system to
    'launch another resource set, including the subsystem name and the form,
    'if any, to launch when the subsystem starts.
    '
    'This allows any form or object in the system to be ObjectLink'd to the
    'remainder of the system with very little effort. Connectivity between
    'forms and objects then becomes externally configurable. For example,
    'if you add a function called ObjectLink to a given adapter, where
    'the linkage information includes the event and the Resource(s) to
    'initialize when the event occurs, then the Adapter's ctlEvent
    'function can watch the list of ObjectLinks and match them to the
    'event. cmdAdapter uses an ObjectLink to allow linkage to another
    'form and business system. If the linkage is added with 'Click' and
    'the 'objectname:formname' then on every click of the command button
    'object-form combination will be initialized and launched
    '
    '
    ' The notation for the strResource parameter is
    '
    '  "objectName:objectName"   OR
    '  "objectName"
    '
    'normally used like
    '  "BusinessObject:StartupForm"   OR
    '  "BusinessObject"
    '
    'NOTE that the textual tags are not the VB names for the objects, but the
    '"tag" names for the objects. Tag names for forms must be embedded in the
    'given form. Tag names for business objects are assigned in this Class's
    'Startup() method below
    '
    'The function simply finds the first resource and calls it's Init
    'method with the remaining resource as a parameter
    'Private Function FormLaunch(pObj As Object, strStartup As String, _
    ''                      strInstructions As String, strMode As String) As String
    ' On Error Resume Next
    ' FormLaunch = glb.Ref("UIMgr").Action("FormLaunch", _
    ''                                       glb.Item("ResourcePath") & strStartup & "|" & _
    ''                                       strStartup & "|" & _
    ''                                       strInstructions & "|" & _
    ''                                       strMode, pObj)
    'End Function
    Private Function ResourceAction(ByRef strResource As String, Optional ByRef objCalling As Object = Nothing) As Object

        On Error Resume Next
        Dim strI As String
        Dim objK As Object
        Dim strA As vTools.StringAdapter
        strA = glb.NewStringAdapter
        Dim strM As String
        Dim strK As String
        Dim strR As String
        ResourceAction = glb.Item("ActionFailed")

        If strResource = vbNullString Then Exit Function

        If InStr(1, strResource, ":", CompareMethod.Text) Then
            strA.Parse(strResource, ":")
        Else
            strA.Parse(strResource, "|")
        End If

        strK = strA.Item

        Select Case strK

            Case "DBModel"
                ResourceAction = glb.Ref("Per").Action(strResource)
                GoTo ExitMe

            Case "LoadSplash"
                If strA.Count = 1 Then
                    SplashScreen(True)
                Else
                    strA.MoveNext()
                    strM = strA.Item
                    SplashScreen(CBool(strM))
                End If

            Case "Display", "ModalDisplay", "LoadForm"
                strA.MoveNext()
                strM = strA.Item
                strA.MoveNext()
                strR = strA.Item
                strA.MoveNext()
                'now reassemble the remainder for a parameter!
                strI = vbNullString
                If strA.More Then
                    Do
                        If strI <> vbNullString Then strI = strI & ":"
                        strI = strI & strA.Item
                        strA.MoveNext()
                    Loop While strA.More
                End If

                ResourceAction = glb.Ref("UIMgr").Action("FormLaunch", glb.Item("ResourcePath") & strR & "|" & strR & "|" & strI & "|" & strK, Me)





            Case "Command"
                strA.MoveNext()
                strK = strA.Item
                strA.MoveNext()
                strR = strA.Item
                If InStr(1, strR, ".CMD", CompareMethod.Text) > 0 Then
                    ResourceAction = objK.ctlEvent(Nothing, Nothing, strR)
                    GoTo ExitMe
                End If


            Case "Action"
                strA.MoveNext()
                strK = strA.Item
                strA.MoveNext()
                strR = strA.Item
                'now reassemble the remainder for a parameter!
                strI = vbNullString
                If strA.More Then
                    Do
                        If strI <> vbNullString Then strI = strI & ":"
                        strI = strI & strA.Item
                        strA.MoveNext()
                    Loop While strA.More
                End If


                objK = glb.Ref(UCase(strK))
                If objK Is Nothing Then
                    glb.MessageOk("Unable to Find Business Ref=" & strK, "Action")
                    GoTo ExitMe
                End If
                ResourceAction = objK.Action("", strI)
                GoTo ExitMe


        End Select



ExitMe:
        glb.OldStringAdapter(strA)

    End Function
    Public Sub CloseMe(Optional ByRef blnShutdown As Boolean = True)
        On Error Resume Next
        glb.TextIOMgr.CloseFile(pDebugHandle)
        CloseComm()
        If blnShutdown Then glb.Action("ShutDown")

    End Sub
    Protected Overrides Sub Finalize()
        System.Diagnostics.Debug.WriteLine("Terminating glbMain")
        MyBase.Finalize()
    End Sub
    Private Sub CloseComm()
        On Error Resume Next
        glb.Action("FactoryClose", "Sockets")
        glb.Action("FactoryClose", "Mail")
        '  If Not mapiPrimary Is Nothing Then mapiPrimary.CloseMe
    End Sub

    '************************************************************************
    Public Sub DebugOut(Optional ByRef strS As String = "")
        On Error Resume Next
        System.Diagnostics.Debug.WriteLine(strS)
        strDebugOut = strS
        moObserve.Observe(Me, "Print", "glbMain")

        If Not pDebugHandle Is Nothing Then
            glb.TextIOMgr.Item(pDebugHandle) = strS
        End If
    End Sub
    Public Sub DebugOutput(ByRef blnMode As Boolean)
        On Error Resume Next
        Dim strName As String
        If blnMode = True Then

            strName = GlobalValue("DebugOut")
            If strName <> "True" Then Exit Sub

            'If pDebugHandle Is Nothing Then
            '    pDebugOut = glb.TextIOMgr
            '    strName = VB6.GetPath & "\LogFiles\"
            '    '   If Mid(strName, Len(strName) - 3) = "main" Then strName = strName & "\..\Data"
            '    strName = strName & "\" & GlobalValue("userName") & VB6.Format(Now, "YYYY-MM-DD-HH-MM-SS") & ".TXT"
            '    pDebugHandle = pDebugOut.OpenOutputFile(strName)
            'End If

        Else

            If Not pDebugHandle Is Nothing Then pDebugOut.CloseFile(pDebugHandle)

        End If


    End Sub




  
End Class