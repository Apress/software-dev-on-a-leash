Public Class mathadapter
    '*************************************************************************
    'Source Code,
    'Framework, &
    'Architecture :  Copyright (c) 1997-2000 Virtual Machine Intelligence Inc. All Rights Reserved
    '
    '*************************************************************************
    Private oParent As Object
    Public Function Create(ByVal oParent As Object, Optional ByVal iParm As String = "") As mathadapter
        On Error Resume Next
        Dim oMth As mathadapter
        Create = Nothing
        oMth = New mathadapter()
        Create = oMth
    End Function
    Public Function Action(ByVal ActionID As String, Optional ByRef ActionData As String = "", Optional ByRef ActionObject As Object = Nothing) As String
        On Error Resume Next
        Dim strWrk As String
        Dim pWrk As vtools.ParmNode
        Dim tcParm As vtools.TurboCollection
        Action = vbNullString
        If ActionObject Is Nothing Then
            tcParm = glb.UnStringParm(ActionData)
        Else
            tcParm = ActionObject
        End If
        strWrk = Calc(CalcPrep(ActionID), tcParm)
        If Not tcParm Is Nothing Then
            pWrk = tcParm.Find("@Format")
            If Not pWrk Is Nothing Then strWrk = Format(CDbl(strWrk), pWrk.Item)
        End If
        Action = strWrk

    End Function
    Private Function ReplaceSubString(ByVal strWrk As String, ByVal strFind As String, ByVal StrReplace As String) As String
        Dim strW As String
        On Error Resume Next
        strW = strWrk
        ReplaceSubString = strW

        strW = Replace(strW, strFind, StrReplace, 1, -1, vbTextCompare)

        ReplaceSubString = strW

    End Function
    Private Property CalcPrep(ByVal vntS As String) As String
        Get
            On Error Resume Next
            Dim strWrk As String
            Dim strI As String

            strWrk = CStr(vntS)

            '  strWrk = strA.Item
            'strWrk = ReplaceSubString(strWrk, " ", "")
            strWrk = ReplaceSubString(strWrk, "(", " ( ")
            strWrk = ReplaceSubString(strWrk, ")", " ) ")
            strWrk = ReplaceSubString(strWrk, "/", " / ")
            strWrk = ReplaceSubString(strWrk, "+", " + ")
            strWrk = ReplaceSubString(strWrk, "-", " - ")
            strWrk = ReplaceSubString(strWrk, "*", " * ")
            strWrk = ReplaceSubString(strWrk, ":", " : ")
            Do
                strI = strWrk
                strWrk = ReplaceSubString(strI, ", ", ",")
            Loop While strI <> strWrk
            Do
                strI = strWrk
                strWrk = ReplaceSubString(strI, " ,", ",")
            Loop While strI <> strWrk

            strWrk = ReplaceSubString(strWrk, ",,", ",NULL,")
            strWrk = ReplaceSubString(strWrk, ",", " , ")
            strWrk = " ( " & strWrk & " ) "    'guarantee terminus with parens
            CalcPrep = strWrk


        End Get
        Set(ByVal Value As String)

        End Set
    End Property



    Private Sub ReplaceMathOps(ByVal strA As vtools.StringAdapter)
        On Error Resume Next
        Dim pWrk As vtools.ParmNode
        Dim lngParen As Long
        Dim strItem As String

        'debug.writeline Concat(" ")

        Dim strChk As String
        strA.MoveFirst()
        Do
            strItem = strA.Item
            strChk = ConditionFactory.Action("TypeChk", strItem)
            If strChk = "fn" Then
                'debug.writeline strItem & " " & strChk
                strA.Item = "(FN_NULL " & strItem
                'debug.writeline Item
                pWrk = strA.Ref
                Do
                    strA.MoveNext()
                Loop While strA.Item <> "("
                lngParen = 0
                Do
                    If strA.Item = "(" Then lngParen = lngParen + 1
                    If strA.Item = ")" Then lngParen = lngParen - 1
                    If lngParen = 0 Then
                        strA.Item = ")" & strA.Item
                        Exit Do
                    End If
                    strA.MoveNext()
                Loop While strA.More
                strA.Ref = pWrk
            End If


            strA.MoveNext()
        Loop While strA.More

        strItem = strA.Concat(" ")
        'debug.writeline strItem

        strA.Clear()
        strItem = CalcPrep(strItem)
        strA.Parse(strItem, " ")
    End Sub
    Private Function BuildSubFormulas(ByVal strFormula As String) As vtools.TurboCollection
        On Error Resume Next
        Dim blnFound As Boolean
        Dim lngSubCtr As Long
        Dim lngParen As Long
        Dim strNull As String
        Dim pOpen As vtools.ParmNode
        Dim pClose As vtools.ParmNode
        Dim tcA As vtools.TurboCollection
        tcA = New vtools.TurboCollection()
        BuildSubFormulas = tcA
        Dim tc As vtools.TurboCollection
        Dim strA As vtools.StringAdapter
        strA = glb.NewStringAdapter
        strA.Parse(strFormula, " ")
        strA.RemoveNullStrings()
        strA.MoveFirst()
        lngSubCtr = 0
        pOpen = Nothing
        pClose = Nothing
        strA.MoveFirst()
        Do
            blnFound = False
            Do
                If strA.Item = "(" Then
                    pOpen = strA.Ref
                ElseIf strA.Item = ")" And Not pOpen Is Nothing Then
                    pClose = strA.Ref
                End If
                If Not pClose Is Nothing Then
                    blnFound = True
                    strA.Ref = pOpen
                    tc = New vtools.TurboCollection()
                    strNull = "$SUBF" & CStr(lngSubCtr)
                    tcA.AddItem("", strNull, strNull)
                    lngSubCtr = lngSubCtr + 1
                    tcA.Ref.obj = tc

                    Do
                        If strA.Item <> Nothing And strA.Item <> vbNullString Then
                            tc.AddItem(strA.Item)
                            tc.Ref.obj = ConditionFactory.Ref(strA.Item)
                        End If
                        strA.Item = strNull
                        strNull = vbNullString
                        strA.MoveNext()
                    Loop While Not strA.Ref Is pClose

                    tc.AddItem(strA.Item)
                    strA.Item = strNull
                    pClose = Nothing
                    pOpen = Nothing

                End If
                strA.MoveNext()
            Loop While strA.More
            strA.RemoveNullStrings()
            strA.MoveFirst()
            If Not blnFound Then Exit Do
        Loop While strA.DataPresent

        glb.OldStringAdapter(strA)
    End Function
    Private Function CalcSubFormula(ByVal tcSub As vtools.TurboCollection, ByVal iParm As vtools.TurboCollection) As String
        On Error Resume Next
        CalcSubFormula = vbNullString
        Dim lngParmCnt As Long
        Dim strParmCat As String
        Dim strItem As String
        Dim strItemHold As String
        Dim strLHS As String
        Dim strRHS As String
        Dim oMath As vtools.ParmNode
        Dim oMth As Object
        Dim strDelim As String

        Dim strWrk As String

        strLHS = vbNullString
        strRHS = vbNullString
        oMath = Nothing
        lngParmCnt = 0
        strParmCat = vbNullString
        strDelim = vbNullString

        tcSub.MoveFirst()
        Do
            strItem = tcSub.Ref.Item
            If strItem = "," Then
                If strItemHold = "," Then strItemHold = vbNullString
                strParmCat = strParmCat & strDelim & "P" & CStr(lngParmCnt) & "=" & strItemHold
                lngParmCnt = lngParmCnt + 1
                strDelim = "|"

            ElseIf Mid(strItem, 1, 1) = "$" Then
                strItem = iParm.Find(strItem).Item
            End If

            If strItem = ")" And strParmCat <> vbNullString Then
                strParmCat = strParmCat & strDelim & "P" & CStr(lngParmCnt) & "=" & strItemHold
                strLHS = strParmCat
            End If

            strItemHold = strItem
            'debug.writeline strItem

            If strLHS = vbNullString Then
                If IsNumeric(strItem) Or strItem = "NULL" Or strItem = "FN_NULL" Then
                    strLHS = strItem
                End If

            ElseIf InStr(1, strItem, "P0", vbTextCompare) = 1 Then
                If Not oMath Is Nothing Then
                    oMth = oMath.obj
                    strLHS = oMth.Evaluate(CStr(strLHS), CStr(strItem))
                    oMath.obj = Nothing      'vntMath = Empty
                    oMath = Nothing
                End If

            ElseIf Not oMath Is Nothing And IsNumeric(strItem) Then
                If lngParmCnt > 1 Then strItem = strParmCat
                oMth = oMath.obj
                strLHS = oMth.Evaluate(CStr(strLHS), CStr(strItem))
                oMath.obj = Nothing      'vntMath = Empty
                Exit Do
                'Set oMath = Nothing


            ElseIf Not tcSub.Ref.obj Is Nothing Then
                oMath = tcSub.Ref
            End If
            tcSub.MoveNext()

        Loop While tcSub.More

        If strLHS = vbNullString Then
            If IsNumeric(strItem) Then strLHS = strItem
        End If

        CalcSubFormula = strLHS

    End Function
    Private Function ResolveSubFormulas(ByVal tcSubList As vtools.TurboCollection) As String
        On Error Resume Next
        ResolveSubFormulas = vbNullString
        Dim strWrk As String
        Dim pWrk As vtools.ParmNode
        With tcSubList
            .MoveFirst()
            Do
                strWrk = vbNullString
                strWrk = CalcSubFormula(.Ref.obj, tcSubList)
                If strWrk <> vbNullString Then .Ref.Item = strWrk
                .MoveNext()
            Loop While .More
            ResolveSubFormulas = strWrk
        End With
    End Function
    Private Function Calc(Optional ByVal vntFormula As String = "", Optional ByVal iParm As vtools.TurboCollection = Nothing) As String
        On Error Resume Next
        Dim strResult As String
        Dim strA As vtools.StringAdapter

        Calc = "0"
        Dim tcSub As vtools.TurboCollection


        strA = glb.NewStringAdapter


        strA.Parse(CStr(vntFormula), " ")
        strA.ReplaceParms("", iParm)
        ReplaceMathOps(strA)

        tcSub = BuildSubFormulas(strA.Concat(" "))
        strResult = ResolveSubFormulas(tcSub)
        Calc = strResult
        glb.OldStringAdapter(strA)

    End Function



End Class
