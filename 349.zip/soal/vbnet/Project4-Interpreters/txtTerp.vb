Public Class txtTerp
    Private oTxt As vTools.TextIO

    Private intStrVarCtr As Integer
    Private tcFile As vTools.TurboCollection
    Private tcSub As New vTools.TurboCollection()
    Private tcVar As New vTools.TurboCollection()
    Private ConditionFactory As New vTools.conFactory()

    Public Function Create(ByVal oParent As Object, Optional ByVal iParm As String = Nothing) As txtTerp
        On Error Resume Next
        Dim txtT As txtTerp
        Create = Nothing
        txtT = New txtTerp()
        txtT.Init(oParent, iParm)
        Create = txtT
    End Function
    Public Sub Init(ByVal oParent As Object, ByVal iParm As String)
        On Error Resume Next

        Dim strA As New vTools.StringAdapter()
        Dim strB As New vTools.StringAdapter()
        Dim oTxt As vTools.TextIO
        Dim strWrk As String


        oTxt = glb.TextIOMgr
        strA.Parse(iParm, "|")
        strB.Parse(strA.Item, "=")
        If strB.Item(0) = "File" Then
            tcFile = oTxt.LoadInputFile(strB.Item(1))
        End If
        If tcFile Is Nothing Then Exit Sub


        tcSub.AddItem("", "Main", "Main")
        tcSub.Ref.tc = New vTools.TurboCollection()

        tcFile.MoveFirst()
        Do

            strWrk = LTrim(tcFile.Ref.Item)
            If Mid(strWrk, 1, 1) = "#" Or Mid(strWrk, 1, 1) = "'" Then
                strWrk = vbNullString
            End If

            If strWrk <> vbNullString Then
                strA.Parse(strWrk, " ")
                If strA.Item = "Define" Then
                    If strA.Item(1) = "Simple" Then
                        Me.DefineLogic(strA)
                    ElseIf strA.Item(1) = "Routine" Then
                        tcSub.AddItem("", strA.Item(2), strA.Item(2))
                        tcSub.Ref.tc = New vTools.TurboCollection()
                    End If
                Else
                    If InStr(1, strWrk, "$STR", vbTextCompare) Then
                        strWrk = strToVar(strWrk)
                    End If
                    If Not (strA.Item(0) = "End" And strA.Item(1) = "Routine") Then
                        tcSub.Ref.tc.AddItem(strWrk)
                    End If

                End If
            End If



            tcFile.MoveNext()
        Loop While tcFile.More

        tcSub.Dump()

        Debug.WriteLine("")
        Debug.WriteLine("")

        tcSub.MoveFirst()
        Do
            Debug.WriteLine("*****Start of " & tcSub.Ref.ItemKey & "******")
            tcSub.Ref.tc.Dump()
            Debug.WriteLine("*****End of " & tcSub.Ref.ItemKey & "******")
            Debug.WriteLine("")
            tcSub.MoveNext()
        Loop While tcSub.More



        tcSub.MoveFirst()
        Do
            ResolveDecisions(tcSub.Ref.tc)
            ' DumpRoutine tcSub.Ref.tc, 0
            ResolveConditionFactory(tcSub.Ref.tc)

            tcSub.MoveNext()
        Loop While tcSub.More



        Me.Action("Execute", "Routine=Main")


    End Sub
    '************************************************************************
    Private Sub DumpRoutine(ByVal tcR As vTools.TurboCollection, ByVal intNest As Integer)
        On Error Resume Next
        Dim tcL As vTools.TurboCollection
        Dim strWrk As String
        strWrk = Mid("                     ", 1, intNest * 2)
        If tcR Is Nothing Then Exit Sub
        tcR.MoveFirst()
        Do
            Debug.WriteLine(intNest & " " & strWrk & tcR.Ref.Item)
            If tcR.Ref.Item = "$Condition" Then
                tcL = tcR.Ref.tc
                tcL.MoveFirst()
                Do
                    If tcL.Ref.ItemKey <> "Endif" Then
                        Debug.WriteLine(intNest & " " & strWrk & tcL.Ref.Item)
                        DumpRoutine(tcL.Ref.tc, intNest + 1)
                    Else
                        Debug.WriteLine(intNest & " " & strWrk & tcL.Ref.Item)
                    End If
                    tcL.MoveNext()
                Loop While tcL.More
            End If

            tcR.MoveNext()
        Loop While tcR.More
    End Sub
    Private Sub ResolveConditionFactory(ByVal tcR As vTools.TurboCollection)
        On Error Resume Next
        Dim oCon As Object
        Dim strK As String
        Dim strA As vTools.StringAdapter
        Dim tcL As vTools.TurboCollection
        If tcR Is Nothing Then Exit Sub


        tcR.MoveFirst()
        Do
            If tcR.Ref.Item = "$Condition" Then
                tcL = tcR.Ref.tc
                tcL.MoveFirst()
                Do
                    strK = tcL.Ref.ItemKey

                    If strK = "If" Or strK = "elseif" Then
                        strA = New vTools.StringAdapter()
                        strA.Parse(tcL.Ref.Item, " ")
                        oCon = ConditionFactory.Ref(strA.Item(2))
                        If Not oCon Is Nothing Then
                            tcL.Ref.Ref = strA
                            strA.Find(2).obj = oCon
                        End If
                    End If

                    ResolveConditionFactory(tcL.Ref.tc)
                    tcL.MoveNext()
                Loop While tcL.More
            End If




            tcR.MoveNext()
        Loop While tcR.More


    End Sub
    '************************************************************************
    Private Sub ResolveDecisions(ByVal tcRoutine As vTools.TurboCollection)
        On Error Resume Next
        Dim tcList As vTools.TurboCollection
        Dim tcR As vTools.TurboCollection
        Dim tcNest As vTools.TurboCollection
        Dim strA As New vTools.StringAdapter()
        Dim pWrk As vTools.ParmNode
        Dim strK As String
        Dim strN As String
        Dim intNesting As Integer

        intNesting = 0
        tcRoutine.MoveFirst()
        Do
            strN = tcRoutine.Ref.Item
            strA.Parse(strN, " ")
            strK = strA.Item

            If strK = "if" Then
                intNesting = intNesting + 1
                If intNesting = 1 Then
                    tcList = New vTools.TurboCollection()
                    tcRoutine.Ref.tc = tcList
                    tcList.AddItem(strN, strK)
                    tcR = New vTools.TurboCollection()
                    tcList.Ref.tc = tcR
                    tcRoutine.Ref.Item = "$Condition"
                Else
                    tcR.AddItem(strN)
                End If

            ElseIf strK = "elseif" And intNesting = 1 Then
                tcList.AddItem(strN, strK)
                tcR = New vTools.TurboCollection()
                tcList.Ref.tc = tcR



            ElseIf strK = "else" And intNesting = 1 Then
                tcList.AddItem(strN, strK)
                tcR = New vTools.TurboCollection()
                tcList.Ref.tc = tcR

            ElseIf strK = "endif" Then
                If intNesting = 1 Then
                    tcList.AddItem(strN, strK)
                    tcList = Nothing
                Else
                    tcR.AddItem(strK)
                End If
                tcR = Nothing
                intNesting = intNesting - 1
                tcRoutine.Ref.Item = "REMOVE_ME_NOW"


            Else

                tcR.AddItem(strN)

            End If

            If intNesting > 0 And tcRoutine.Ref.Item <> "$Condition" Then
                tcRoutine.Ref.Item = "REMOVE_ME_NOW"
            End If



            tcRoutine.MoveNext()
        Loop While tcRoutine.More





        If intNesting <> 0 Then Debug.WriteLine("Missing EndIf for If-Block")

        tcRoutine.RemoveItemContaining("REMOVE_ME_NOW")




        'DumpRoutine tcRoutine, 0


        tcRoutine.MoveFirst()
        Do
            If tcRoutine.Ref.Item = "$Condition" Then
                tcList = tcRoutine.Ref.tc
                tcList.MoveFirst()
                Do
                    ResolveDecisions(tcList.Ref.tc)
                    tcList.MoveNext()
                Loop While tcList.More
            End If

            tcRoutine.MoveNext()
        Loop While tcRoutine.More




        Debug.WriteLine("")


    End Sub
    Private Function strToVar(ByVal strWrk As String) As String
        On Error Resume Next
        Dim strVName As String
        Dim strA As vTools.StringAdapter
        Dim strW As String
        Dim strT As String
        Dim intIdx As Integer
        strToVar = strWrk
        intStrVarCtr = intStrVarCtr + 1
        strVName = "STR" & Format(intStrVarCtr, "00000")
        intIdx = InStr(1, strWrk, "$STR", vbTextCompare)

        strW = Mid(strWrk, intIdx + Len("STR(  "))
        intIdx = InStr(1, strW, ")", vbTextCompare)
        strW = Mid(strW, 1, intIdx - 2)

        strA = glb.NewStringAdapter
        strA.Parse("Define Simple " & strVName, " ")
        DefineLogic(strA, strW)

        strT = strA.ReplaceSubString(strWrk, "$STR(" & """" & strW & """" & ")", "$" & strVName)
        If strT <> strWrk Then
            strToVar = strT
        Else
            Debug.WriteLine("Unable to convert string constant = " & strWrk)
        End If



        glb.OldStringAdapter(strA)




    End Function

    Public Function Action(ByVal ActionID As String, Optional ByVal ActionData As String = Nothing, Optional ByVal ActionObject As Object = Nothing) As String
        On Error Resume Next
        Dim tcP As vTools.TurboCollection
        Dim strA As New vTools.StringAdapter()
        Action = vbNullString
        Select Case ActionID
            Case "Execute"
                tcP = glb.UnStringParm(ActionData, "Routine")
                If tcP Is Nothing Then Exit Function
                ExecRoutine(tcSub.Find(tcP.Find("Routine").Item).tc)
                tcP = Nothing
        End Select

    End Function
    '************************************************************************
    Private Sub ResolveDecisions_WithoutRecursion(ByVal tcRoutine As vTools.TurboCollection)
        On Error Resume Next
        Dim tcList As vTools.TurboCollection
        Dim tcNest As vTools.TurboCollection
        Dim pWrk As vTools.ParmNode
        Dim oCon As Object
        Dim strA As New vTools.StringAdapter()
        Dim strK As String
        Dim strN As String
        Dim intNesting As Integer


        'First, break up the whole thing into sublists with their own levels, assume
        ' unlimited nesting

        intNesting = 0
        tcRoutine.MoveFirst()
        Do
            strN = tcRoutine.Ref.Item
            strA.Parse(strN, " ")
            strK = strA.Item
            If strK = "if" Then
                intNesting = intNesting + 1
                If tcList Is Nothing Then
                    tcRoutine.Ref.Item = "$Condition"
                    tcList = New vTools.TurboCollection()
                    tcRoutine.Ref.tc = tcList
                Else
                    tcList.Ref.Item = "$Condition"
                    tcList.Ref.tc = New vTools.TurboCollection()
                    tcList = tcList.Ref.tc
                End If


                If tcNest Is Nothing Then tcNest = New vTools.TurboCollection()
                tcNest.Add(New vTools.ParmNode(), "ToHead")
                tcNest.Ref.tc = tcList



            ElseIf strK = "endif" Then
                tcList.AddItem(strN)
                tcList.Ref.Sequence = intNesting
                intNesting = intNesting - 1
                tcNest.Remove(tcNest.Top)
                tcList = tcNest.Top.tc
                tcRoutine.Ref.Item = "REMOVE_ME_NOW"


            End If
            tcRoutine.Ref.Sequence = intNesting

            If intNesting > 0 Then
                If tcRoutine.Ref.Item <> "$Condition" Then
                    tcRoutine.Ref.Item = "REMOVE_ME_NOW"
                End If

                If strK <> "endif" Then
                    tcList.AddItem(strN)
                    tcList.Ref.Sequence = intNesting
                End If
            End If

            tcRoutine.MoveNext()
        Loop While tcRoutine.More

        If intNesting <> 0 Then Debug.WriteLine("Missing EndIf for If-Block")

        tcRoutine.RemoveItemContaining("REMOVE_ME_NOW")

        DumpRoutine(tcRoutine, 0)
        Debug.WriteLine("")



    End Sub
    '************************************************************************
    Private Function FindVar(ByVal strKey As String) As vTools.ParmNode
        On Error Resume Next
        Dim pWrk As vTools.ParmNode

        Dim strK As String
        strK = strKey
        FindVar = Nothing


        If Mid(strK, 1, 1) <> "$" Then
            If pWrk Is Nothing Then
                pWrk = New vTools.ParmNode()
                pWrk.Item = strK
            End If

        Else
            pWrk = tcVar.Find(Mid(strK, 2))
            If pWrk Is Nothing Then Exit Function
            strK = pWrk.Item
            If Mid(strK, 1, 2) = "@$" Then
                pWrk = FindVar(Mid(strK, 2))
            End If


        End If


        FindVar = pWrk


    End Function
    '************************************************************************
    Private Sub ConditionLogic(ByVal tcRoutine As vTools.TurboCollection)
        On Error Resume Next
        Dim strWrk As String
        Dim tcR As vTools.TurboCollection
        Dim tcList As vTools.TurboCollection
        Dim strA As vTools.StringAdapter
        Dim blnEval As Boolean
        Dim pLHS As vTools.ParmNode
        Dim pRHS As vTools.ParmNode
        Dim oEval As Object

        tcR = tcRoutine.Ref.tc
        tcR.MoveFirst()
        Do
            strA = tcR.Ref.Ref
            If Not strA Is Nothing Then
                strA.MoveFirst()
                strA.MoveNext()
                pLHS = FindVar(strA.Item)
                strWrk = strA.Item & "(" & pLHS.Item & ") "

                strA.MoveNext()
                oEval = strA.Ref.obj
                strWrk = strWrk & strA.Item
                strA.MoveNext()
                pRHS = FindVar(strA.Item)
                strWrk = strWrk & "  " & strA.Item & "(" & pRHS.Item & ") "
                blnEval = oEval.Evaluate(pLHS.Item, pRHS.Item)
                If blnEval Then
                    strWrk = "TRUE Was Result of " & strWrk
                Else
                    strWrk = "FALSE was result of " & strWrk
                End If
                Debug.WriteLine(strWrk)

                If blnEval Then
                    ExecRoutine(tcR.Ref.tc)
                    Exit Sub
                End If


            ElseIf tcR.Ref.ItemKey <> "Endif" Then
                ExecRoutine(tcR.Ref.tc)
                Exit Sub

            End If



            tcR.MoveNext()
        Loop While tcR.More



    End Sub
    '************************************************************************
    Private Sub ExecRoutine(ByVal tcRoutine As vTools.TurboCollection)
        On Error Resume Next
        Dim strA As vTools.StringAdapter
        Dim strK As String
        Dim pWrk As vTools.ParmNode
        If tcRoutine Is Nothing Then Exit Sub
        strA = glb.NewStringAdapter

        tcRoutine.MoveFirst()
        Do
            strA.Parse(tcRoutine.Ref.Item, " ")
            strK = strA.Item
            Select Case strK
                Case "Set"
                    SetLogic(strA)
                Case "Call"
                    CallLogic(strA)
                Case "$Condition"
                    '        DumpRoutine tcRoutine, 0
                    ConditionLogic(tcRoutine)
            End Select

            tcRoutine.MoveNext()
        Loop While tcRoutine.More

        glb.OldStringAdapter(strA)

    End Sub
    '************************************************************************
    Private Sub CallLogic(ByVal strA As vTools.StringAdapter)
        On Error Resume Next
        Dim strR As String
        Dim pWrk As vTools.ParmNode
        strA.MoveNext()
        strR = strA.Item
        If Mid(strR, 1, 1) = "$" Then strR = Mid(strR, 2)
        pWrk = tcSub.Find(strR)
        If pWrk Is Nothing Then Exit Sub
        Debug.WriteLine("Calling " & strA.Item)
        ExecRoutine(pWrk.tc)
    End Sub
    '************************************************************************
    Private Sub SetLogic(ByVal strA As vTools.StringAdapter)
        On Error Resume Next
        Dim strWrk As String
        Dim pWrk As vTools.ParmNode
        Dim pWrkR As vTools.ParmNode
        strA.MoveNext()
        strWrk = "Setting " & strA.Item
        pWrk = FindVar(strA.Item)
        If pWrk Is Nothing Then Exit Sub
        strA.MoveNext()
        If strA.Item = "=" Then strA.MoveNext()

        strWrk = strWrk & " to Value of " & strA.Item & "=  |"
        pWrkR = FindVar(strA.Item)
        If pWrkR Is Nothing Then
            Debug.WriteLine("Could not Find Var = " & strA.Item)
            Exit Sub
        End If

        strWrk = strWrk & pWrkR.Item & "|"
        pWrk.Item = pWrkR.Item
        Debug.WriteLine(strWrk)
        pWrk = Nothing
        pWrkR = Nothing


    End Sub
    '************************************************************************
    Private Sub DefineLogic(ByVal strA As vTools.StringAdapter, Optional ByVal strValue As String = Nothing)
        On Error Resume Next
        Dim pWrk As vTools.ParmNode
        strA.MoveNext()
        If strA.Item = "Simple" Then
            strA.MoveNext()
            pWrk = tcVar.Find(strA.Item)
            If pWrk Is Nothing Then
                tcVar.AddItem(strValue, strA.Item, strA.Item)
            End If
        End If
    End Sub

End Class
