'*************************************************************************
'Source Code,
'Framework, &
'Architecture :  Copyright (c) 1997-2002 Virtual Machine Intelligence Inc. All Rights Reserved
'*************************************************************************
Module main
   Public glb As New vTools.glbAdapter()
    Public ConditionFactory As New vTools.conFactory()

    Public dbPer As Object
    Public glbM As glbMain
    Public mIfc As ifcAdapter
    Private tcFactory As New vTools.TurboCollection()

'NOTE: If the vTools reference fails, open the Solution explorer, 
' Expand the References treeview, click on vTools to remove it, then
' right-click on References, select Add Reference, then browse for the
' vTools.DLL in this project's directory and select it. 



    Public Sub main()
        On Error Resume Next

        ' SECTION ONE - 
        Dim tcTest As New vTools.TurboCollection()
        Dim tcRainBow As New vTools.TurboCollection()
        Dim tcWestern As New vTools.TurboCollection()
        '###
        'Colors of Rainbow
        tcRainBow.AddItem("Red", "R1", "R1")
        tcRainBow.AddItem("Orange", "O1", "O1")
        tcRainBow.AddItem("Yellow", "Y1", "Y1")
        tcRainBow.AddItem("Green", "G1", "G1")
        tcRainBow.AddItem("Blue", "B1", "B1")
        tcRainBow.AddItem("Indigo", "I1", "I1")
        tcRainBow.AddItem("Violet", "V1", "V1")
        '####Subjects of Spaghetti Western Classic
        tcWestern.AddItem("TheGood", "TG1", "TG1")
        tcWestern.AddItem("TheBad", "TB1", "TB1")
        tcWestern.AddItem("TheUgly", "TU1", "TU1")



        tcTest.AddItem("", "R", "R")


        tcTest.Ref.Observe("Item#Item") = tcRainBow.Find("R1")

        tcTest.AddItem("", "W", "W")
        tcTest.Ref.Observe("Item#Item") = tcWestern.Find("TG1")

        tcTest.Find("W").Item = "Sergio Leone"
        tcTest.Find("R").Item = "Reddish Tint"

        Debug.WriteLine("Results")
        tcTest.Dump()
        tcRainBow.Dump()
        tcWestern.Dump()


        tcRainBow.Find("O1").Observe("Item#Item") = tcTest.Find("R")
        tcWestern.Find("TB1").Observe("Item#Item") = tcTest.Find("W")

        tcRainBow.Find("O1").Item = "Italian Stallion"
        tcWestern.Find("TB1").Item = "Orange Apple"

        Debug.WriteLine("Results")

        tcTest.Dump()
        tcRainBow.Dump()
        tcWestern.Dump()

        'SECTION TWO




        Dim strWrk As String
        Dim strW As String
        Dim strA As vTools.StringAdapter
        Dim pWrk As vTools.ParmNode
        Dim pOb As Object



'Let's add all six primary conditions to the TurboCollection
'Note that the conFactory() automatically adds all conditional operators to
'its internal implementation. You can review the details of this implementation
' in the conFactory.cls file of the VB6 version of this project.


        Dim oCon As New vTools.conFactory()


'Now let's parse a string as it would arrive from an external source -
'   e.g.   "0001"  EQV  "001"
'
' Note that the EQV notation will get the "numeric" comparator not the
' string comparator in the lists above

        strA = glb.NewStringAdapter

        strWrk = """" & "0001" & """" & " EQV " & """" & "001" & """"

        strA.Parse(strWrk, " ") 'parse on the space 
        strA.Dump() 'dump It for viewing In Immediate Window

        strA.MoveFirst() 'reset to beginning.
        '####
        Do
            pOb = oCon.Ref("." & strA.Item & ".")               ' is the conditional notation it in the list?
            If Not pOb Is Nothing Then                                     'yes we found it!
                'using contents of Item to Initialze with "V" or ""
                strA.Ref.obj = pOb       'set the StringAdapter's ref object to this new conditional
                '		object
            Else

                strW = strA.ReplaceSubString(strA.Item, """", "")  'otherwise just strip out the quotes
                strA.Item = strW     'and replace It without the quotes

            End If
            '####  
            strA.MoveNext()   'keep looking until 
        Loop While strA.More    '      string Is empty


        strA.Dump()


        Dim blnEval As Boolean
        blnEval = strA.Find(1).obj.Action(strA.Item(0), strA.Item(2))     'evaluate right hand(2) and left hand(0) items
        If blnEval Then
            Debug.WriteLine("Condition is TRUE!")
        Else
            Debug.WriteLine("Condition is FALSE!")
        End If
        tcTest.Clear()


        'SECTION THREE

        strWrk = """" & "0001" & """" & " EQ " & """" & "001" & """"




        tcTest.AddItem("", "", "")  'add an empty Item to It
        tcTest.AddItem("", "", "")  'add another empty Item to It
        ''###We'll use FindByIndex to locate the nodes on tcTest!
        tcTest.FindByIndex(0).Observe("Item#Item") = strA.Find(0)           'observe first node of tcTest
        tcTest.FindByIndex(1).Observe("Item#Item") = strA.Find(2)           'observe second node of tcTest
        tcTest.FindByIndex(0).Item = "238"   'make the value a numeric 238
        tcTest.FindByIndex(1).Item = "0000238"   'next value a numeric 238 also!


        strA.Dump()


        blnEval = strA.Find(1).obj.Action(strA.Item(0), strA.Item(2))
        If blnEval Then Debug.WriteLine("By Jove! I've Got it!")










        glb.OldStringAdapter(strA)

    End Sub


   '
    'Startup Routine to call vTools as a DLL - we can invoke the same scenario for every
    ' DLL driven by the main() module - the StartupSubSys for glbMain allows for registering
    ' an unlimited number of third-party DLLs so we can quickly integrate new subsystems
    ' and provide plug-and-play thereafter.
    '
    '
    Private Sub StartupInit()

      mIfc = New ifcAdapter()

      'glb = New vDDM.glbAdapter()
      Dim strPath As String
      strPath = glb.Item("ResourcePath")
      glb.Item("Master") = "True"
      glb.Item("Context") = "ProjectSix"
      glb.IFCRef = mIfc
      glbM = New glbMain()
      mIfc.Init(glbM, "ProjectSix")
      mIfc.ifcCtrl = mIfc
      glbM.Action("Startup", "", mIfc)
      glb.Item("PKGSPEC") = "PKGSPEC.txt"
'Note that this startupsubsys function can also accept a tag-based CreateObject,
' giving use the ability to dynamically attach pre-integrated DLLs at run time,
' furthering the model's flexibility and minimizing its run-time footprint
     glbM.Action("StartupSubSys", "glb", glb) 'glb speaks for the vTools subsystem






 '     dbPer = glb.Ref("Per")

  '    dbPer.Action("Logon", ":")

    strPath = glb.Item("ResourcePath")


    End Sub
    Public Sub CloseMain()
        On Error Resume Next
    End Sub
    Public WriteOnly Property ifcCtrlRef() As Object
        Set(ByVal Value As Object)
            On Error Resume Next
            glb.IFCRef = Value
        End Set
    End Property

End Module
