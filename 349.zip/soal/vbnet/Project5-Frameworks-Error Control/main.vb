'*************************************************************************
'Source Code,
'Framework, &
'Architecture :  Copyright (c) 1997-2002 Virtual Machine Intelligence Inc. All Rights Reserved
'*************************************************************************
Option Strict Off
Option Explicit On 
Option Compare Text
Module main
    Public glb As New vTools.glbAdapter()
    Public ConditionFactory As New vTools.conFactory()

    Public dbPer As Object
    Public glbM As glbMain
    Public mIfc As ifcAdapter
    Private tcFactory As New vTools.TurboCollection()

'NOTE: If the vTools reference fails, open the Solution explorer, 
' Expand the References treeview, click on vTools to remove it, then
' right-click on References, select Add Reference, then browse for the
' vTools.DLL in this project's directory and select it. 



    Public Sub main()
        On Error Resume Next
        StartupInit()         'pay no attention to the man behind the curtain!


        FactoryInit()

        'SECTION ONE (.NET ONLY)

        ' SOME DATE Formatting examples - note that the default VB .NET environment treats
        ' YYYY-MM-DD differently from yyyy-MM-dd - because now "case" matters! Of 
        ' course, our application users might complain about having to understand
        ' this very subtle formatting nuance, so let's make it a non-issue (following)

        Dim strD As String
        strD = glb.DateFormat(Now, "YYYY-MM-DD")
        Debug.WriteLine(strD)

        strD = glb.DateFormat(Now, "YYYY-MM-DD HH24:MI:SS")
        Debug.WriteLine(strD)

        strD = glb.DateFormat(Now, "mm/dd/yyyy")
        Debug.WriteLine(strD)

        strD = glb.DateFormat(Now, "yyyy/mm/dd")
        Debug.WriteLine(strD)

        strD = glb.DateFormat(Now, "YYYY-MM-DD HH:MI:SS")
        Debug.WriteLine(strD)

        ' SECTION TWO - setting up error control logging

        Dim cntErr As New cntAdapter()

'Define the columns (layout) of the container
        cntErr.Action("Layout", "ErrTime|ErrComponent|ErrClass|ErrContext|ErrMsg")


        Dim strTime As String
        Dim strComponent As String
        Dim strClass As String
        Dim strContext As String
        Dim strMsg As String


'let's assemble a message and add it
        Dim strDat As String
        strTime = glb.DateFormat(Now(), "YYYY-MM-DD HH24:MI:SS")
        strComponent = "Program"
        strClass = "Main"
        strContext = "Example"
        strMsg = "0 - Here is an Error Message"


        strDat = strTime & "|" & strComponent & "|" & strClass & "|" & strContext & "|" & strMsg
        cntErr.Action("AddRow", strDat, Nothing)
        Debug.WriteLine(CStr(cntErr.Action("GetRow")))


'let's add another general message
        strTime = glb.DateFormat(Now(), "YYYY-MM-DD HH24:MI:SS")
        strComponent = "Program"
        strClass = "Main"
        strContext = "Another Example"
        strMsg = "35 - Here is an Error Message 35"
        strDat = strTime & "|" & strComponent & "|" & strClass & "|" & strContext & "|" & strMsg
        cntErr.Action("AddRow", strDat, Nothing)

'and another, this time with a VB-generated error

        strTime = glb.DateFormat(Now(), "YYYY-MM-DD HH24:MI:SS")
        strComponent = "Program"
        strClass = "Main"
        strContext = "Yet Another Example"
'        strMsg = "481 - Here is an Error Message 481"
        Dim IntI As Integer
        IntI = 0
        IntI = 481 / IntI         ' Force a Divide By 0 error
        If Err.Number <> 0 Then
          strMsg = "Err " & Err.Number & " - " & Err.Description
          strDat = strTime & "|" & strComponent & "|" & strClass & "|" & strContext & "|" & strMsg
          cntErr.Action("AddRow", strDat, Nothing)
        End If

'now let's look at our log
        Debug.WriteLine("------")
        cntErr.Action("MoveFirst")
        Do
            Debug.WriteLine(CStr(cntErr.Action("GetRow")))

        Loop While cntErr.Action("MoveNext") = "True"

        'SECTION THREE - Using the glbAdapter

        'give the glb() object a container object for catching errors
        glb.Ref("cntErr") = New cntAdapter()

        'Now let's just add a new error message to the ErrorHandler

        glb.Action("ErrorHandler", "Context=Trying to Test|Message=3134 - Test Message")


        'now get it back and browse it
        cntErr = glb.Ref("cntErr")
        cntErr.Action("MoveFirst")
        Do
            Debug.WriteLine(CStr(cntErr.Action("GetRow")))

        Loop While cntErr.Action("MoveNext") = "True"

        'or let's just set the glb() object's browse context to the "ErrorHandler"
        ' and go get the information only
        glb.Action("BrowseContext", "cntErr")
        glb.Action("MoveFirst")
        Do
            Debug.WriteLine(CStr(glb.Action("GetRow")))
        Loop While glb.Action("MoveNext") = "True"


'       Section FOUR - VB .NET Extra - Try Catch

'       This will capture an error in the called subroutine
'       Single-step through this exercise:
        Debug.WriteLine("------")

        TryCatchTest()


'now let's go get the log again

        glb.Action("MoveFirst")
        Do
            Debug.WriteLine(CStr(glb.Action("GetRow")))
        Loop While glb.Action("MoveNext") = "True"



    End Sub
Private Sub TryCatchTest()
        Dim objErr As Object                    'let's let this object be "Nothing"
        Dim objAccess As Object
        Try
           objAccess = objErr.MoveFirst         'Access empty object to force error
        Catch
           glb.Action("ErrorHandler", "Context=TryCatchTest " & Err.Source & "|Message=Err " & Err.Number & " - " & Err.Description)

        End Try


End Sub

    Public Function Factory(ByVal strK As String, Optional ByVal iObj As Object = Nothing) As Object
        On Error Resume Next
        Dim tcAv As vTools.TurboCollection
        Dim pWrk As vTools.ParmNode
        Factory = Nothing
        pWrk = tcFactory.Find(strK)

        tcAv = pWrk.Ref       'get the available list
        If tcAv.DataPresent Then   'If something Is on It?
            Factory = tcAv.Top.obj      'use the node on the top of the list
            tcAv.Remove(tcAv.Top)  'then remove the top node
        Else   'otherwise It's empty
            Factory = pWrk.obj.Create(iObj)     'so create a new one
        End If


    End Function
    Public Sub FactoryRelease(ByVal strK As String, ByVal iObj As Object)
        On Error Resume Next
        Dim tcAv As vTools.TurboCollection    'allocate a vTools. TurboCollection
        Dim pWrk As vTools.ParmNode   ' and a placeholder
        pWrk = tcFactory.Find(strK)      'find the class type with the key
        tcAv = pWrk.Ref       ' and get the "available" list
        tcAv.AddItem("", strK, strK)  'add the recycled object
        tcAv.Ref.obj = iObj       'and set It to the list's obj reference
    End Sub
    Private Sub FactoryInit()
        On Error Resume Next
        FactoryAdd("StringAdapter", New vTools.StringAdapter())
        FactoryAdd("TurboCollection", New vTools.TurboCollection())
        FactoryAdd("ParmNode", New vTools.ParmNode())
        FactoryAdd("Observer", New vTools.Observer())
        FactoryAdd("Container", New cntAdapter())
    End Sub
    Public Sub FactoryAdd(ByVal strK As String, ByVal iObj As Object)
        On Error Resume Next
        Dim pWrk As vTools.ParmNode
        pWrk = tcFactory.Find(strK)     'find it
        If pWrk Is Nothing Then         'if not found, then add a ref
            tcFactory.AddItem("", strK, strK)   'add to the factory
            tcFactory.Ref.obj = iObj            'add the seed
            tcFactory.Ref.Ref = New vTools.TurboCollection()  ' and an "available list" 
        Else
            pWrk.obj = iObj             'otherwise just reset the seed object
        End If
    End Sub
        '
    '
    'Startup Routine to call vTools as a DLL - we can invoke the same scenario for every
    ' DLL driven by the main() module - the StartupSubSys for glbMain allows for registering
    ' an unlimited number of third-party DLLs so we can quickly integrate new subsystems
    ' and provide plug-and-play thereafter.
    '
    '
    Private Sub StartupInit()

      mIfc = New ifcAdapter()

      'glb = New vDDM.glbAdapter()
      Dim strPath As String
      strPath = glb.Item("ResourcePath")
      glb.Item("Master") = "True"
      glb.Item("Context") = "ProjectSix"
      glb.IFCRef = mIfc
      glbM = New glbMain()
      mIfc.Init(glbM, "ProjectSix")
      mIfc.ifcCtrl = mIfc
      glbM.Action("Startup", "", mIfc)
      glb.Item("PKGSPEC") = "PKGSPEC.txt"
'Note that this startupsubsys function can also accept a tag-based CreateObject,
' giving use the ability to dynamically attach pre-integrated DLLs at run time,
' furthering the model's flexibility and minimizing its run-time footprint
     glbM.Action("StartupSubSys", "glb", glb) 'glb speaks for the vTools subsystem






 '     dbPer = glb.Ref("Per")

  '    dbPer.Action("Logon", ":")

    strPath = glb.Item("ResourcePath")


    End Sub
    Public Sub CloseMain()
        On Error Resume Next
    End Sub
    Public WriteOnly Property ifcCtrlRef() As Object
        Set(ByVal Value As Object)
            On Error Resume Next
            glb.IFCRef = Value
        End Set
    End Property

End Module
