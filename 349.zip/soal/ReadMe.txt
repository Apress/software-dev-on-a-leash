File:Readme.Txt
Software Development On a Leash, (aPress, 2002,  ISBN: 1893115917)


COPYRIGHTS:

All source code examples, binary libraries and supporting project documentation
are Copyright (c) 1997-2002 Virtual Machine Intelligence Inc. All Rights Reserved.
This copyright notice supercedes any/all embedded copyright notices in the source
code or banners.

Other copyrights apply per aPress.

PATENTS:

Patents and trademarks are pending on vMach, its sub-components, and the
Metamorphic Software model.


LICENSE:

VMII provides discounted licenses to University / academic environments based on
class size rather than individual student.

Before installing the Projects and supporting modules, the reader must read and
accept the license agreement and intellectual property documents:

         SOAL_vMach_SCLA.rtf - License Agreement
         SOAL_INTELLECTUAL_PROPERTY_RIGHTS.doc

In general, the reader agrees to use the software within his/her personal
computing environment and not for commercial / for profit software development.
Such development licenses are available separately from VMII.

All licenses (commercial, government and academic) are confidential. 


PROJECTS


Caveats: Adding the vTools/vDDM DLLs under VB6 projects can also add them to the
workstation registry. Avoid moving the project directory once installed.

The VB6 *.vbp files are all separate projects to self-contain them as
demonstrations, but as always multiple projects can create configuration
issues in the registry. The vTools.DLL is a different version in Project 7 than
the other projects.


All projects contain a subset of the vMach (c) product, a fully functional
metamorphic framework as described in the book.

The Microsoft ActiveX Data Objects bound into the VB6 version of the
vDDM is for ADO 2.5 or higher. Under Windows 2000, the VB .NET versions will conform to
the version you have applied for the operating system.


The projects are organized into the following directory structure:

VB6/    All Projects for Visual Basic 6/Visual Basic 7
VBNET/  All Projects for Visual Basic .NET

Under each of these directories is a common structure:

Project1-Groundwork/            Self-contained Project 1 software
Project2-Structures/            Self-contained Project 2 software
Project3-Behaviors/             Self-contained Project 3 software
Project4-Interpreters/          Self-contained Project 4 software
Project5,6,7-Frameworks.../     Self-contained Project(s) 5,6,7 software
vUIMDemo/                       Subset of the vMach framework demonstrating user interface
                                   management



VB6 Notes on vTools and vDDM DLLs - if these do not operate correctly, you will need to:
1) Open up the Project/References
2) Remove the DLL from the list
3) Close the Reference panel
4) Reopen the References panel
5) Browse for the project's directory
6) Locate the given DLL
7) Add it to the references
8) Close the panel and execute the project

Note that vb6/Project 7 uses a different vTools.DLL than the other projects

In VB6, adding these reference may also add them to your workstation's registry, so
avoid moving the project directory once installed.


.NET Notes on vTools and vDDM DLLs - if these do not appear in the References when you
bring up the project's  SLN file, you will need to:

1) Select References in the Solution TreeView
2) Right click on the DLL and remove the DLL from the list
3) Right click on References, select Add Reference
4) Select Browse, then locate the project's directory
5) Find the project's /bin subdirectory
6) Select the given DLL
7) Execute the project


