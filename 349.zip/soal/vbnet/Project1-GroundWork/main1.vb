'*************************************************************************
'Source Code,
'Framework, &
'Architecture :  Copyright (c) 1997-2002 Virtual Machine Intelligence Inc. All Rights Reserved
'*************************************************************************
Module main1
   Public glb As New vTools.glbAdapter()
    Public ConditionFactory As New vTools.conFactory()

    Public dbPer As Object
    Public glbM As glbMain
    Public mIfc As ifcAdapter
    Private tcFactory As New vTools.TurboCollection()

'NOTE: If the vTools reference fails, open the Solution explorer, 
' Expand the References treeview, click on vTools to remove it, then
' right-click on References, select Add Reference, then browse for the
' vTools.DLL in this project's directory and select it. 


    Public Sub Main()
        On Error Resume Next
        StartupInit()  'pay no attention to the man behind the curtain!
        Dim tcTest As New vTools.TurboCollection()
        Dim pWrk As vTools.ParmNode



        'SECTION 1 - vTools.TurboCOllection Intro

  'add a node manually
        tcTest.Add(New vTools.ParmNode())

  'or just add one by default internally
        tcTest.Add()

'now add one and return it

        pWrk = tcTest.Add()

'or just add one and get it later
        tcTest.Add()
        pWrk = tcTest.Ref


        'Set the ParmNode contents Directly
        pWrk.Item = "A1"
        pWrk.ItemKey = "A10"
        pWrk.SortKey = "A10"

        'OR - Set the ParmNode contents indirectly through the TurboCOllection's current Ref
        tcTest.Ref.Item = "A1"
        tcTest.Ref.ItemKey = "A!0"
        tcTest.Ref.SortKey = "A10"

        'OR - just use the handy shorthand version

        tcTest.AddItem("A1", "A10", "A10")
        tcTest.Dump()



        'Now let's add lot's of stuff
        tcTest.Clear()  ' let�s clear out the iterator first
        tcTest.AddItem("A1", "A10", "A10")
        tcTest.AddItem("A4", "A40", "A40")
        tcTest.AddItem("A2", "A20", "A20")
        tcTest.AddItem("A5", "A50", "A50")
        tcTest.AddItem("A6", "A60", "A60")
        tcTest.AddItem("A7", "A70", "A70")
        tcTest.AddItem("A3", "A30", "A30")
        tcTest.AddItem("A8", "A80", "A80")

        'Loop through the list to review the contents:

        tcTest.MoveFirst()   'move the Iterator to the top of the list
        Do
            Debug.WriteLine(tcTest.Ref.Item)    'display the item there.
            tcTest.MoveNext()               'move to the next Node in the list
        Loop While tcTest.More()            'repeat while more Nodes in the list
        tcTest.Dump()

        'Now find a list member - two examples (should return "A3")

        pWrk = tcTest.Find("A30")
        Debug.WriteLine(pWrk.Item)

        Debug.WriteLine(tcTest.Find("A30").Item)

        'Sort the list descending and display

        tcTest.SortList(strParms:="Descending")
        Debug.WriteLine("After Sortlist (Desc)")
        tcTest.Dump()

      'now sort Ascending (default)
        tcTest.SortList()
        Debug.WriteLine("After Sortlist (Asc)")
        tcTest.Dump()


        'Build a Binary Tree

        tcTest.TreeBuild()
        Debug.WriteLine("After Treebuild")
        tcTest.Dump()


        'SECTION 2 - Property Manipulation


        Dim pEngine As New RocketEngine()


        pEngine.Item("Drive") = "TwinIon"
        pEngine.Item("Navigation") = "VFR"
        pEngine.Item("Inertia") = "Dampening=False"

        pEngine.Item("Warp") = "True"


        ' SECTION 3 - Factories and Object Recycle

        Dim oWrk As vTools.Observer
        Dim iWrk As vTools.Observer

        FactoryInit()
        oWrk = Factory("Observer")                         'go get an Observer
        FactoryRelease("Observer", oWrk)                   ' put it back
        iWrk = Factory("Observer")                         'fetch it again
        If TypeOf oWrk Is vTools.Observer Then             'did I get it?
          Debug.WriteLine("Found it!")
        End If
        If iWrk Is oWrk Then                               'is it the same one I just had?
           Debug.WriteLine("It's the same one!")           '   good - recycling works!
        End If





    End Sub
    Public Function Factory(ByVal strK As String, Optional ByVal iObj As Object = Nothing) As Object
        On Error Resume Next
        Dim tcAv As vTools.TurboCollection
        Dim pWrk As vTools.ParmNode
        Factory = Nothing
        pWrk = tcFactory.Find(strK)

        tcAv = pWrk.Ref       'get the available list
        If tcAv.DataPresent Then   'If something Is on It?
            Factory = tcAv.Top.obj      'use the node on the top of the list
            tcAv.Remove(tcAv.Top)  'then remove the top node
        Else   'otherwise It's empty
            Factory = pWrk.obj.Create(iObj)     'so create a new one
        End If


    End Function
    Public Sub FactoryRelease(ByVal strK As String, ByVal iObj As Object)
        On Error Resume Next
        Dim tcAv As vTools.TurboCollection   'allocate a vTools.TurboCOllection
        Dim pWrk As vTools.ParmNode   ' and a placeholder
        pWrk = tcFactory.Find(strK)      'find the class type with the key
        tcAv = pWrk.Ref       ' and get the "available" list
        tcAv.AddItem("", strK, strK)  'add the recycled object
        tcAv.Ref.obj = iObj       'and set It to the list's obj reference
    End Sub
    Private Sub FactoryInit()
        On Error Resume Next
        FactoryAdd("StringAdapter", New vTools.StringAdapter())
        FactoryAdd("TurboCollection", New vTools.TurboCollection())
        FactoryAdd("ParmNode", New vTools.ParmNode())
        FactoryAdd("Observer", New vTools.Observer())
    End Sub
    Public Sub FactoryAdd(ByVal strK As String, ByVal iObj As Object)
        On Error Resume Next
        Dim pWrk As vTools.ParmNode
        pWrk = tcFactory.Find(strK)     'find it
        If pWrk Is Nothing Then         'if not found, then add a ref
            tcFactory.AddItem("", strK, strK)   'add to the factory
            tcFactory.Ref.obj = iObj            'add the seed
            tcFactory.Ref.Ref = New vTools.TurboCollection() ' and an "available list" 
        Else
            pWrk.obj = iObj             'otherwise just reset the seed object
        End If
    End Sub


  Private Sub StartupInit()

      mIfc = New ifcAdapter()

      'glb = New vDDM.glbAdapter()
      Dim strPath As String
      strPath = glb.Item("ResourcePath")
      glb.Item("Master") = "True"
      glb.Item("Context") = "ProjectSix"
      glb.IFCRef = mIfc
      glbM = New glbMain()
      mIfc.Init(glbM, "ProjectSix")
      mIfc.ifcCtrl = mIfc
      glbM.Action("Startup", "", mIfc)
      glb.Item("PKGSPEC") = "PKGSPEC.txt"
'Note that this startupsubsys function can also accept a tag-based CreateObject,
' giving use the ability to dynamically attach pre-integrated DLLs at run time,
' furthering the model's flexibility and minimizing its run-time footprint
     glbM.Action("StartupSubSys", "glb", glb) 'glb speaks for the vTools subsystem






 '     dbPer = glb.Ref("Per")

  '    dbPer.Action("Logon", ":")

    strPath = glb.Item("ResourcePath")


    End Sub
    Public Sub CloseMain()
        On Error Resume Next
    End Sub
    Public WriteOnly Property ifcCtrlRef() As Object
        Set(ByVal Value As Object)
            On Error Resume Next
            glb.IFCRef = Value
        End Set
    End Property
End Module
