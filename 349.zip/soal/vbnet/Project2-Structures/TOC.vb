Option Explicit On 
Option Compare Text
Public Class TOC
  Private tcProp As New vTools.TurboCollection()
  '****************************************************************
  'Now let�s define the Item() property using the tcProp as the repository
  Public Property Item(ByVal strK As String) As String
    Get
      On Error Resume Next
      Item = vbNullString 'prepare if not found
      Item = tcProp.Find(strK).Item 'find the item and return the value 
    End Get
    Set(ByVal Value As String)
      On Error Resume Next
      Dim pWrk As vTools.ParmNode 'working storage
      pWrk = tcProp.Find(strK) ' find the property if already there
      If pWrk Is Nothing Then 'if not, then add it
        tcProp.AddItem(Value, strK, strK) 'add the property with the key
        pWrk = tcProp.Ref                  'get the property reference again
      End If
      pWrk.Item = Value                     'set the Item to the new value
    End Set
  End Property
  '*******************************************************************
  'Now let�s define the Ref() with the tcProp repository
  '*******************************************************************
  Public Property Ref(ByVal strK As String) As Object

    Get
      On Error Resume Next
      Dim oSeed As Object                       'prep in case �New�
      Dim oNew As Object                        'also in case �New�

      If strK = "New" Then  'is this a New request
        oSeed = tcProp.Find("Factory").obj  'yes then get the seed � it was
        'added when we built the object
        If oSeed Is Me Then                  'am I the seed?
          oNew = New TOC()            'yes then make a new one
          'use TOB, TOC as required in each class
          'don�t miss the significance of the next statement, because it allows every
          'created object to know where its factory is � so we can build new objects
          'fractally from existing ones without accessing the abstract factory
          oNew.Ref("Factory") = Me  ' make this object�s Factory = Me
          Ref = oNew   'and return it
        Else
          Ref = oSeed.Ref("New")           'otherwise, find the seed elsewhere
        End If
      ElseIf strK = "Top" Then                 'Asking for �Top� ?
        Ref = Top()                                   'call Top() and Make It So
      Else
        Ref = tcProp.Find(strK).obj        'Otherwise, return the reference as found
        'on the tcProp
      End If

    End Get
    '*********************************************************
    Set(ByVal Value As Object)
      On Error Resume Next
      Dim pWrk As vTools.ParmNode 'working reference
      pWrk = tcProp.Find(strK) 'find the Ref if already there
      If pWrk Is Nothing Then 'else build it
        tcProp.AddItem("", strK, strK) 'add it to the properties list
        pWrk = tcProp.Ref  'get  the Ref
      End If
      pWrk.obj = Value  'set the Obj to the new value
    End Set
  End Property
  '*******************************************************************
  'Now let�s define the Top function call - 
  '*******************************************************************
  Private Function Top() As Object
    On Error Resume Next
    Dim oTop As Object  'working storage
    Dim oParent As Object  'local parent
    oParent = tcProp.Find("Parent").obj       'find my parent
    If oParent Is Nothing Then  'if I don�t have one then
      Top = Me        'I�m the top!
    Else
      oTop = oParent.Ref("Top")     'otherwise look on my Parent
      If oTop Is Nothing Then  'not Found?
        Top = Me        'then I�m the Top!
      Else
        Top = oTop       'Otherwise use Found Value
      End If
    End If
  End Function
  '*******************************************************************




End Class
