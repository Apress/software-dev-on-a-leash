'*************************************************************************
'Source Code,
'Framework, &
'Architecture :  Copyright (c) 1997-2002 Virtual Machine Intelligence Inc. All Rights Reserved
'*************************************************************************
Option Strict Off
Option Explicit On 
Option Compare Text
Module main
    Public glb As New vDDM.glbAdapter()
    Public ConditionFactory As New vDDM.conFactory()

    Public dbPer As vDDM.dbEngine
    Public glbM As glbMain
    Public mIfc As ifcAdapter
    Private tcFactory As New vDDM.TurboCollection()

'NOTE: If the vDDM reference fails, open the Solution explorer, 
' Expand the References treeview, click on vDDM to remove it, then
' right-click on References, select Add Reference, then browse for the
' vDDM.DLL in this project's directory and select it.
'
'
'
' If you want to access a Microsoft Access database, an entry for this purpose exists
' in the file DBSPEC.txt. The "SOALTest" DSN in this file can be changed to a DSN of
' your choosing (all other parameters should remain the same). I have provided a
' preformatted MSAccess database called SOAL.mdb under the C:\SOAL\vb6\vUIMDemo
' path. You can simply set the SOALTest DSN to this file using an Access driver. The
' steps are: Start Menu/Control Panel/Data Sources
'                      (Data Sources is under Administrative Tools in Win2k)
' Select the System DSN tab, then select Add, select the Microsoft Access driver, then
' set the DSN name to SOALTest and the file name to C:\SOAL\vb6\vUIMDemo\SOAL.mdb.
'
' If you want to use Oracle, in order to comply with the examples in this project,
' plus the data model ' explained in the book, the data model database should be the same as
' the one described here. Oracle "create" examples are given for syntax.
'
'
'create table emp( emp_id  number(10), emp_name varchar2(50), addr_id number(10), site_id number(10), emp_str_dte date);
'create table site( site_id number(10), site_name varchar(50),csz_id number(10), sec_id number(10));
'create table addr( addr_id number(10), addr_field1 varchar(50),csz_id number(10));
'create table sec( sec_id number(10), sec_code varchar2(50));
'create table ctry( ctry_id number(10), ctry_name varchar2(50));
'create table csz( csz_id number(10), csz_city_st_zip varchar2(50), ctry_id number(10));


'
'



    Public Sub main()
      On Error Resume Next
      StartupInit()            'pay no attention to the man behind the curtain!








        Dim oT As txtTerp
        FactoryInit()




        'SECTION ONE

        Dim cnt As cntAdapter
        cnt = Factory("Container", Nothing)
        cnt.Action("Layout", "Column0|Column1|Column2|Column3|Column4")
        cnt.Action("Load", "Source=Text|Path=File:Snip1Input.Txt|Delim=,")

'Now let's browse the contents of the loaded file
        Debug.WriteLine("------")
        cnt.Action("Movefirst")
        Do
            Debug.WriteLine(cnt.Action("GetRow"))
        Loop While cnt.Action("MoveNext") = "True"


'Let's get the data on a per-column basis
        Dim strWrk As String  'workspace
        Debug.WriteLine("------")
        cnt.Action("MoveFirst")   'move to the first node
        Do
            strWrk = cnt.Item("Column1")  'get second column�s data by �tag�
            strWrk = strWrk & "    " & cnt.Item(1) 'concat with second column�s 
            'data by �position�
            Debug.WriteLine(strWrk)  ' show it
        Loop While CBool(cnt.Action("MoveNext")) 'move to the next and test for terminus

'Let's reset the data layout and sort it by the date, then show it again
        Debug.WriteLine("------")
        cnt.Action("Layout", "Tag=PUB_ID,Type=N|Tag=PUB_NM,Type=c|Tag=PUB_LOC,Type=c|Tag=PUB_ROL,Type=c|Tag=PUB_DT,Type=d")
        cnt.Action("Sort", "PUB_DT")
        cnt.Action("Movefirst")
        Do
            Debug.WriteLine(cnt.Action("GetRow"))
        Loop While cnt.Action("MoveNext") = "True"

'Now let's sort on two keys, then display the result again
        Debug.WriteLine("------")

        cnt.Action("Sort", "PUB_LOC|PUB_NM")
        cnt.Action("Movefirst")
        Do
            Debug.WriteLine(cnt.Action("GetRow"))
        Loop While cnt.Action("MoveNext") = "True"




        'Now load and interpret the same file

        oT = New txtTerp()
        oT.Init(Nothing, "File=" & glb.AppPath & "..\Snip2Input.Txt")

        oT.Action("Execute", "Routine=BrowseDemo")



        ' SECTION TWO - 


        'Browse the database







        dbPer.Action("Logon", ":")

        oT = New txtTerp()
        oT.Init(Nothing, "File=" & glb.AppPath & "..\Snip4Input.Txt")

        oT.Action("Execute", "Routine=BrowseDemo")










'Let's set up some staging information

        dbPer.Item("@AddrID") = 121

        Debug.WriteLine("AddrID=" & dbPer.Item("@AddrID"))
        Debug.WriteLine("Emp.AddrID=" & dbPer.Item("DBModelValue|EMP:ADDR_ID"))
        Debug.WriteLine("Addr.AddrID=" & dbPer.Item("DBModelValue|Addr:Addr_ID"))
        dbPer.Item("DBModelValue|Addr:Addr_ID") = 400
        Debug.WriteLine("Emp.AddrID=" & dbPer.Item("DBModelValue|EMP:ADDR_ID"))
        Debug.WriteLine("Addr.AddrID=" & dbPer.Item("DBModelValue|Addr:Addr_ID"))
        dbPer.Item("DBModelValue|@Emp:@AddrID") = 500
        Debug.WriteLine("Emp.AddrID=" & dbPer.Item("DBModelValue|EMP:ADDR_ID"))

        dbPer.Action("dbPseudo", "Tag=EmpSSN|Type=n|Size=10|Key=EmpSSN")
        dbPer.Item("@EmpSSN") = 841
        Debug.WriteLine("EmpSSN=" & dbPer.Item("@EmpSSN"))


        dbPer.Action("dbAlias", "EmpID=AcctID")
        dbPer.Action("dbAlias", "AddrID=HomeAddrID")
        dbPer.Item("@AcctID") = 891
        dbPer.Item("@HomeAddrID") = 898
        Debug.WriteLine("AcctID/EmpID=" & dbPer.Item("@EmpID"))  'will yield 891
        Debug.WriteLine("HomeAddrID/AddrID=" & dbPer.Item("@AddrID")) ' will yield 898


        dbPer.Item("@EmpID") = 8910
        dbPer.Item("@AddrID") = 8980
        Debug.WriteLine("AcctID/EmpID=" & dbPer.Item("@AcctID"))     'will yield 8910
        Debug.WriteLine("HomeAddrID/AddrID=" & dbPer.Item("@HomeAddrID")) ' will yield 8980


        dbPer.Action("dbAlias", "EmpID=SiteID")      'alias SiteID and EmpID
        dbPer.Item("@EmpID") = 9000                ' set the value once
        Debug.WriteLine("SiteID=" & dbPer.Item("DBModelValue|SITE:SITE_ID"))   'yields 9000
        Debug.WriteLine("EmpID=" & dbPer.Item("DBModelValue|EMP:EMP_ID"))   'yields 9000
        dbPer.Item("@SiteID") = 9500                  'set the other value
        Debug.WriteLine("SiteID=" & dbPer.Item("DBModelValue|SITE:SITE_ID"))  'yields 9500
        Debug.WriteLine("EmpID=" & dbPer.Item("DBModelValue|EMP:EMP_ID"))  ' yields 9500

'Now let's look at some simple generated SQL

        dbPer.Item("@EmpID") = 5000
        Debug.WriteLine(dbPer.Item("SQL|select @AcctID, @HomeAddrID from @Emp where @EmpID = @EmpID"))

        dbPer.Item("@EmpSSN") = 3000
        Debug.WriteLine(dbPer.Item("SQL|select @AcctID, @HomeAddrID from @Emp where @EmpID = @EmpSSN"))


        Debug.WriteLine(dbPer.Item("DBInsertString|@EMP"))
        Debug.WriteLine(dbPer.Item("DBInsertString|@ADDR"))
        Debug.WriteLine(dbPer.Item("DBUpdateString|@EMP|@EmpID"))

        dbPer.Item("@AddrField1") = "1880 Bay St"
        Debug.WriteLine(dbPer.Item("DBUpdateString|@ADDR|@AddrID"))

        Debug.WriteLine(dbPer.Item("SQL|@EmpAddrCtrySel @EmpAddrCtryWhere"))
        Debug.WriteLine(dbPer.Item("SQL|@EmpAddrCtry"))


'Let's take a look at the history of all SQL statements submitted to the vDDM

        Dim strW As String
        dbPer.Item("BrowseContext") = "SQL"  ' optionally �Model� or �Err�
        strW = dbPer.Item("MoveFirst")
        If strW <> vbNullString Then
            Do
                strW = dbPer.Item("Reference")
                Debug.WriteLine(strW)
                strW = dbPer.Item("MoveNext")
            Loop While strW = "More"
        End If


'Let's take a look at any errors the vDDM has seen

        dbPer.Item("BrowseContext") = "ERR"
        strW = dbPer.Item("MoveFirst")
        If strW <> vbNullString Then
            Do

                strW = dbPer.Item("Reference")
                Debug.WriteLine(strW)
                strW = dbPer.Item("MoveNext")
            Loop While strW = "More"
        End If


'Let's take a look at the virtual model the vDDM sees

        dbPer.Item("BrowseContext") = "Model"
        strW = dbPer.Item("MoveFirst")
        If strW <> vbNullString Then
            Do

                strW = dbPer.Item("Reference")
                Debug.WriteLine(strW)
                strW = dbPer.Item("MoveNext")
            Loop While strW = "More"
        End If


'Let's take a look at column-level metadata


        Debug.WriteLine("vSQL from column EMP_ID=" & dbPer.Item("dbOriginKey|Emp_ID"))
        Debug.WriteLine("Column from vSQL key=" & dbPer.Item("dbOrigin|EmpID"))
        Debug.WriteLine("Column from vSQL key==" & dbPer.Item("dbOrigin|@EmpID"))
        Debug.WriteLine("Table Name from vSQL EMP=" & dbPer.Item("DBTableName|@Emp"))
        Debug.WriteLine("Column Name derived from vSQL @EmpId=" & dbPer.Item("DBColumnName|EmpId"))
        Debug.WriteLine("Data type from vSQL key EmpID=" & dbPer.Item("DBType|EmpID"))
        Debug.WriteLine("Data Size from vSQL key EMP_ID=" & dbPer.Item("DBSize|EmpID"))
        Debug.WriteLine("All table columns from table EMP=" & dbPer.Item("DBColumnString|EMP"))


'Now let's generate some data!


        dbPer.Action("dbGenerateInit", "File=PkgDataGen.Txt")

        dbPer.Action("dbGenerateExec")




    End Sub



    Public Function Factory(ByVal strK As String, Optional ByVal iObj As Object = Nothing) As Object
        On Error Resume Next
        Dim tcAv As vDDM.TurboCollection
        Dim pWrk As vDDM.ParmNode
        Factory = Nothing
        pWrk = tcFactory.Find(strK)

        tcAv = pWrk.Ref       'get the available list
        If tcAv.DataPresent Then   'If something Is on It?
            Factory = tcAv.Top.obj      'use the node on the top of the list
            tcAv.Remove(tcAv.Top)  'then remove the top node
        Else   'otherwise It's empty
            Factory = pWrk.obj.Create(iObj)     'so create a new one
        End If


    End Function
    Public Sub FactoryRelease(ByVal strK As String, ByVal iObj As Object)
        On Error Resume Next
        Dim tcAv As vDDM.TurboCollection   'allocate a TurboCollection
        Dim pWrk As vDDM.ParmNode   ' and a placeholder
        pWrk = tcFactory.Find(strK)      'find the class type with the key
        tcAv = pWrk.Ref       ' and get the "available" list
        tcAv.AddItem("", strK, strK)  'add the recycled object
        tcAv.Ref.obj = iObj       'and set It to the list's obj reference
    End Sub
    Private Sub FactoryInit()
        On Error Resume Next
        FactoryAdd("StringAdapter", New vDDM.StringAdapter())
        FactoryAdd("TurboCollection", New vDDM.TurboCollection())
        FactoryAdd("ParmNode", New vDDM.ParmNode())
        FactoryAdd("Observer", New vDDM.Observer())
        FactoryAdd("Container", New cntAdapter())
    End Sub
    Public Sub FactoryAdd(ByVal strK As String, ByVal iObj As Object)
        On Error Resume Next
        Dim pWrk As vDDM.ParmNode
        pWrk = tcFactory.Find(strK)     'find it
        If pWrk Is Nothing Then         'if not found, then add a ref
            tcFactory.AddItem("", strK, strK)   'add to the factory
            tcFactory.Ref.obj = iObj            'add the seed
            tcFactory.Ref.Ref = New vDDM.TurboCollection() ' and an "available list" 
        Else
            pWrk.obj = iObj             'otherwise just reset the seed object
        End If
    End Sub

    Public Sub CloseMain()
        On Error Resume Next
    End Sub
    Public WriteOnly Property ifcCtrlRef() As Object
        Set(ByVal Value As Object)
            On Error Resume Next
            glb.IFCRef = Value
        End Set
    End Property
    '
    '
    'Startup Routine to call vDDM as a DLL - we can invoke the same scenario for every
    ' DLL driven by the main() module - the StartupSubSys for glbMain allows for registering
    ' an unlimited number of third-party DLLs so we can quickly integrate new subsystems
    ' and provide plug-and-play thereafter.
    '
    '
    Private Sub StartupInit()

      mIfc = New ifcAdapter()
      'glb = New vDDM.glbAdapter()
      Dim strPath As String
      strPath = glb.Item("ResourcePath")
      glb.Item("Master") = "True"
      glb.Item("Context") = "ProjectSix"
      glb.IFCRef = mIfc
      glbM = New glbMain()
      mIfc.Init(glbM, "ProjectSix")
      mIfc.ifcCtrl = mIfc
      glbM.Action("Startup", "", mIfc)
      glb.Item("PKGSPEC") = "PKGSPEC.txt"

'Note that this startupsubsys function can also accept a tag-based CreateObject,
' giving use the ability to dynamically attach pre-integrated DLLs at run time,
' furthering the model's flexibility and minimizing its run-time footprint
      glbM.Action("StartupSubSys", "Per", New vDDM.dbEngine()) 'vDDM.dbEngine






      dbPer = glb.Ref("Per")

      dbPer.Action("Logon", ":")

    strPath = glb.Item("ResourcePath")


    End Sub

End Module
