Option Compare Text
Public Class txtTerp

    '*************************************************************************
    'Source Code,
    'Framework, &
    'Architecture :  Copyright (c) 1997-2000 Virtual Machine Intelligence Inc. All Rights Reserved
    '
    '
    ' Normalize each Complex LHS and RHS to the following preprocess:
    '   xxx.xxx(xxx) = yyy.yyy(yyy)
    '   possible legal syntax:
    '   $cmplx                      $cmplx.Item()
    '   $cmplx.Property             $cmplx.Property()
    '   $cmplx.Property(Key)        $cmplx.Property(Key)
    '
    '
    '
    '*************************************************************************

    Dim oTxt As vDDM.TextIO

    Private intStrVarCtr As Integer
    Private tcFile As vDDM.TurboCollection
    Private tcSub As New vDDM.TurboCollection()
    Private tcVar As New vDDM.TurboCollection()
    Private strDelim As String = "|"
    Public Function Create(ByVal oParent As Object, Optional ByVal iParm As String = Nothing) As txtTerp
        On Error Resume Next
        Dim txtT As txtTerp
        Create = Nothing
        txtT = New txtTerp()
        txtT.Init(oParent, iParm)
        Create = txtT
    End Function
    Public Sub Init(ByVal oParent As Object, ByVal iParm As String)
        On Error Resume Next

        Dim strA As New vDDM.StringAdapter()
        Dim strB As New vDDM.StringAdapter()
        Dim oTxt As vDDM.TextIO
        Dim strWrk As String


        oTxt = glb.TextIOMgr
        strA.Parse(iParm, "|")
        strB.Parse(strA.Item, "=")
        If strB.Item(0) = "File" Then
            tcFile = oTxt.LoadInputFile(strB.Item(1))
        End If
        If tcFile Is Nothing Then Exit Sub




        tcSub.AddItem("", "Main", "Main")
        tcSub.Ref.tc = New vDDM.TurboCollection()

        tcFile.MoveFirst()
        Do

            strWrk = Trim(tcFile.Ref.Item)


            '    strWrk = strA.ReplaceSubString(strWrk, "=", " = ")
            '    strWrk = strA.ReplaceSubString(strWrk, "$", " $")
            strA.Parse(strWrk, " ")                                             'parse on spaces
            strA.RemoveNullStrings()
            strWrk = strA.Concat(" ")
            strA.Parse(strWrk, " ")

            If Mid(strWrk, 1, 1) = "#" Or Mid(strWrk, 1, 1) = "'" Then
                strWrk = vbNullString
            End If

            If strWrk <> vbNullString Then
                strA.Parse(strWrk, " ")
                If strA.Item = "Define" Then                                        'if a define, then determine Simple or complex
                    If strA.Item(1) = "Simple" Or strA.Item(1) = "Complex" Then
                        DefineLogic(strA)
                    ElseIf InStr(1, strA.Item(1), "Routine", vbTextCompare) > 0 Then   'if a routine then
                        tcSub.AddItem("", strA.Item(2), strA.Item(2))               ' include in tcSub 
                        tcSub.Ref.tc = New vDDM.TurboCollection()
                    End If
                Else
                    If InStr(1, strWrk, "$STR", vbTextCompare) Then
                        strWrk = strToVar(strWrk)
                    End If
                    If Not (strA.Item(0) = "End" And InStr(1, strA.Item(1), "Routine", vbTextCompare) > 0) Then
                        tcSub.Ref.tc.AddItem(strWrk)                            'be default add line to the current routine
                    End If

                End If
            End If



            tcFile.MoveNext()
        Loop While tcFile.More

        tcSub.Dump()

        Debug.WriteLine(" ")
        Debug.WriteLine(" ")

        tcSub.MoveFirst()
        Do
            Debug.WriteLine("*****Start of " & tcSub.Ref.ItemKey & "******")
            tcSub.Ref.tc.Dump()
            Debug.WriteLine("*****End of " & tcSub.Ref.ItemKey & "******")
            Debug.WriteLine(" ")
            tcSub.MoveNext()
        Loop While tcSub.More



        tcSub.MoveFirst()
        Do
            ResolveDecisions(tcSub.Ref.tc)
            ' DumpRoutine tcSub.Ref.tc, 0
            ResolveConditionFactory(tcSub.Ref.tc)

            tcSub.MoveNext()
        Loop While tcSub.More



        Action("Execute", "Routine=Main")


    End Sub
    '************************************************************************
    Private Sub DumpRoutine(ByVal tcR As vDDM.TurboCollection, ByVal intNest As Integer)
        On Error Resume Next
        Dim tcL As vDDM.TurboCollection
        Dim strWrk As String
        strWrk = Mid("                     ", 1, intNest * 2)
        If tcR Is Nothing Then Exit Sub
        tcR.MoveFirst()
        Do
            Debug.WriteLine(intNest & " " & strWrk & tcR.Ref.Item)
            If tcR.Ref.Item = "$Condition" Then
                tcL = tcR.Ref.tc
                tcL.MoveFirst()
                Do
                    If tcL.Ref.ItemKey <> "Endif" Then
                        Debug.WriteLine(intNest & " " & strWrk & tcL.Ref.Item)
                        DumpRoutine(tcL.Ref.tc, intNest + 1)
                    Else
                        Debug.WriteLine(intNest & " " & strWrk & tcL.Ref.Item)
                    End If
                    tcL.MoveNext()
                Loop While tcL.More
            End If

            tcR.MoveNext()
        Loop While tcR.More
    End Sub
    Private Sub ResolveConditionFactory(ByVal tcR As vDDM.TurboCollection)
        On Error Resume Next
        Dim oCon As Object
        Dim strK As String
        Dim strA As vDDM.StringAdapter
        Dim tcL As vDDM.TurboCollection
        If tcR Is Nothing Then Exit Sub


        tcR.MoveFirst()
        Do
            If tcR.Ref.Item = "$Condition" Then
                tcL = tcR.Ref.tc
                tcL.MoveFirst()
                Do
                    strK = tcL.Ref.ItemKey

                    If strK = "If" Or strK = "elseif" Then
                        strA = New vDDM.StringAdapter()
                        strA.Parse(tcL.Ref.Item, " ")
                        oCon = ConditionFactory.Ref(strA.Item(2))
                        If Not oCon Is Nothing Then
                            tcL.Ref.Ref = strA
                            strA.Find(2).obj = oCon
                        End If
                    End If

                    ResolveConditionFactory(tcL.Ref.tc)
                    tcL.MoveNext()
                Loop While tcL.More
            End If




            tcR.MoveNext()
        Loop While tcR.More


    End Sub
    '************************************************************************
    Private Sub ResolveDecisions(ByVal tcRoutine As vDDM.TurboCollection)
        On Error Resume Next
        Dim tcList As vDDM.TurboCollection
        Dim tcR As vDDM.TurboCollection
        Dim tcNest As vDDM.TurboCollection
        Dim strA As New vDDM.StringAdapter()
        Dim pWrk As vDDM.ParmNode
        Dim strK As String
        Dim strN As String
        Dim intNesting As Integer

        intNesting = 0
        tcRoutine.MoveFirst()
        Do
            strN = tcRoutine.Ref.Item
            strA.Parse(strN, " ")
            strK = strA.Item

            If strK = "if" Then
                intNesting = intNesting + 1
                If intNesting = 1 Then
                    tcList = New vDDM.TurboCollection()
                    tcRoutine.Ref.tc = tcList
                    tcList.AddItem(strN, strK)
                    tcR = New vDDM.TurboCollection()
                    tcList.Ref.tc = tcR
                    tcRoutine.Ref.Item = "$Condition"
                Else
                    tcR.AddItem(strN)
                End If

            ElseIf strK = "elseif" And intNesting = 1 Then
                tcList.AddItem(strN, strK)
                tcR = New vDDM.TurboCollection()
                tcList.Ref.tc = tcR



            ElseIf strK = "else" And intNesting = 1 Then
                tcList.AddItem(strN, strK)
                tcR = New vDDM.TurboCollection()
                tcList.Ref.tc = tcR

            ElseIf strK = "endif" Then
                If intNesting = 1 Then
                    tcList.AddItem(strN, strK)
                    tcList = Nothing
                Else
                    tcR.AddItem(strK)
                End If
                tcR = Nothing
                intNesting = intNesting - 1
                tcRoutine.Ref.Item = "REMOVE_ME_NOW"


            Else

                tcR.AddItem(strN)

            End If

            If intNesting > 0 And tcRoutine.Ref.Item <> "$Condition" Then
                tcRoutine.Ref.Item = "REMOVE_ME_NOW"
            End If



            tcRoutine.MoveNext()
        Loop While tcRoutine.More





        If intNesting <> 0 Then Debug.WriteLine("Missing EndIf for If-Block")

        tcRoutine.RemoveItemContaining("REMOVE_ME_NOW")




        'DumpRoutine tcRoutine, 0


        tcRoutine.MoveFirst()
        Do
            If tcRoutine.Ref.Item = "$Condition" Then
                tcList = tcRoutine.Ref.tc
                tcList.MoveFirst()
                Do
                    ResolveDecisions(tcList.Ref.tc)
                    tcList.MoveNext()
                Loop While tcList.More
            End If

            tcRoutine.MoveNext()
        Loop While tcRoutine.More




        Debug.WriteLine(" ")


    End Sub
    Private Function strToVar(ByVal strWrk As String) As String
        On Error Resume Next
        Dim strVName As String
        Dim strA As vDDM.StringAdapter
        Dim strW As String
        Dim intIdx As Integer
        strToVar = strWrk
        intStrVarCtr = intStrVarCtr + 1
        strVName = "STR" & Format(intStrVarCtr, "00000")
        intIdx = InStr(1, strWrk, "$STR", vbTextCompare)

        strW = Mid(strWrk, intIdx + Len("STR(  "))
        intIdx = InStr(1, strW, ")", vbTextCompare)
        strW = Mid(strW, 1, intIdx - 2)

        strA = glb.NewStringAdapter
        strA.Parse("Define Simple " & strVName, " ")
        DefineLogic(strA, strW)

        strW = strA.ReplaceSubString(strWrk, "$STR(" & """" & strW & """" & ")", "$" & strVName)
        glb.OldStringAdapter(strA)

        strToVar = strW


    End Function
    Public Function Action(ByVal ActionID As String, Optional ByVal ActionData As String = "", Optional ByVal ActionObject As Object = Nothing) As String
        On Error Resume Next
        Dim tcP As vDDM.TurboCollection
        Dim strA As New vDDM.StringAdapter()
        Action = vbNullString
        Select Case ActionID                                            'is this to execute?
            Case "Execute"
                tcP = glb.UnStringParm(ActionData, "Routine")           'yes so find the routine
                Debug.WriteLine(" ")
                Debug.WriteLine("About to Exec Routine >>> " & ActionData)
                ExecRoutine(tcSub.Find(tcP.Find("Routine").Item).tc)    'and execute it
                tcP = Nothing
        End Select

    End Function
    '************************************************************************
    Private Sub ResolveDecisions_WithoutRecursion(ByVal tcRoutine As vDDM.TurboCollection)
        On Error Resume Next
        Dim tcList As vDDM.TurboCollection
        Dim tcNest As vDDM.TurboCollection
        Dim pWrk As vDDM.ParmNode
        Dim oCon As Object
        Dim strA As New vDDM.StringAdapter()
        Dim strK As String
        Dim strN As String
        Dim intNesting As Integer


        'First, break up the whole thing into sublists with their own levels, assume
        ' unlimited nesting

        intNesting = 0
        tcRoutine.MoveFirst()
        Do
            strN = tcRoutine.Ref.Item
            strA.Parse(strN, " ")
            strK = strA.Item
            If strK = "if" Then
                intNesting = intNesting + 1
                If tcList Is Nothing Then
                    tcRoutine.Ref.Item = "$Condition"
                    tcList = New vDDM.TurboCollection()
                    tcRoutine.Ref.tc = tcList
                Else
                    tcList.Ref.Item = "$Condition"
                    tcList.Ref.tc = New vDDM.TurboCollection()
                    tcList = tcList.Ref.tc
                End If


                If tcNest Is Nothing Then tcNest = New vDDM.TurboCollection()
        tcNest.Add(New vDDM.ParmNode(), "ToHead")
                tcNest.Ref.tc = tcList



            ElseIf strK = "endif" Then
                tcList.AddItem(strN)
                tcList.Ref.Sequence = intNesting
                intNesting = intNesting - 1
                tcNest.Remove(tcNest.Top)
                tcList = tcNest.Top.tc
                tcRoutine.Ref.Item = "REMOVE_ME_NOW"


            End If
            tcRoutine.Ref.Sequence = intNesting

            If intNesting > 0 Then
                If tcRoutine.Ref.Item <> "$Condition" Then
                    tcRoutine.Ref.Item = "REMOVE_ME_NOW"
                End If

                If strK <> "endif" Then
                    tcList.AddItem(strN)
                    tcList.Ref.Sequence = intNesting
                End If
            End If

            tcRoutine.MoveNext()
        Loop While tcRoutine.More

        If intNesting <> 0 Then Debug.WriteLine("Missing EndIf for If-Block")

        tcRoutine.RemoveItemContaining("REMOVE_ME_NOW")

        DumpRoutine(tcRoutine, 0)
        Debug.WriteLine(" ")



    End Sub
    '************************************************************************
    Private Function FindVar(ByVal strKey As String) As vDDM.ParmNode
        On Error Resume Next
        Dim pWrk As vDDM.ParmNode

        Dim strK As String
        strK = strKey
        FindVar = Nothing

        Do


            If Mid(strK, 1, 1) <> "$" Then
                If pWrk Is Nothing Then
                    pWrk = New vDDM.ParmNode()
                    pWrk.Item = strK
                    pWrk.ItemType = "Simple"
                End If

                FindVar = pWrk
                Exit Function
            End If
            pWrk = tcVar.Find(Mid(strK, 2))
            If pWrk Is Nothing Then Exit Function
            strK = pWrk.Item
            If Mid(strK, 1, 1) = "$" Then
                pWrk = FindVar(strK)
            Else
                FindVar = pWrk
                Exit Function
            End If


        Loop While True



    End Function
    '************************************************************************
    Private Sub ConditionLogic(ByVal tcRoutine As vDDM.TurboCollection)
        On Error Resume Next
        Dim strWrk As String
        Dim tcR As vDDM.TurboCollection
        Dim tcList As vDDM.TurboCollection
        Dim strA As vDDM.StringAdapter
        Dim blnEval As Boolean
        Dim pLHS As vDDM.ParmNode
        Dim pRHS As vDDM.ParmNode
        Dim oEval As Object

        tcR = tcRoutine.Ref.tc
        tcR.MoveFirst()
        Do
            strA = tcR.Ref.Ref
            If Not strA Is Nothing Then
                strA.MoveFirst()
                strA.MoveNext()
                pLHS = FindVar(strA.Item)
                strWrk = strA.Item & "(" & pLHS.Item & ") "

                strA.MoveNext()
                oEval = strA.Ref.obj
                strWrk = strWrk & strA.Item
                strA.MoveNext()
                pRHS = FindVar(strA.Item)
                strWrk = strWrk & "  " & strA.Item & "(" & pRHS.Item & ") "
                blnEval = oEval.Evaluate(pLHS.Item, pRHS.Item)
                If blnEval Then
                    strWrk = "TRUE Was Result of " & strWrk
                Else
                    strWrk = "FALSE was result of " & strWrk
                End If
                Debug.WriteLine(strWrk)

                If blnEval Then
                    ExecRoutine(tcR.Ref.tc)
                    Exit Sub
                End If


            ElseIf tcR.Ref.ItemKey <> "Endif" Then
                ExecRoutine(tcR.Ref.tc)
                Exit Sub

            End If



            tcR.MoveNext()
        Loop While tcR.More



    End Sub
    '************************************************************************
    Private Sub ExecRoutine(ByVal tcRoutine As vDDM.TurboCollection)
        On Error Resume Next
        Dim strWrk As String
        Dim strA As vDDM.StringAdapter
        Dim strK As String
        Dim pWrk As vDDM.ParmNode
        If tcRoutine Is Nothing Then Exit Sub
        strA = glb.NewStringAdapter

        tcRoutine.MoveFirst()
        Do

            strWrk = Trim(tcRoutine.Ref.Item)                   'get the next statement
            Debug.WriteLine("Executing = " & strWrk)
            strA.Parse(strWrk, " ")                             'parse on the space
            strK = strA.Item
            Select Case strK
                Case "Set"                                      'is it a set
                    strA.Item = vbNullString
                    strA.RemoveNullStrings()
                    SetLogic(strA.Concat(" "))                  'do the assignment
                Case "Call"
                    CallLogic(strA)                             'else call
                Case "$Condition"
                    '        DumpRoutine tcRoutine, 0
                    ConditionLogic(tcRoutine)                   'else handle the conditional logic
            End Select

            tcRoutine.MoveNext()
        Loop While tcRoutine.More

        glb.OldStringAdapter(strA)

    End Sub
    '************************************************************************
    Private Sub CallLogic(ByVal strA As vDDM.StringAdapter)
        On Error Resume Next
        Dim strR As String
        Dim pWrk As vDDM.ParmNode
        strA.MoveNext()
        strR = strA.Item
        If Mid(strR, 1, 1) = "$" Then strR = Mid(strR, 2)
        pWrk = tcSub.Find(strR)
        If pWrk Is Nothing Then Exit Sub
        Debug.WriteLine("Calling " & strA.Item)
        ExecRoutine(pWrk.tc)
    End Sub
    '************************************************************************
    Private Sub SetProp(ByVal strA As vDDM.StringAdapter, ByVal strWrk As String, ByVal tcVar As vDDM.TurboCollection)
        'strVar As String, strProp As String, strDat As String)
        On Error Resume Next
        Dim lngI As Long
        Dim strProp As String
        Dim strW As String
        Dim strC As String

        '$xxx.xxx()

        strA.Parse(strWrk, ".")
        tcVar.AddItem(strA.Item, "VAR") 'strVar =             '$xxx

        If strA.Count = 1 Then Exit Sub
        strA.MoveNext()                 'xxx(" ")

        strProp = strA.Item             ' if 'xxx' only


        lngI = InStr(1, strProp, "(", vbTextCompare)
        If lngI = 0 Then
            'strProp = "ActionID=" & strA.Item
            strProp = strA.Item
            tcVar.AddItem(strProp, "PROP")
            Exit Sub
        Else
            strW = Mid(strProp, lngI)
            strProp = Mid(strProp, 1, lngI - 1)
        End If

        tcVar.AddItem(strProp, "PROP")


        ' strW = strDat                     'xxx()



        'strW = "ActionID=" & Mid(strW, 1, lngI - 1)   'xxx
        'strW = Mid(strW, lngI + 1)         '()

        strC = Mid(strW, 2, 1)

        If strC = """" Or strC = "'" Then
            strW = Mid(strW, 3)
            strW = Mid(strW, 1, Len(strW) - 2)
        Else
            strW = Mid(strW, 2, Len(strW) - 2)
        End If

        tcVar.AddItem(strW, "KEY")
        'strDat = strW



    End Sub
    Private Sub SetVars(ByVal strWrk As String, ByVal tcLHS As vDDM.TurboCollection, ByVal tcRHS As vDDM.TurboCollection) 'strLVar As String, strLProp As String, strlDat As String, strRVar As String, strRProp As String, strRDat As String)
        On Error Resume Next
        Dim strA As vDDM.StringAdapter
        strA = glb.NewStringAdapter
        Dim strL As String
        Dim strR As String
        Dim strW As String
        Dim lngI As Long

        'strWrk = "  Set $xxx.xxx('dn=4 ') = $xxx.xxx('in=5 ')"

        strWrk = Trim(strA.ReplaceSubString(strWrk, "Set ", ""))

        'strWrk = strA.ReplaceSubString(strWrk, "=  $", "=$")
        'strWrk = strA.ReplaceSubString(strWrk, "= $", "=$")

        'the first "=" sign is the marker between LHS and RHS
        lngI = InStr(1, strWrk, "=", vbTextCompare)
        If lngI = 0 Then Exit Sub
        strL = Trim(Mid(strWrk, 1, lngI - 1))
        strR = Trim(Mid(strWrk, lngI + 1))



        SetProp(strA, strL, tcLHS) 'strLVar, strLProp, strlDat
        SetProp(strA, strR, tcRHS) ' strRVar, strRProp, strRDat
        tcLHS.MoveFirst()
        tcRHS.MoveFirst()



        glb.OldStringAdapter(strA)

    End Sub
    Private Function ExecAction(ByVal oAct As Object, ByVal strActionID As String, ByVal strActionData As String) As String
        On Error Resume Next
        Dim strWrk As String
        ExecAction = vbNullString
        '  Dim strActionID As String
        '  Dim strActionData As String
        '  Dim tcParm as vddm.turbocollection
        '  Dim pWrk as vddm.parmnode
        '  Set tcParm = UnStringParm(strAction, "ActionID")
        '  Set pWrk = tcParm.Find("ActionID")
        '  If pWrk Is Nothing Then Exit Function
        '  strActionID = pWrk.Item
        '  tcParm.Remove pWrk

        '  If tcParm.DataPresent Then
        '  tcParm.MoveFirst
        '  Do
        '   If tcParm.Ref.ItemKey = "ActionID" Then tcParm.Ref.ItemKey = vbNullString
        '  tcParm.MoveNext
        '  Loop While tcParm.More
        '  End If

        '  strActionData = tcParm.Item
        strWrk = oAct.Action(strActionID, strActionData, Me)
        ExecAction = strWrk

    End Function
    Private Sub SetLogic(ByVal strStatement As String)
        On Error Resume Next
        Dim strA As vDDM.StringAdapter
        Dim lngI As Long
        Dim strWrk As String
        Dim strKey As String
        Dim strProp As String

        Dim strRHS As String
        Dim strMsg As String
        Dim pWrk As vDDM.ParmNode
        Dim pWrkR As vDDM.ParmNode
        strA = glb.NewStringAdapter

        Dim tcLHS As New vDDM.TurboCollection()
        Dim tcRHS As New vDDM.TurboCollection()


        SetVars(strStatement, tcLHS, tcRHS)   'strWrk, strProp, strDatL, strWrkR, strPropR, strDatR

        pWrk = FindVar(tcLHS.Ref.Item)
        pWrkR = FindVar(tcRHS.Ref.Item)
        If pWrkR Is Nothing Then
            pWrkR = New vDDM.ParmNode()
            pWrkR.ItemType = "Simple"
        End If


        '####Resolve the Right Hand Side First


        'Debug.Print strStatement

        strRHS = pWrkR.Item
        If pWrkR.ItemType <> "Simple" Then
            strKey = vbNullString
            strKey = tcRHS.Find("KEY").Item
            strRHS = ExecAction(pWrkR.obj, tcRHS.Find("PROP").Item, strKey)
        End If

        '###Resolve the Left Hand Side, assign Right Hand Result

        If pWrk.ItemType = "Simple" Then
            pWrk.Item = strRHS
            Debug.WriteLine("LHS is Now = " & strRHS)
            GoTo ExitSub
        Else
            strKey = vbNullString
            strKey = tcLHS.Find("Key").Item
            If strKey <> vbNullString Then
                strRHS = strKey & "=" & strRHS
            End If
            strWrk = ExecAction(pWrk.obj, tcLHS.Find("PROP").Item, strRHS)
            Debug.WriteLine("LHS Now = " & strRHS)
        End If







        Debug.WriteLine(strWrk)
ExitSub:
        pWrk = Nothing
        pWrkR = Nothing
        glb.OldStringAdapter(strA)
        tcLHS.Clear()
        tcRHS.Clear()

    End Sub
    '************************************************************************
    Private Sub DefineLogic(ByVal strA As vDDM.StringAdapter, Optional ByVal strValue As String = Nothing)
        On Error Resume Next
        Dim pWrk As vDDM.ParmNode
        strA.MoveNext()
        If strA.Item = "Simple" Then
            strA.MoveNext()
            pWrk = tcVar.Find(strA.Item)
            If pWrk Is Nothing Then
                tcVar.AddItem(strValue, strA.Item, strA.Item, "Simple")
            End If
        ElseIf strA.Item = "Complex" Then
            strA.MoveNext()
            pWrk = tcVar.Find(strA.Item)
            If pWrk Is Nothing Then
                tcVar.AddItem(strValue, strA.Item, strA.Item, "Complex")
                tcVar.Ref.obj = Factory("Container", Me)
            End If
        End If

    End Sub





End Class
