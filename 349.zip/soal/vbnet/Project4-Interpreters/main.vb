'*************************************************************************
'Source Code,
'Framework, &
'Architecture :  Copyright (c) 1997-2002 Virtual Machine Intelligence Inc. All Rights Reserved
'*************************************************************************
Module main
    Public glb As New vTools.glbAdapter()
    Public ConditionFactory As New vTools.conFactory()

    Public dbPer As Object
    Public glbM As glbMain
    Public mIfc As ifcAdapter
    Private tcFactory As New vTools.TurboCollection()

'NOTE: If the vTools reference fails, open the Solution explorer, 
' Expand the References treeview, click on vTools to remove it, then
' right-click on References, select Add Reference, then browse for the
' vTools.DLL in this project's directory and select it. 



    Public Sub main()
        On Error Resume Next
        StartupInit()
        ' SECTION ONE - 



        Dim oTxt As vTools.TextIO
        Dim tcFile As vTools.TurboCollection
        oTxt = glb.TextIOMgr
        tcFile = oTxt.LoadInputFile(glb.AppPath & "..\Snip1Input.Txt")

        tcFile.Dump()



        Dim strA As New vTools.StringAdapter()
        Dim tcVar As New vTools.TurboCollection()


        tcFile.MoveFirst() 'start at the first
        Do
            Debug.WriteLine("Examining: " & tcFile.Ref.Item)
            strA.Parse(tcFile.Ref.Item, " ") 'parse It, break the string on the space character
            If strA.Item = "Define" Then 'If the first word Is a "Define" then to DefineLogic
                DefineLogic(strA, tcVar)
            ElseIf strA.Item = "Set" Then 'else If the first word Is a "Set" then do the SetLogic
                SetLogic(strA, tcVar)
                tcVar.Dump()               'let's look at the results so far
            End If
            tcFile.MoveNext() 'keep going to the end of file
        Loop While tcFile.More


        tcVar.Dump()




        'SECTION TWO

        Dim oT As New txtTerp() 'declare the variable
        oT.Init(Nothing, "File=" & glb.AppPath & "..\Snip2Input.Txt") 'Initialize It with a file by name
        Debug.WriteLine("-----")
        oT.Action("Execute", "Routine=Main") 'command to execute the Main routine




       ' From Chapter 4 Math Discussion


        ' These statements enhance the scope of the vtools.Confactory to
        ' regard additional mathematical evaluation functions
        Dim conMath As New vTools.mathOperator()
        ConditionFactory.Action("Add", "+|mth", conMath)
        ConditionFactory.Action("Add", "*|mth", conMath)
        ConditionFactory.Action("Add", "-|mth", conMath)
        ConditionFactory.Action("Add", "/|mth", conMath)
        ConditionFactory.Action("Add", "abs|fn", New absFunction())
        ConditionFactory.Action("Add", "cos|fn", New cosFunction())
        ConditionFactory.Action("Add", "spxfr|fn", New spxfrFunction())
        ConditionFactory.Action("Optimize")


'Let's build a simple formula and execute it

        Dim oMath As New mathadapter()
        Dim strWrk As String
        strWrk = "(1000 * (40 + 200) ) / 20"
        strWrk = oMath.Action(strWrk)
        Debug.WriteLine(strWrk)

'Let's pass in the formula and compound parameters directly and execute it

        Dim inParm As String
        inParm = "Parm1=1000|Parm2=40|Parm3=200|Parm4=20"
        strWrk = "($Parm1 * ($Parm2 + $Parm3) ) / $Parm4"
        strWrk = oMath.Action(strWrk, inParm)
        Debug.WriteLine(strWrk)

'Now let's build a parameter collection and pass it into the same formula

        Dim tcParm As New vTools.TurboCollection()
        tcParm.AddItem("1000", "Parm1")
        tcParm.AddItem("40", "Parm2")
        tcParm.AddItem("200", "Parm3")
        tcParm.AddItem("20", "Parm4")
        tcParm.AddItem("30", "Parm5")
        tcParm.AddItem("700", "Parm6")
        tcParm.AddItem("80", "Parm7")
        '


        strWrk = "($Parm1 * ($Parm2 + $Parm3) ) / $Parm4"
        strWrk = oMath.Action(strWrk, ActionObject:=tcParm)
        Debug.WriteLine(strWrk)


'Let's keep the same parameter collection, but change the formula
        strWrk = "($Parm1 * ($Parm6 + $Parm7) ) / $Parm4"
        strWrk = oMath.Action(strWrk, ActionObject:=tcParm)
        Debug.WriteLine(strWrk)


'Now let's unclude some advanced functions and parse/evaluate them as a formula
        strWrk = "abs( cos($Parm1) + cos($Parm2) ) * $Parm3"
        strWrk = oMath.Action(strWrk, ActionObject:=tcParm)
        Debug.WriteLine(strWrk)

'let's just include a Format indicator in the parameter list, and let the formula
' use it as a keyword behavior cue
        tcParm.AddItem("#.##", "@Format")
        strWrk = "abs( cos($Parm1) + cos($Parm2) ) * $Parm3"
        strWrk = oMath.Action(strWrk, ActionObject:=tcParm)
        Debug.WriteLine(strWrk)

'Now let's do a custome function with unlimited parameters
        tcParm.Find("@Format").Item = "#"
        strWrk = "spxfr($Parm1, $Parm2, $Parm3  ,  $Parm4)"
        strWrk = oMath.Action(strWrk, ActionObject:=tcParm)
        Debug.WriteLine(strWrk)

' try it again but wrap some parameters with function calls tooo
        strWrk = "spxfr(cos($Parm1), cos($Parm2), $Parm3, $Parm4)"
        strWrk = oMath.Action(strWrk, ActionObject:=tcParm)
        Debug.WriteLine(strWrk)








    End Sub
    Private Sub DefineLogic(ByVal strA As vTools.StringAdapter, ByVal tcVar As vTools.TurboCollection)
        On Error Resume Next
        Dim pWrk As vTools.ParmNode
        strA.MoveNext()   'Move to the next Token
        If strA.Item = "Simple" Then   'Should be the keyword "Simple"
            strA.MoveNext()  'then move to the next Item 
            pWrk = tcVar.Find(strA.Item)       'try to find the variable name
            If pWrk Is Nothing Then    'not there, so proceed to add It
                tcVar.AddItem("", strA.Item, strA.Item) 'add an Item, using the
                ' variable name as
                '    the ItemKey and SortKey
            End If
        End If
    End Sub

    Private Sub SetLogic(ByVal strA As vTools.StringAdapter, ByVal tcVar As vTools.TurboCollection)
        On Error Resume Next
        Dim pWrk As vTools.ParmNode
        Dim pWrkR As vTools.ParmNode   'need another temp variable
        strA.MoveNext()
        If Mid(strA.Item, 1, 1) = "$" Then
            pWrk = tcVar.Find(Mid(strA.Item, 2))
            If pWrk Is Nothing Then Exit Sub
            strA.MoveNext()
            If strA.Item = "=" Then
                strA.MoveNext()
                If Mid(strA.Item, 1, 1) = "$" Then  'If $ Is present
                    pWrkR = tcVar.Find(Mid(strA.Item, 2))     'treat like first one, and find It
                    If pWrkR Is Nothing Then Exit Sub
                    pWrk.Item = pWrkR.Item   'set target to source value
                Else
                    pWrk.Item = strA.Item    'otherwise just use value
                End If
            End If
        End If
    End Sub
    '
    'Startup Routine to call vTools as a DLL - we can invoke the same scenario for every
    ' DLL driven by the main() module - the StartupSubSys for glbMain allows for registering
    ' an unlimited number of third-party DLLs so we can quickly integrate new subsystems
    ' and provide plug-and-play thereafter.
    '
    '
    Private Sub StartupInit()

      mIfc = New ifcAdapter()

      'glb = New vDDM.glbAdapter()
      Dim strPath As String
      strPath = glb.Item("ResourcePath")
      glb.Item("Master") = "True"
      glb.Item("Context") = "ProjectSix"
      glb.IFCRef = mIfc
      glbM = New glbMain()
      mIfc.Init(glbM, "ProjectSix")
      mIfc.ifcCtrl = mIfc
      glbM.Action("Startup", "", mIfc)
      glb.Item("PKGSPEC") = "PKGSPEC.txt"
'Note that this startupsubsys function can also accept a tag-based CreateObject,
' giving use the ability to dynamically attach pre-integrated DLLs at run time,
' furthering the model's flexibility and minimizing its run-time footprint
     glbM.Action("StartupSubSys", "glb", glb) 'glb speaks for the vTools subsystem






 '     dbPer = glb.Ref("Per")

  '    dbPer.Action("Logon", ":")

    strPath = glb.Item("ResourcePath")


    End Sub
    Public Sub CloseMain()
        On Error Resume Next
    End Sub
    Public WriteOnly Property ifcCtrlRef() As Object
        Set(ByVal Value As Object)
            On Error Resume Next
            glb.IFCRef = Value
        End Set
    End Property
End Module
