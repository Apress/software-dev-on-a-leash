Option Strict Off
Option Explicit On
Option Compare Text
Friend Class ifcAdapter
	'*************************************************************************
	'Source Code,
	'Framework, &
	'Architecture :  Copyright (c) 1997-2000 Virtual Machine Intelligence Inc. All Rights Reserved
	'
	'*************************************************************************
  '**************************************
  Private oParent As Object
  Private tcItem As vtools.TurboCollection
  Private blnMaster As Boolean
  'Private glb As New glbAdapter
  Private Function Top() As Object
    On Error Resume Next
    If oParent Is Nothing Then
      Top = Me
    Else
            Top = oParent.Top
        End If
  End Function
  Public WriteOnly Property ifcCtrl() As Object
    Set(ByVal Value As Object)
      On Error Resume Next
      ifcCtrlRef = Value
      '  Set glb = iIfc.glbRef
    End Set
  End Property
  Public Property Item(ByVal strK As String) As String
    Get
      On Error Resume Next
      Item = tcItem.Find(strK).Item
    End Get
    Set(ByVal Value As String)
      On Error Resume Next
      Dim pwrk As vtools.ParmNode
      If tcItem Is Nothing Then tcItem = New vtools.TurboCollection()
      pwrk = tcItem.Find(strK)
      If strK = "Context" And Value = "vMach" Then blnMaster = True
      If pwrk Is Nothing Then
        tcItem.AddItem(Value, strK, strK)
      Else
        pwrk.Item = Value
      End If
    End Set
  End Property
  Public Property Ref(ByVal strK As String) As Object
    Get
      On Error Resume Next
            Ref = Top.GlobalRef(strK)
        End Get
        Set(ByVal Value As Object)
            On Error Resume Next
            Top.GlobalRef(strK) = Value
        End Set
    End Property
  'Public Property Set glbRef(iglb As Object)
  '  On Error Resume Next
  '  Set glb = iglb
  'End Property
  'Public Property Get glbRef() As Object
  '  On Error Resume Next
  '  Set glbRef = glb
  'End Property
  Public Function Create(ByRef iParent As Object, ByRef iParm As String) As Object
    On Error Resume Next
    Dim oNew As ifcAdapter
    oNew = New ifcAdapter()
    Create = oNew
    oNew.Init(iParent, iParm)
  End Function
  Public Sub Init(ByRef iParent As Object, ByRef iParm As String)
    On Error Resume Next
    oParent = iParent
  End Sub
  Public Function Action(ByRef strActionID As String, Optional ByRef strActionData As String = "", Optional ByRef oActionObject As Object = Nothing) As String
    On Error Resume Next
    Action = ""
    Dim strA As vtools.StringAdapter
    Select Case strActionID
      Case "Print"
                Top.DebugOut(strActionData)
            Case "GlobalValueLet"
                strA = glb.NewStringAdapter
                strA.ParseFirst(strActionData, "=", True)
                Top.GlobalValue(strA.Item) = strA.Item(CStr(1))
                glb.OldStringAdapter(strA)
            Case "GlobalValueGet"
                Action = Top.GlobalValue(strActionData)
            Case Else
                Top.Action(strActionID, strActionData, oActionObject)

        End Select



  End Function
End Class