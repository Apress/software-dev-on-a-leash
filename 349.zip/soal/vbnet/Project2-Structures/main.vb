'*************************************************************************
'Source Code,
'Framework, &
'Architecture :  Copyright (c) 1997-2002 Virtual Machine Intelligence Inc. All Rights Reserved
'*************************************************************************
Module main
     Public glb As New vTools.glbAdapter()
    Public ConditionFactory As New vTools.conFactory()

    Public dbPer As Object
    Public glbM As glbMain
    Public mIfc As ifcAdapter
    Private tcFactory As New vTools.TurboCollection()

'NOTE: If the vTools reference fails, open the Solution explorer, 
' Expand the References treeview, click on vTools to remove it, then
' right-click on References, select Add Reference, then browse for the
' vTools.DLL in this project's directory and select it. 


  Private Function FactoryNew(ByVal strSeedName As String) As Object
    On Error Resume Next
    FactoryNew = Nothing
    Dim pSeed As Object
    pSeed = tcFactory.Find(strSeedName).obj    'find the seed by name
    FactoryNew = pSeed.Ref("New")                  'let the seed create it 
  End Function

  Private Sub AddSeed(ByVal strSeedName As String, ByVal oSeed As Object)
    On Error Resume Next
        tcFactory.AddItem("", strSeedName, strSeedName)       'add the element
    tcFactory.Ref.obj = oSeed                        'include seed object
    oSeed.Ref("Factory") = oSeed          'let seed know it's the factory 
    oSeed.Item("Role") = "Seed"                   'let's make a role as well
  End Sub

  Public Sub main()
    On Error Resume Next

    StartupInit() ' pay no attention to the man behind the curtain

    ' FACTORY EXAMPLE


    Dim oNew As Object
    Dim oNewToo As Object
    Dim oNewMore As Object
    Dim oTop As Object
    Dim oParent As Object
    '*******************************************************************
    AddSeed("TOA", New TOA())                         'add some objects to the factory 
    AddSeed("TOB", New TOB())
    AddSeed("TOC", New TOC())
    '*********************************************************************
    'Now let�s add a new TOA to our local environment and play 
    '  around with it  
    '*********************************************************************
    oTop = FactoryNew("TOA")                          'get a new for the Topmost reference
    oTop.Item("Role") = "Top"                         'make it's role the "Top"
    oNew = FactoryNew("TOA")                          'call factoryNew to get one from the seed
    oNew.Ref("Parent") = oTop                         'set its Parent to our "Top" object
    oNew.Item("Role") = "First"                       'it�s role will be �First� in the chain
    '*********************************************************************
    oNewToo = oNew.Ref("New")                   'now I need another object, but I�ll manufacture
    'it fractally off one of its own kind � but remember
    'that each object created from the Seed knows where
    'the Seed is to go get more because we initialized it
    '��Factory� when we created it
    oNewToo.Ref("Parent") = oNew                      'assign this parent to the �First� above
    oNewToo.Item("Role") = "Second"                   'and make its role the �Second� in line
    '*********************************************************************
    oNewMore = oNew.Ref("New")                        'lets repeat the above with a third object
    oNewMore.Ref("Parent") = oNewToo                   'parent is the �Second� above
    oNewMore.Item("Role") = "Third"                   'and this one�s role is �Third�
    '*********************************************************************
    oTop = oNewMore.Ref("Top")                        'now if we ask for the �Second�s� Top, we�ll
    Debug.WriteLine(oTop.Item("Role"))                ' get the "parent" of "First" = "Top"
    '*********************************************************************
    oTop = oNewMore.Ref("Top")                        'ditto for this reference
    Debug.WriteLine(oTop.Item("Role"))                'will be �Top� for its Top
    '*********************************************************************
    oParent = oNewMore.Ref("Parent")                  'But if I ask for the �Third�s� Parent, I will
    Debug.WriteLine(oParent.Item("Role"))             'get �Second�








'SECTION ONE

    Dim strA As New vTools.StringAdapter()
    Dim tcTest As New vTools.TurboCollection()
    Dim strTest As String
    Dim strWrk As String
    Dim strP As String

    strTest = "This is a great string"
    strA.Parse(strTest, " ")

'browse the list to examine it
    If strA.DataPresent Then
      strA.MoveFirst()
      Do
        Debug.WriteLine(strA.Item)
        strA.MoveNext()
      Loop While strA.More
    End If

'pull it back together with pipes
    strTest = strA.Concat("|")
    Debug.WriteLine(strTest)



'break it apart on the pipe "|" boundary now, then find and replace tokens
    strA.Parse(strTest, "|")

    If strA.DataPresent Then    'check for Info
      strA.MoveFirst()   'move to first one
      Do
        If strA.Item = "a" Then strA.Item = "not a" 'swap out the 'a' value
        If strA.Item = "great" Then strA.Item = "bad" 'swap out the 'great' value
        strA.MoveNext()   'get the next one
      Loop While strA.More    'until all done
    End If
    strTest = strA.Concat(" ")    'recombine the string, separate with space
    Debug.WriteLine(strTest)

    If Not strA.FindToken("Great") Then Debug.WriteLine("Not There!")
    If strA.FindToken("String") Then Debug.WriteLine("Found It")


'Bonus attractions: Offset to the current reference
strA.MoveFirst()
Debug.WriteLine(strA.Item(0))
Debug.WriteLine(strA.Item(1))
Debug.WriteLine(strA.Item(2))

' In regular parse, every delimiter counts, but what if we
' only want the first occurrence?
strTest = "This is not = to that and not = those"
strA.ParseFirst(strTest, "=")
Debug.WriteLine(strA.Item(0))
Debug.WriteLine(strA.Item(1))


'Using Stringadapter's recycle, we get one, use it and return it
    strA = glb.NewStringAdapter
    'Actions for string here
    glb.OldStringAdapter(strA)


    'SECTION TWO

'let's open and close a set of files

    Dim oTxt As vTools.TextIO
    oTxt = glb.TextIOMgr
    strA = glb.NewStringAdapter

    Dim pHan1 As Object
    Dim pHan2 As Object
    Dim pHan3 As Object

    pHan1 = oTxt.OpenInputFile(glb.AppPath & "..\Snip1Input.Txt")
    pHan2 = oTxt.OpenInputFile(glb.AppPath & "..\Snip2Input.Txt")
    pHan3 = oTxt.OpenInputFile(glb.AppPath & "..\Snip3Input.Txt")

    oTxt.CloseFile(pHan1)
    oTxt.CloseFile(pHan2)
    oTxt.CloseFile(pHan3)

'Let's input a file and show it's contents while reading

    pHan1 = oTxt.OpenInputFile(glb.AppPath & "..\Snip1Input.Txt")     'open a file
    If Not pHan1 Is Nothing Then   'make sure we have something!
      Do
        Debug.WriteLine(oTxt.Item(pHan1))  'print the current text line
        oTxt.MoveNext(pHan1)  'move to the next line (throws away previous!)
      Loop While oTxt.More(pHan1)   'repeat until end of file
    End If
    oTxt.CloseFile(pHan1)  'close It!

'
' Now let's just pull a file in and browse it afterward
'
    Dim fWrk As vTools.TurboCollection   'prep a vTools.TurboCollection
    fWrk = oTxt.LoadInputFile(glb.AppPath & "..\Snip1Input.Txt")     'Load the file and return the reference
    If fWrk.DataPresent Then   'check for data
      fWrk.MoveFirst()  'reset to top
      Do
        Debug.WriteLine(fWrk.Ref.Item)  'print the current Item
        fWrk.MoveNext()  'go to the next
      Loop While fWrk.More   'repeat until done
    End If


'Can we browse in reverse? Sure!

    fWrk.MoveFirst()  'start at the top
    Do
      fWrk.MovePrevious() 'move to the last one (circular list)
      Debug.WriteLine(fWrk.Ref.Item)  'print the line
    Loop While fWrk.More   'repeat until done


'Now let's replace some of the tokens and write the file back out


    If fWrk.DataPresent Then
      fWrk.MoveFirst()
      Do
        strWrk = fWrk.Ref.Item   'get the text line
        If strA.FindToken("A80", strWrk) Then  'check for a specific value
                    fWrk.Add(New vTools.ParmNode(), "ToMidAfter") 'add a new vTools.ParmNode with Op after current
                    '      list member (Insert after)
          strP = ">>> THIS GOES AFTER A80"
          fWrk.Ref.Item = strP   'stuff the new string on the Item
        ElseIf strA.FindToken("tcTest.More", strWrk) Then  'check for a specific value
                    fWrk.Add(New vTools.ParmNode(), "ToMidAfter") 'add a new vTools.ParmNode with Op after current
          '      list member (Insert after)
          strP = ">>> THIS GOES AFTER tcTest.More"
          fWrk.Ref.Item = strP   'stuff the new string on the Item
        End If


        fWrk.MoveNext()
      Loop While fWrk.More
    End If


'now let's dump the file to output and check the contents!
    oTxt.WriteOutputFile(glb.AppPath & "..\Snip1Output.Txt", fWrk)

    glb.OldStringAdapter(strA)









  End Sub
     '
    'Startup Routine to call vTools as a DLL - we can invoke the same scenario for every
    ' DLL driven by the main() module - the StartupSubSys for glbMain allows for registering
    ' an unlimited number of third-party DLLs so we can quickly integrate new subsystems
    ' and provide plug-and-play thereafter.
    '
    '
    Private Sub StartupInit()

      mIfc = New ifcAdapter()

      'glb = New vDDM.glbAdapter()
      Dim strPath As String
      strPath = glb.Item("ResourcePath")
      glb.Item("Master") = "True"
      glb.Item("Context") = "ProjectSix"
      glb.IFCRef = mIfc
      glbM = New glbMain()
      mIfc.Init(glbM, "ProjectSix")
      mIfc.ifcCtrl = mIfc
      glbM.Action("Startup", "", mIfc)
      glb.Item("PKGSPEC") = "PKGSPEC.txt"
'Note that this startupsubsys function can also accept a tag-based CreateObject,
' giving use the ability to dynamically attach pre-integrated DLLs at run time,
' furthering the model's flexibility and minimizing its run-time footprint
     glbM.Action("StartupSubSys", "glb", glb) 'glb speaks for the vTools subsystem






 '     dbPer = glb.Ref("Per")

  '    dbPer.Action("Logon", ":")

    strPath = glb.Item("ResourcePath")


    End Sub
    Public Sub CloseMain()
        On Error Resume Next
    End Sub
    Public WriteOnly Property ifcCtrlRef() As Object
        Set(ByVal Value As Object)
            On Error Resume Next
            glb.IFCRef = Value
        End Set
    End Property

End Module
